# Estructura del proyecto (Next.js 15 + shadcn/ui + Zustand)

```
limpieza-financiera-express-v2/
├── public/                          # assets estáticos (logo, favicon, og-image)
├── components.json                  # config de shadcn/ui
├── package.json
├── tsconfig.json
├── tailwind.config.ts               # design tokens (colores, radios, animaciones)
├── postcss.config.mjs
├── next.config.ts
├── next-env.d.ts
├── DESIGN.md                        # sistema de diseño + landing + dashboard (spec)
├── STRUCTURE.md                     # este archivo
└── src/
    ├── app/
    │   ├── layout.tsx               # shell raíz (metadata, fuente, skip-link)
    │   ├── globals.css              # tokens CSS (variables HSL)
    │   ├── page.tsx                 # LANDING PAGE (monta las secciones)
    │   ├── onboarding/page.tsx      # flujo de conexión + consentimiento
    │   ├── dashboard/page.tsx       # dashboard de resultados
    │   ├── pago/page.tsx            # pago del success fee
    │   ├── exito/page.tsx           # pantalla de ahorro logrado
    │   ├── dashboard-final/page.tsx # panel post-pago (monitoreo)
    │   ├── privacidad/page.tsx      # legal (pendiente)
    │   └── terminos/page.tsx        # legal (pendiente)
    ├── components/
    │   ├── ui/                      # primitivas shadcn/ui (button, card, badge, ...)
    │   ├── landing/                 # secciones de la landing
    │   │   ├── site-header.tsx
    │   │   ├── hero.tsx
    │   │   ├── how-it-works.tsx
    │   │   ├── problem.tsx
    │   │   ├── features.tsx
    │   │   ├── pricing.tsx
    │   │   ├── testimonials.tsx
    │   │   ├── faq.tsx
    │   │   ├── final-cta.tsx
    │   │   └── site-footer.tsx
    │   ├── dashboard/               # dashboard de resultados
    │   │   ├── metrics.tsx
    │   │   ├── filters.tsx
    │   │   ├── subscription-card.tsx
    │   │   ├── subscription-detail.tsx
    │   │   └── empty-state.tsx
    │   ├── cancellation/            # flujo de cancelación guiada
    │   │   └── cancellation-flow.tsx
    │   └── shared/                  # componentes reutilizables
    ├── config/
    │   └── site.ts                  # copy centralizado (localización por país)
    ├── data/
    │   └── subscriptions.ts         # datos de ejemplo (mock)
    ├── lib/
    │   ├── utils.ts                 # cn() (clsx + tailwind-merge)
    │   └── format.ts                # formatMoney, formatDate
    ├── store/
    │   ├── use-onboarding.ts        # Zustand: onboarding
    │   ├── use-subscriptions.ts     # Zustand: dashboard + filtros + selección
    │   ├── use-cancellation.ts      # Zustand: flujo de cancelación
    │   └── use-billing.ts           # Zustand: fee y pago
    ├── hooks/                       # hooks reutilizables
    └── types/
        └── index.ts                 # tipos del dominio (Subscription, etc.)
```

## Convenciones

- **Ruta base:** `@/` → `src/`.
- **Componentes UI** (shadcn) en `components/ui/`, sin lógica de negocio.
- **Estado global** solo con Zustand en `store/`; estado local con hooks de React.
- **Copy** en `config/site.ts` (para i18n futuro: es-AR, es-MX, en-US).
- **Tipos** de dominio centralizados en `types/`.
- Accesibilidad en todo: contraste AA, targets ≥ 44px, focus visible, `prefers-reduced-motion`,
  HTML semántico y skip-link.

## Próximos pasos (en orden)

1. `next.config.ts` (headers de seguridad, imágenes).
2. Dashboard de resultados + tarjeta de suscripción.
3. Flujo de cancelación + verificación de ahorro.
4. Página de pago del success fee.
5. i18n (next-intl) y páginas legales.
