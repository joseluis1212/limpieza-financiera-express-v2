-- ============================================================================
-- Limpieza Financiera Express v2 — Setup de base de datos + RLS
-- Pegar en Supabase → SQL Editor → Run (después de `drizzle-kit push` o como
-- alternativa directa a las migraciones).
-- ============================================================================

-- RLS: segunda capa de seguridad. La app lee/escribe con conexión directa
-- (rol postgres, que saltea RLS), pero esto protege si en el futuro se leen
-- estas tablas desde el navegador con la anon key.

ALTER TABLE "public"."profiles" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."provider_connections" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."emails_index" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."subscriptions" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."subscription_charges" ENABLE ROW LEVEL SECURITY;

-- Cada usuario solo ve/modifica sus propios datos.
CREATE POLICY "profiles_own" ON "public"."profiles"
  FOR ALL USING (auth.uid() = id);

CREATE POLICY "connections_own" ON "public"."provider_connections"
  FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "emails_own" ON "public"."emails_index"
  FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "subscriptions_own" ON "public"."subscriptions"
  FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "charges_own" ON "public"."subscription_charges"
  FOR ALL USING (
    auth.uid() = (
      SELECT user_id FROM "public"."subscriptions" s
      WHERE s.id = subscription_id
    )
  );
