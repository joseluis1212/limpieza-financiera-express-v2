import { defineConfig } from "drizzle-kit";

// Configuración de drizzle-kit para generar migraciones y sincronizar el esquema.
// Requiere DATABASE_URL (modo Session, puerto 5432, para migraciones locales).

export default defineConfig({
  dialect: "postgresql",
  schema: "./src/db/schema.ts",
  out: "./drizzle",
  dbCredentials: {
    url: process.env.DATABASE_URL ?? "postgresql://postgres:postgres@localhost:5432/postgres",
  },
  strict: true,
  verbose: true,
});
