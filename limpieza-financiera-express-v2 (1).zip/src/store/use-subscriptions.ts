"use client";

import { create } from "zustand";
import type { Subscription } from "@/types";
import { mockSubscriptions } from "@/data/subscriptions";

export type Filter = "todas" | "activas" | "olvidadas" | "trials";

type SubscriptionsState = {
  subscriptions: Subscription[];
  filter: Filter;
  keptIds: string[]; // suscripciones que el usuario marcó "lo uso"
  selectedId: string | null;
  /** Fee del país del usuario (por defecto AR). */
  feeRate: number;
  setFilter: (filter: Filter) => void;
  select: (id: string | null) => void;
  toggleKeep: (id: string) => void;
  markCanceled: (id: string) => void;
  setFeeRate: (rate: number) => void;
};

/**
 * Estado del dashboard: lista de suscripciones, filtros, selección y acciones
 * del usuario. En producción se hidrata desde la API.
 */
export const useSubscriptionsStore = create<SubscriptionsState>((set) => ({
  subscriptions: mockSubscriptions,
  filter: "todas",
  keptIds: [],
  selectedId: null,
  feeRate: 0.3, // Argentina por defecto
  setFilter: (filter) => set({ filter }),
  select: (selectedId) => set({ selectedId }),
  toggleKeep: (id) =>
    set((state) => ({
      keptIds: state.keptIds.includes(id)
        ? state.keptIds.filter((k) => k !== id)
        : [...state.keptIds, id],
    })),
  markCanceled: (id) =>
    set((state) => ({
      subscriptions: state.subscriptions.map((s) =>
        s.id === id ? { ...s, status: "canceled" } : s,
      ),
      keptIds: state.keptIds.filter((k) => k !== id),
    })),
  setFeeRate: (feeRate) => set({ feeRate }),
}));

/** Selector derivado: total mensual de las suscripciones activas (no canceladas). */
export function selectMonthlySavings(
  subscriptions: Subscription[],
  keptIds: string[],
): { monthlyCents: number; currency: Subscription["currency"] } {
  const active = subscriptions.filter(
    (s) => s.status !== "canceled" && !keptIds.includes(s.id),
  );
  // Suma normalizada: para simplificar, se suma en la moneda dominante (ARS).
  // En producción se convierte con una tabla de tipos de cambio.
  const monthlyCents = active.reduce(
    (sum, s) =>
      sum + (s.recurrence === "annual" ? Math.round(s.amountCents / 12) : s.amountCents),
    0,
  );
  return { monthlyCents, currency: "ARS" };
}
