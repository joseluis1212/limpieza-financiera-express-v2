"use client";

import { create } from "zustand";

type BillingState = {
  /** Ahorro total verificado (centavos, moneda dominante). */
  totalSavingsCents: number;
  currency: "ARS" | "MXN" | "USD";
  feeRate: number;
  feeCents: number;
  paid: boolean;
  method: "stripe" | "mercadopago" | null;
  setMethod: (method: "stripe" | "mercadopago") => void;
  pay: () => void;
};

/**
 * Estado de facturación del success fee. En producción el monto viene del
 * backend (ahorro verificado acumulado) y el pago se ejecuta vía Stripe/MP.
 */
export const useBillingStore = create<BillingState>((set) => ({
  totalSavingsCents: 11998800, // ejemplo ARS
  currency: "ARS",
  feeRate: 0.3,
  feeCents: Math.round(11998800 * 0.3),
  paid: false,
  method: null,
  setMethod: (method) => set({ method }),
  pay: () => set({ paid: true }),
}));
