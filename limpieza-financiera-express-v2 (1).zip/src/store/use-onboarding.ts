"use client";

import { create } from "zustand";

export type Provider = "gmail" | "outlook" | null;

export type OnboardingStep =
  | "welcome"
  | "consent"
  | "connecting"
  | "scanning"
  | "done";

type OnboardingState = {
  provider: Provider;
  step: OnboardingStep;
  scanProgress: number;
  setProvider: (provider: Provider) => void;
  setStep: (step: OnboardingStep) => void;
  setScanProgress: (progress: number) => void;
  reset: () => void;
};

/**
 * Estado del flujo de onboarding: conexión de email → consentimiento → escaneo.
 * Se usa en el cliente; el escaneo real es asíncrono (job) y aquí se refleja su progreso.
 */
export const useOnboardingStore = create<OnboardingState>((set) => ({
  provider: null,
  step: "welcome",
  scanProgress: 0,
  setProvider: (provider) => set({ provider }),
  setStep: (step) => set({ step }),
  setScanProgress: (scanProgress) => set({ scanProgress }),
  reset: () => set({ provider: null, step: "welcome", scanProgress: 0 }),
}));
