"use client";

import { create } from "zustand";
import type { Subscription } from "@/types";

export type CancelMethod = "self_service" | "letter" | "concierge";

export type CancelStep =
  | "review" // revisar fee y confirmar
  | "guide" // pasos guiados del comercio
  | "waiting" // esperando confirmación de baja
  | "confirmed" // ahorro confirmado
  | "failed"; // no se pudo cancelar

type CancellationState = {
  subscription: Subscription | null;
  step: CancelStep;
  method: CancelMethod;
  guideStepIndex: number;
  /** Fee calculado en centavos. */
  feeCents: number;
  annualSavingsCents: number;
  start: (subscription: Subscription, feeRate: number) => void;
  setMethod: (method: CancelMethod) => void;
  nextGuideStep: () => void;
  prevGuideStep: () => void;
  confirmWaiting: () => void;
  confirmDone: () => void;
  fail: () => void;
  close: () => void;
};

function annualize(sub: Subscription): number {
  if (sub.recurrence === "annual") return sub.amountCents;
  if (sub.recurrence === "weekly") return sub.amountCents * 52;
  return sub.amountCents * 12;
}

/**
 * Flujo de cancelación guiada, desde la revisión del fee hasta la confirmación
 * del ahorro.
 */
export const useCancellationStore = create<CancellationState>((set) => ({
  subscription: null,
  step: "review",
  method: "self_service",
  guideStepIndex: 0,
  feeCents: 0,
  annualSavingsCents: 0,
  start: (subscription, feeRate) =>
    set({
      subscription,
      step: "review",
      method: "self_service",
      guideStepIndex: 0,
      annualSavingsCents: annualize(subscription),
      feeCents: Math.round(annualize(subscription) * feeRate),
    }),
  setMethod: (method) => set({ method }),
  nextGuideStep: () => set((s) => ({ guideStepIndex: s.guideStepIndex + 1 })),
  prevGuideStep: () => set((s) => ({ guideStepIndex: Math.max(0, s.guideStepIndex - 1) })),
  confirmWaiting: () => set({ step: "waiting" }),
  confirmDone: () => set({ step: "confirmed" }),
  fail: () => set({ step: "failed" }),
  close: () =>
    set({
      subscription: null,
      step: "review",
      method: "self_service",
      guideStepIndex: 0,
      feeCents: 0,
      annualSavingsCents: 0,
    }),
}));
