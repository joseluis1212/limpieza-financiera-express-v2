import Link from "next/link";
import { AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Problem() {
  return (
    <section className="py-16 lg:py-24">
      <div className="container grid items-center gap-12 lg:grid-cols-2">
        <div>
          <p className="inline-flex items-center gap-2 rounded-full bg-amber-100 px-4 py-1.5 text-sm font-semibold text-amber-800">
            <AlertTriangle className="size-4" aria-hidden />
            El costo de no hacer nada
          </p>
          <h2 className="mt-6 text-3xl font-bold tracking-tight sm:text-4xl">
            Las suscripciones que olvidaste no se cancelan solas.
          </h2>
          <p className="mt-4 text-lg text-slate-700">
            La mayoría de las personas tiene entre 2 y 4 suscripciones que ya no usa. Una de{" "}
            <strong>$9.999 al mes</strong> son <strong>$119.988 al año</strong> — dinero que se
            va todos los meses sin que lo notes.
          </p>
          <p className="mt-3 text-lg text-slate-700">
            Y los <strong>trials gratuitos</strong> son peores: olvidás cancelarlos y te cobran
            sin avisar.
          </p>

          <div className="mt-8">
            <Button asChild size="lg">
              <Link href="/onboarding">Descubrí cuánto estás pagando</Link>
            </Button>
          </div>
        </div>

        {/* Ejemplo visual */}
        <div className="rounded-3xl border bg-white p-8 shadow-lg shadow-slate-200/60">
          <h3 className="text-lg font-bold text-slate-700">Ejemplo real</h3>
          <dl className="mt-6 space-y-4">
            {[
              { label: "Suscripción que no usás", value: "$9.999/mes" },
              { label: "Al año", value: "$119.988" },
              { label: "Nuestro fee (30%)", value: "$35.996" },
            ].map((row) => (
              <div key={row.label} className="flex items-center justify-between border-b pb-3">
                <dt className="text-slate-700">{row.label}</dt>
                <dd className="font-bold">{row.value}</dd>
              </div>
            ))}
            <div className="flex items-center justify-between">
              <dt className="text-lg font-bold text-emerald-700">Vos recuperás</dt>
              <dd className="text-2xl font-extrabold text-success">$83.992</dd>
            </div>
          </dl>
          <p className="mt-4 text-sm text-slate-600">
            Es el 70% de lo que ibas a seguir pagando por algo que no usás.
          </p>
        </div>
      </div>
    </section>
  );
}
