const faqs = [
  {
    q: "¿Ven mis correos?",
    a: "No. Solo leemos el asunto, el remitente y los datos de los pagos (montos y fechas). Nunca vemos el contenido completo de tus emails, y jamás borramos ni enviamos nada.",
  },
  {
    q: "¿Cuánto me cobran?",
    a: "Solo cobramos si te ahorramos dinero: un porcentaje del ahorro de tu primer año (30% en Argentina, 35% en México, 40% en Estados Unidos). Siempre te mostramos el monto exacto antes de cobrarte.",
  },
  {
    q: "¿Y si no me ahorran nada?",
    a: "No pagás nada. El escaneo y la detección son gratis. Solo pagás cuando se confirma que dejaste de pagar una suscripción.",
  },
  {
    q: "¿Cómo saben cuánto me ahorraron?",
    a: "Detectamos el correo de confirmación de la baja (“tu suscripción fue cancelada”). Si no aparece esa confirmación, no te cobramos.",
  },
  {
    q: "¿Cancelan las suscripciones por mí?",
    a: "Te guiamos paso a paso para que las canceles fácil. En algunos casos podemos ayudarte con una carta o asistencia personal. Siempre con tu autorización.",
  },
];

export function Faq() {
  return (
    <section id="preguntas" className="py-16 lg:py-24">
      <div className="container max-w-3xl">
        <h2 className="text-center text-3xl font-bold tracking-tight sm:text-4xl">
          Preguntas frecuentes
        </h2>

        <div className="mt-10 space-y-3">
          {faqs.map((faq) => (
            <details
              key={faq.q}
              className="group rounded-2xl border bg-white open:shadow-sm"
            >
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 p-6 text-lg font-semibold">
                {faq.q}
                <span
                  className="grid size-8 shrink-0 place-items-center rounded-full bg-muted text-slate-600 transition-transform group-open:rotate-45"
                  aria-hidden
                >
                  +
                </span>
              </summary>
              <p className="px-6 pb-6 text-slate-700">{faq.a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}
