import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

export function FinalCta() {
  return (
    <section className="py-16 lg:py-24">
      <div className="container">
        <div className="rounded-3xl bg-primary px-6 py-14 text-center text-white sm:px-12">
          <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
            Empezá a recuperar tu dinero hoy
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-lg text-blue-100">
            Escaneá tu correo gratis y descubrí cuánto estás pagando sin usar. No pagás nada
            hasta que te ahorremos.
          </p>
          <div className="mt-8 flex justify-center">
            <Button asChild size="lg" variant="success" className="bg-white text-primary hover:bg-blue-50">
              <Link href="/onboarding">
                Escanear mi correo gratis
                <ArrowRight aria-hidden />
              </Link>
            </Button>
          </div>
          <p className="mt-4 text-sm text-blue-200">
            Sin suscripción mensual. Solo pagás si ahorrás.
          </p>
        </div>
      </div>
    </section>
  );
}
