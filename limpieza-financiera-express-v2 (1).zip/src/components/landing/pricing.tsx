import Link from "next/link";
import { Check } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

const plans = [
  {
    name: "Gratis",
    price: "$0",
    period: "siempre",
    description: "Empezá sin pagar nada.",
    features: [
      "Escaneo completo de tu correo",
      "Lista de suscripciones detectadas",
      "Ahorro potencial estimado",
    ],
    cta: { label: "Escanear gratis", href: "/onboarding", variant: "outline" as const },
    highlight: false,
  },
  {
    name: "Por resultado",
    price: "30%",
    period: "del ahorro del 1er año",
    description: "Pagás solo si te ahorramos dinero.",
    features: [
      "Cancelación guiada de suscripciones",
      "Detección de confirmación de baja",
      "Alertas de trials y renovaciones",
      "Te mostramos el monto exacto antes",
    ],
    cta: { label: "Empezar a ahorrar", href: "/onboarding", variant: "default" as const },
    highlight: true,
  },
  {
    name: "Pago fijo",
    price: "$24.900",
    period: "una vez · Argentina",
    description: "Sin porcentajes, todo incluido.",
    features: [
      "Todo lo del plan anterior",
      "12 meses de monitoreo",
      "Cancelaciones ilimitadas",
    ],
    cta: { label: "Elegir pago fijo", href: "/onboarding", variant: "outline" as const },
    highlight: false,
  },
];

export function Pricing() {
  return (
    <section id="precios" className="py-16 lg:py-24">
      <div className="container">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
            Precios transparentes
          </h2>
          <p className="mt-4 text-lg text-slate-700">
            Sin letra chica. El fee varía según tu país: 30% Argentina, 35% México, 40% Estados
            Unidos. Y en Argentina también podés elegir un pago fijo.
          </p>
        </div>

        <div className="mt-12 grid gap-6 lg:grid-cols-3">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`relative flex flex-col rounded-2xl border p-8 ${
                plan.highlight ? "border-primary shadow-lg shadow-primary/10" : "bg-white"
              }`}
            >
              {plan.highlight ? (
                <Badge className="absolute -top-3 left-1/2 -translate-x-1/2">
                  Más elegido
                </Badge>
              ) : null}

              <h3 className="text-xl font-bold">{plan.name}</h3>
              <div className="mt-3 flex items-baseline gap-1">
                <span className="text-4xl font-extrabold">{plan.price}</span>
                <span className="text-sm text-slate-600">{plan.period}</span>
              </div>
              <p className="mt-2 text-slate-700">{plan.description}</p>

              <ul className="mt-6 flex-1 space-y-3">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-2 text-slate-700">
                    <Check className="mt-1 size-5 shrink-0 text-success" aria-hidden />
                    {feature}
                  </li>
                ))}
              </ul>

              <Button asChild variant={plan.cta.variant} className="mt-8 w-full">
                <Link href={plan.cta.href}>{plan.cta.label}</Link>
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
