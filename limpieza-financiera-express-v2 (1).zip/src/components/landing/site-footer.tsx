import Link from "next/link";
import { ShieldCheck } from "lucide-react";
import { siteConfig } from "@/config/site";

export function SiteFooter() {
  return (
    <footer className="border-t bg-white py-12">
      <div className="container">
        <div className="flex flex-col items-start justify-between gap-8 sm:flex-row">
          <div className="max-w-sm">
            <div className="flex items-center gap-2">
              <span className="grid size-8 place-items-center rounded-lg bg-primary text-white">
                <ShieldCheck className="size-4" aria-hidden />
              </span>
              <span className="font-bold">Limpieza Financiera Express</span>
            </div>
            <p className="mt-3 text-slate-600">
              Te recuperamos el dinero que estás tirando todos los meses. Solo cobramos si te
              ahorramos.
            </p>
          </div>

          <nav aria-label="Enlaces legales" className="grid gap-3 text-slate-700">
            <Link href="/privacidad" className="hover:text-primary">
              Política de privacidad
            </Link>
            <Link href="/terminos" className="hover:text-primary">
              Términos y condiciones
            </Link>
            <a href={`mailto:${siteConfig.contactEmail}`} className="hover:text-primary">
              Contacto
            </a>
          </nav>
        </div>

        <div className="mt-10 border-t pt-6 text-sm text-slate-600">
          <p>
            © {new Date().getFullYear()} {siteConfig.name}. Todos los derechos reservados.
          </p>
          <p className="mt-1">
            No somos un asesor financiero. Los resultados varían según cada persona.
          </p>
        </div>
      </div>
    </footer>
  );
}
