import { Star } from "lucide-react";

const testimonials = [
  {
    name: "María G.",
    location: "Buenos Aires, Argentina",
    quote:
      "Encontré 4 suscripciones que ni recordaba. Me ahorró más de $140.000 en el primer mes.",
    savings: "$140.000 recuperados",
  },
  {
    name: "Diego R.",
    location: "Ciudad de México",
    quote:
      "Me avisó de un trial que estaba a punto de cobrarme. Lo cancelé justo a tiempo.",
    savings: "3 trials evitados",
  },
  {
    name: "Sarah T.",
    location: "Austin, Estados Unidos",
    quote:
      "Me mostraron el fee exacto antes de cancelar. Transparente y sin sorpresas.",
    savings: "$310 al año recuperados",
  },
];

export function Testimonials() {
  return (
    <section className="bg-muted/50 py-16 lg:py-24">
      <div className="container">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
            Personas que ya recuperaron su dinero
          </h2>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {testimonials.map((t) => (
            <figure key={t.name} className="rounded-2xl border bg-white p-6">
              <div className="flex gap-0.5 text-amber-400" aria-label="5 estrellas">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="size-5 fill-current" aria-hidden />
                ))}
              </div>
              <blockquote className="mt-4 text-slate-700">“{t.quote}”</blockquote>
              <figcaption className="mt-4">
                <p className="font-bold">{t.name}</p>
                <p className="text-sm text-slate-600">{t.location}</p>
                <p className="mt-2 inline-block rounded-full bg-emerald-50 px-3 py-1 text-sm font-semibold text-emerald-800">
                  {t.savings}
                </p>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}
