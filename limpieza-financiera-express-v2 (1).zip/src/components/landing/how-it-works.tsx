import { Mail, Search, PiggyBank } from "lucide-react";

const steps = [
  {
    icon: Mail,
    title: "Conectá tu correo",
    text: "Gmail o Outlook, en un clic y con acceso de solo lectura.",
  },
  {
    icon: Search,
    title: "Encontramos todo",
    text: "Suscripciones activas, olvidadas y pruebas gratis a punto de cobrar.",
  },
  {
    icon: PiggyBank,
    title: "Cancelás y ahorrás",
    text: "Te guiamos para cancelar lo que no usás. Pagás solo un % de lo que recuperás.",
  },
];

export function HowItWorks() {
  return (
    <section id="como-funciona" className="bg-muted/50 py-16 lg:py-24">
      <div className="container">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
            Así de simple
          </h2>
          <p className="mt-4 text-lg text-slate-700">
            En menos de un minuto vas a saber qué estás pagando sin usar.
          </p>
        </div>

        <ol className="mt-12 grid gap-6 md:grid-cols-3">
          {steps.map(({ icon: Icon, title, text }, i) => (
            <li key={title} className="relative rounded-2xl border bg-white p-8">
              <span className="absolute -top-4 left-8 grid size-9 place-items-center rounded-full bg-primary text-lg font-bold text-white">
                {i + 1}
              </span>
              <Icon className="size-9 text-primary" aria-hidden />
              <h3 className="mt-4 text-xl font-bold">{title}</h3>
              <p className="mt-2 text-slate-700">{text}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
