import { ShieldCheck, EyeOff, Bell, Globe2, HandCoins, Sparkles } from "lucide-react";

const features = [
  {
    icon: ShieldCheck,
    title: "Privacidad real",
    text: "Acceso de solo lectura. Nunca vemos el contenido de tus correos, solo los datos de los pagos.",
  },
  {
    icon: EyeOff,
    title: "Nada se te escapa",
    text: "Detectamos suscripciones activas, olvidadas y pruebas gratis a punto de cobrar.",
  },
  {
    icon: Bell,
    title: "Te avisamos antes",
    text: "Alertas de trials que van a cobrarte y de renovaciones de precios.",
  },
  {
    icon: HandCoins,
    title: "Pagás solo si ahorrás",
    text: "Un porcentaje del ahorro del primer año. Sin suscripción mensual nuestra.",
  },
  {
    icon: Globe2,
    title: "Hecho para tu país",
    text: "Argentina, México y Estados Unidos. Montos en tu moneda y soporte en tu idioma.",
  },
  {
    icon: Sparkles,
    title: "Simple de verdad",
    text: "Sin tecnicismos. Diseñado para que lo use cualquier persona, a cualquier edad.",
  },
];

export function Features() {
  return (
    <section className="bg-muted/50 py-16 lg:py-24">
      <div className="container">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
            Pensado para que confíes
          </h2>
          <p className="mt-4 text-lg text-slate-700">
            Tu privacidad y tu dinero, siempre primero.
          </p>
        </div>

        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {features.map(({ icon: Icon, title, text }) => (
            <div key={title} className="rounded-2xl border bg-white p-6">
              <span className="grid size-11 place-items-center rounded-lg bg-primary/10 text-primary">
                <Icon className="size-6" aria-hidden />
              </span>
              <h3 className="mt-4 text-lg font-bold">{title}</h3>
              <p className="mt-2 text-slate-700">{text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
