"use client";

import { useState } from "react";
import Link from "next/link";
import { Menu, ShieldCheck, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { siteConfig } from "@/config/site";

export function SiteHeader() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b bg-white/90 backdrop-blur">
      <div className="container flex h-16 items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2" aria-label="Ir al inicio">
          <span className="grid size-9 place-items-center rounded-lg bg-primary text-white">
            <ShieldCheck className="size-5" aria-hidden />
          </span>
          <span className="text-lg font-bold tracking-tight">
            Limpieza Financiera<span className="text-primary"> Express</span>
          </span>
        </Link>

        {/* Navegación desktop */}
        <nav className="hidden items-center gap-6 md:flex" aria-label="Menú principal">
          {siteConfig.nav.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="text-base font-medium text-slate-700 transition-colors hover:text-primary"
            >
              {item.label}
            </a>
          ))}
        </nav>

        <div className="hidden md:block">
          <Button asChild>
            <Link href="/onboarding">Escanear mi correo</Link>
          </Button>
        </div>

        {/* Botón menú móvil */}
        <button
          type="button"
          className="grid size-11 place-items-center rounded-lg md:hidden"
          aria-expanded={open}
          aria-label={open ? "Cerrar menú" : "Abrir menú"}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X className="size-6" aria-hidden /> : <Menu className="size-6" aria-hidden />}
        </button>
      </div>

      {/* Menú móvil */}
      {open ? (
        <nav className="border-t bg-white px-6 py-4 md:hidden" aria-label="Menú móvil">
          <ul className="flex flex-col gap-2">
            {siteConfig.nav.map((item) => (
              <li key={item.href}>
                <a
                  href={item.href}
                  onClick={() => setOpen(false)}
                  className="block rounded-lg px-3 py-3 text-base font-medium text-slate-700 hover:bg-muted"
                >
                  {item.label}
                </a>
              </li>
            ))}
            <li className="mt-2">
              <Button asChild className="w-full">
                <Link href="/onboarding" onClick={() => setOpen(false)}>
                  Escanear mi correo
                </Link>
              </Button>
            </li>
          </ul>
        </nav>
      ) : null}
    </header>
  );
}
