import Link from "next/link";
import { ArrowRight, CheckCircle2, Lock, Mail } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

const trustPoints = [
  { icon: Lock, text: "Solo lectura: nunca vemos tus correos" },
  { icon: CheckCircle2, text: "Sin cargos sorpresa: te mostramos el monto antes" },
  { icon: Mail, text: "Funciona con Gmail y Outlook" },
];

export function Hero() {
  return (
    <section className="relative overflow-hidden">
      {/* Acento sutil de fondo */}
      <div
        className="pointer-events-none absolute inset-0 -z-10 bg-[radial-gradient(circle_at_top_right,hsl(221_100%_96%),transparent_55%)]"
        aria-hidden
      />

      <div className="container grid items-center gap-12 py-16 lg:grid-cols-[1.1fr_0.9fr] lg:py-24">
        {/* Columna de texto */}
        <div>
          <Badge variant="success" className="mb-6 px-4 py-1.5 text-sm">
            ✅ Solo cobramos si te ahorramos dinero
          </Badge>

          <h1 className="text-4xl font-extrabold leading-tight tracking-tight sm:text-5xl lg:text-6xl">
            Te recuperamos el dinero que{" "}
            <span className="text-primary">estás tirando</span> todos los meses.
          </h1>

          <p className="mt-6 max-w-xl text-lg text-slate-700">
            Conectá tu correo y te mostramos todas las suscripciones que tenés activas, las que
            olvidaste y las pruebas gratis a punto de cobrarte. Sin leer tus emails y sin cargos
            sorpresa.
          </p>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Button asChild size="lg">
              <Link href="/onboarding">
                Escanear mi correo gratis
                <ArrowRight aria-hidden />
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <a href="#como-funciona">Ver cómo funciona</a>
            </Button>
          </div>

          <ul className="mt-8 flex flex-col gap-3">
            {trustPoints.map(({ icon: Icon, text }) => (
              <li key={text} className="flex items-center gap-3 text-base text-slate-700">
                <Icon className="size-5 shrink-0 text-success" aria-hidden />
                {text}
              </li>
            ))}
          </ul>
        </div>

        {/* Columna: mockup del resultado (decorativo) */}
        <div className="lg:pl-4" aria-hidden>
          <div className="rounded-3xl border bg-white p-6 shadow-xl shadow-slate-200/60">
            <p className="text-sm font-semibold text-slate-600">Ahorro potencial</p>
            <p className="mt-1 text-4xl font-extrabold text-success">$23.500<span className="text-lg font-semibold text-slate-500">/mes</span></p>

            <div className="mt-6 space-y-3">
              {[
                { name: "Netflix", detail: "Suscripción mensual", amount: "$9.999" },
                { name: "AppDeEdición", detail: "Olvidada · hace 4 meses", amount: "US$15" },
                { name: "GymApp", detail: "Trial · cobra el 01/09", amount: "$14.999" },
              ].map((row) => (
                <div key={row.name} className="flex items-center justify-between rounded-xl border p-4">
                  <div>
                    <p className="font-bold">{row.name}</p>
                    <p className="text-sm text-slate-600">{row.detail}</p>
                  </div>
                  <p className="font-bold">{row.amount}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
