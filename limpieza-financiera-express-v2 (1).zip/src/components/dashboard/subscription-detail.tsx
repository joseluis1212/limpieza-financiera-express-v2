"use client";

import { X, Calendar, CreditCard } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatDate, formatMoney } from "@/lib/format";
import type { Subscription } from "@/types";

const CATEGORY_LABEL: Record<string, string> = {
  streaming: "Streaming",
  software: "Software",
  fitness: "Deportes",
  cloud_storage: "Almacenamiento",
  news: "Noticias",
  music: "Música",
  other: "Otro",
};

const RECURRENCE_LABEL: Record<Subscription["recurrence"], string> = {
  monthly: "Mensual",
  annual: "Anual",
  weekly: "Semanal",
  trial: "Prueba gratis",
  one_time: "Único",
};

/**
 * Drawer/detalle de una suscripción: historial, frecuencia y acciones.
 * En producción el historial de cargos viene de `GET /subscriptions/{id}`.
 */
export function SubscriptionDetail({
  subscription,
  onClose,
  onCancel,
  onKeep,
}: {
  subscription: Subscription;
  onClose: () => void;
  onCancel: () => void;
  onKeep: () => void;
}) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/40 sm:items-center"
      role="dialog"
      aria-modal="true"
      aria-label={`Detalle de ${subscription.merchant}`}
      onClick={onClose}
    >
      <div
        className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-t-3xl bg-white p-6 sm:rounded-3xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <span className="grid size-12 place-items-center rounded-lg bg-primary/10 text-xl font-bold text-primary">
              {subscription.merchant.charAt(0)}
            </span>
            <div>
              <h2 className="text-xl font-bold">{subscription.merchant}</h2>
              <Badge variant="secondary">{CATEGORY_LABEL[subscription.category] ?? "Otro"}</Badge>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="grid size-10 place-items-center rounded-lg text-slate-500 hover:bg-muted"
            aria-label="Cerrar"
          >
            <X className="size-5" aria-hidden />
          </button>
        </div>

        {/* Monto y frecuencia */}
        <div className="mt-6 rounded-2xl bg-muted p-6">
          <p className="text-sm font-semibold text-slate-600">Pago {RECURRENCE_LABEL[subscription.recurrence].toLowerCase()}</p>
          <p className="mt-1 text-4xl font-extrabold">
            {formatMoney(subscription.amountCents, subscription.currency)}
          </p>
          <div className="mt-4 space-y-2 text-sm text-slate-700">
            {subscription.lastChargedAt ? (
              <p className="flex items-center gap-2">
                <Calendar className="size-4" aria-hidden /> Último cobro:{" "}
                {formatDate(subscription.lastChargedAt)}
              </p>
            ) : null}
            {subscription.nextExpectedAt ? (
              <p className="flex items-center gap-2">
                <Calendar className="size-4" aria-hidden /> Próximo cobro:{" "}
                {formatDate(subscription.nextExpectedAt)}
              </p>
            ) : null}
          </div>
        </div>

        {/* Ahorro anual estimado */}
        <div className="mt-4 rounded-2xl border border-success bg-success/5 p-6">
          <p className="flex items-center gap-2 text-sm font-semibold text-emerald-800">
            <CreditCard className="size-4" aria-hidden /> Si la cancelás, dejás de pagar
          </p>
          <p className="mt-1 text-2xl font-extrabold text-success">
            {formatMoney(
              subscription.recurrence === "annual"
                ? subscription.amountCents
                : subscription.amountCents * 12,
              subscription.currency,
            )}
            <span className="text-base font-semibold text-slate-600"> / año</span>
          </p>
        </div>

        {/* Acciones */}
        <div className="mt-6 flex flex-col gap-2 sm:flex-row">
          <Button className="flex-1" size="lg" onClick={onCancel}>
            Cancelar esta suscripción
          </Button>
          <Button className="flex-1" size="lg" variant="outline" onClick={onKeep}>
            Mantenerla
          </Button>
        </div>
      </div>
    </div>
  );
}
