"use client";

import { cn } from "@/lib/utils";

export type Filter = "todas" | "activas" | "olvidadas" | "trials";

const FILTERS: { id: Filter; label: string }[] = [
  { id: "todas", label: "Todas" },
  { id: "activas", label: "Activas" },
  { id: "olvidadas", label: "Olvidadas" },
  { id: "trials", label: "Trials" },
];

export function Filters({
  value,
  onChange,
  counts,
}: {
  value: Filter;
  onChange: (f: Filter) => void;
  counts: Record<Filter, number>;
}) {
  return (
    <div
      className="flex flex-wrap gap-2"
      role="tablist"
      aria-label="Filtrar suscripciones"
    >
      {FILTERS.map(({ id, label }) => (
        <button
          key={id}
          type="button"
          role="tab"
          aria-selected={value === id}
          onClick={() => onChange(id)}
          className={cn(
            "h-12 rounded-full border px-5 text-base font-semibold transition-colors",
            value === id
              ? "border-primary bg-primary text-primary-foreground"
              : "border bg-white text-slate-700 hover:bg-muted",
          )}
        >
          {label}
          <span className="ml-2 opacity-70">{counts[id]}</span>
        </button>
      ))}
    </div>
  );
}
