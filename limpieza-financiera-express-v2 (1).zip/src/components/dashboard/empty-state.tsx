import { Inbox } from "lucide-react";
import { Button } from "@/components/ui/button";

export function EmptyState({ onRescan }: { onRescan?: () => void }) {
  return (
    <div className="rounded-2xl border border-dashed p-12 text-center">
      <Inbox className="mx-auto size-12 text-slate-400" aria-hidden />
      <h3 className="mt-4 text-xl font-bold">No encontramos suscripciones</h3>
      <p className="mx-auto mt-2 max-w-md text-slate-700">
        Todavía no detectamos suscripciones en esta cuenta. Podés volver a escanear o conectar
        otro correo.
      </p>
      {onRescan ? (
        <Button className="mt-6" onClick={onRescan}>
          Volver a escanear
        </Button>
      ) : null}
    </div>
  );
}
