"use client";

import { AlertTriangle, Calendar, CheckCircle2, MoreVertical } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatDayMonth, formatMoney } from "@/lib/format";
import type { Subscription } from "@/types";

const CATEGORY_LABEL: Record<string, string> = {
  streaming: "Streaming",
  software: "Software",
  fitness: "Deportes",
  cloud_storage: "Almacenamiento",
  news: "Noticias",
  music: "Música",
  other: "Otro",
};

const CONFIDENCE_LABEL: Record<Subscription["confidence"], string> = {
  high: "Detección segura",
  medium: "Detección media",
  low: "Revisar",
};

export function SubscriptionCard({
  subscription,
  isKept,
  onSelect,
  onCancel,
  onKeep,
}: {
  subscription: Subscription;
  isKept: boolean;
  onSelect: () => void;
  onCancel: () => void;
  onKeep: () => void;
}) {
  const isTrial = subscription.status === "trial";
  const isForgotten = subscription.status === "forgotten";

  return (
    <article className="rounded-2xl border bg-white p-6 shadow-sm transition-shadow hover:shadow-md">
      <div className="flex items-start justify-between gap-4">
        <button
          type="button"
          onClick={onSelect}
          className="flex min-w-0 items-start gap-3 text-left"
          aria-label={`Ver detalle de ${subscription.merchant}`}
        >
          <span className="grid size-11 shrink-0 place-items-center rounded-lg bg-primary/10 text-lg font-bold text-primary">
            {subscription.merchant.charAt(0)}
          </span>
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="text-lg font-bold">{subscription.merchant}</h3>
              <Badge variant="secondary">{CATEGORY_LABEL[subscription.category] ?? "Otro"}</Badge>
            </div>
            <p className="text-sm text-slate-600">{CONFIDENCE_LABEL[subscription.confidence]}</p>
          </div>
        </button>

        <button
          type="button"
          onClick={onSelect}
          className="grid size-10 place-items-center rounded-lg text-slate-500 hover:bg-muted"
          aria-label="Más opciones"
        >
          <MoreVertical className="size-5" aria-hidden />
        </button>
      </div>

      {/* Monto y recurrencia */}
      <div className="mt-4 flex items-baseline gap-2">
        <p className="text-3xl font-extrabold tracking-tight">
          {formatMoney(subscription.amountCents, subscription.currency)}
        </p>
        <p className="text-slate-600">/ {subscription.recurrence === "annual" ? "año" : "mes"}</p>
      </div>

      {/* Fechas */}
      <div className="mt-3 space-y-1 text-sm text-slate-600">
        {subscription.lastChargedAt ? (
          <p className="flex items-center gap-2">
            <Calendar className="size-4" aria-hidden />
            Último cobro: {formatDayMonth(subscription.lastChargedAt)}
          </p>
        ) : null}
        {subscription.nextExpectedAt ? (
          <p className="flex items-center gap-2">
            <Calendar className="size-4" aria-hidden />
            Próximo cobro: {formatDayMonth(subscription.nextExpectedAt)}
          </p>
        ) : null}
      </div>

      {/* Avisos de estado */}
      {isTrial ? (
        <p className="mt-3 flex items-center gap-2 rounded-lg bg-amber-50 px-3 py-2 text-sm font-semibold text-amber-800">
          <AlertTriangle className="size-4 shrink-0" aria-hidden />
          Te cobrarán {formatMoney(subscription.amountCents, subscription.currency)} el{" "}
          {formatDayMonth(subscription.trialEndsAt)}
        </p>
      ) : null}
      {isForgotten ? (
        <p className="mt-3 flex items-center gap-2 rounded-lg bg-slate-50 px-3 py-2 text-sm font-semibold text-slate-700">
          <CheckCircle2 className="size-4 shrink-0 text-success" aria-hidden />
          Olvidada · {subscription.unusedMonths ?? 2} meses sin uso
        </p>
      ) : null}

      {/* Acciones */}
      {isKept ? (
        <p className="mt-5 flex items-center gap-2 rounded-lg bg-emerald-50 px-3 py-2 text-sm font-semibold text-emerald-800">
          <CheckCircle2 className="size-4" aria-hidden /> La vas a mantener
        </p>
      ) : (
        <div className="mt-5 flex flex-col gap-2 sm:flex-row">
          <Button variant="default" className="flex-1" onClick={onCancel}>
            Cancelar
          </Button>
          <Button variant="outline" className="flex-1" onClick={onKeep}>
            Lo uso, mantenerla
          </Button>
        </div>
      )}
    </article>
  );
}
