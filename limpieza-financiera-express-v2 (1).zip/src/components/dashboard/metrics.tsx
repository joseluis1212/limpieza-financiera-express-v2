import { PiggyBank, Layers, EyeOff, AlertTriangle } from "lucide-react";
import { formatMoney } from "@/lib/format";
import type { Subscription } from "@/types";
import { selectMonthlySavings } from "@/store/use-subscriptions";

export function Metrics({
  subscriptions,
  keptIds,
}: {
  subscriptions: Subscription[];
  keptIds: string[];
}) {
  const { monthlyCents, currency } = selectMonthlySavings(subscriptions, keptIds);
  const count = subscriptions.filter((s) => s.status !== "canceled").length;
  const forgotten = subscriptions.filter((s) => s.status === "forgotten").length;
  const trials = subscriptions.filter((s) => s.status === "trial").length;

  const cards = [
    {
      icon: PiggyBank,
      label: "Ahorro potencial",
      value: `${formatMoney(monthlyCents, currency)}/mes`,
      highlight: true,
    },
    { icon: Layers, label: "Suscripciones", value: String(count) },
    { icon: EyeOff, label: "Olvidadas", value: String(forgotten) },
    {
      icon: AlertTriangle,
      label: "Trials a punto de cobrar",
      value: String(trials),
      warn: trials > 0,
    },
  ];

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {cards.map(({ icon: Icon, label, value, highlight, warn }) => (
        <div
          key={label}
          className={`rounded-2xl border p-6 ${
            highlight ? "border-success bg-success/5" : warn ? "border-amber-200 bg-amber-50" : "bg-white"
          }`}
        >
          <div className="flex items-center gap-2">
            <Icon
              className={`size-5 ${highlight ? "text-success" : warn ? "text-amber-600" : "text-primary"}`}
              aria-hidden
            />
            <p className="text-sm font-semibold text-slate-600">{label}</p>
          </div>
          <p
            className={`mt-3 text-3xl font-extrabold tracking-tight ${
              highlight ? "text-success" : "text-foreground"
            }`}
          >
            {value}
          </p>
        </div>
      ))}
    </div>
  );
}
