"use client";

import { useEffect, useState } from "react";
import { X, CheckCircle2, ExternalLink, Loader2, FileText, Headset, MousePointerClick } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatMoney } from "@/lib/format";
import { useCancellationStore } from "@/store/use-cancellation";

/**
 * Flujo de cancelación guiada:
 *  1. review   → mostrar fee exacto y pedir confirmación
 *  2. guide    → pasos del comercio (playbook)
 *  3. waiting  → esperando confirmación de baja (email)
 *  4. confirmed→ ahorro verificado
 *  5. failed   → no se pudo cancelar
 */

const GUIDE_STEPS = [
  { title: "Entrá a tu cuenta", text: "Abrí la página de tu cuenta en el sitio del servicio." },
  { title: "Buscá 'Suscripción'", text: "Andá a Configuración → Suscripción o Facturación." },
  { title: "Confirmá la baja", text: "Tocá 'Cancelar suscripción' y confirmá." },
];

export function CancellationFlow({ onAfterClose }: { onAfterClose?: () => void }) {
  const {
    subscription,
    step,
    method,
    guideStepIndex,
    feeCents,
    annualSavingsCents,
    setMethod,
    nextGuideStep,
    prevGuideStep,
    confirmWaiting,
    confirmDone,
    fail,
    close,
  } = useCancellationStore();

  const handleClose = () => {
    close();
    onAfterClose?.();
  };

  // Simula la llegada del email de confirmación (en producción: detección real).
  const [waiting, setWaiting] = useState(false);
  useEffect(() => {
    if (step === "waiting" && !waiting) {
      setWaiting(true);
      const t = setTimeout(() => confirmDone(), 3000);
      return () => clearTimeout(t);
    }
  }, [step, waiting, confirmDone]);

  if (!subscription) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/40 sm:items-center"
      role="dialog"
      aria-modal="true"
      aria-label="Cancelación"
      onClick={step === "confirmed" ? handleClose : undefined}
    >
      <div
        className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-t-3xl bg-white p-6 sm:rounded-3xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold">
            {step === "confirmed" ? "¡Listo!" : `Cancelar ${subscription.merchant}`}
          </h2>
          {step !== "waiting" ? (
            <button
              type="button"
              onClick={handleClose}
              className="grid size-10 place-items-center rounded-lg text-slate-500 hover:bg-muted"
              aria-label="Cerrar"
            >
              <X className="size-5" aria-hidden />
            </button>
          ) : null}
        </div>

        {/* ===== 1. REVIEW: fee exacto ===== */}
        {step === "review" ? (
          <div className="mt-6">
            <div className="rounded-2xl border bg-white p-6">
              <p className="text-slate-700">
                Estás por cancelar{" "}
                <strong>
                  {subscription.merchant} ({formatMoney(subscription.amountCents, subscription.currency)}/mes)
                </strong>
                .
              </p>
              <dl className="mt-4 space-y-2 text-slate-700">
                <div className="flex justify-between border-b pb-2">
                  <dt>Ahorro estimado (año 1)</dt>
                  <dd className="font-bold">{formatMoney(annualSavingsCents, subscription.currency)}</dd>
                </div>
                <div className="flex justify-between">
                  <dt>Nuestro fee</dt>
                  <dd className="font-bold">{formatMoney(feeCents, subscription.currency)}</dd>
                </div>
              </dl>
              <p className="mt-4 rounded-lg bg-emerald-50 px-3 py-2 text-sm font-semibold text-emerald-800">
                Te cobramos {formatMoney(feeCents, subscription.currency)} SOLO si la baja se
                confirma. Si no se concreta, no pagás nada.
              </p>
            </div>

            <p className="mt-4 text-sm font-semibold text-slate-600">¿Cómo querés cancelarla?</p>
            <div className="mt-2 grid gap-2">
              {(
                [
                  { id: "self_service", icon: MousePointerClick, label: "Me guío paso a paso" },
                  { id: "letter", icon: FileText, label: "Generar carta de cancelación" },
                  { id: "concierge", icon: Headset, label: "Que me ayude una persona" },
                ] as const
              ).map(({ id, icon: Icon, label }) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => setMethod(id)}
                  className={`flex h-14 items-center gap-3 rounded-lg border px-4 text-left font-semibold transition-colors ${
                    method === id ? "border-primary bg-primary/5" : "hover:bg-muted"
                  }`}
                >
                  <Icon className="size-5 text-primary" aria-hidden />
                  {label}
                </button>
              ))}
            </div>

            <Button
              size="lg"
              className="mt-6 w-full"
              onClick={() => (method === "concierge" ? confirmWaiting() : setStepGuide())}
            >
              Confirmar y cancelar
            </Button>
          </div>
        ) : null}

        {/* ===== 2. GUIDE: pasos ===== */}
        {step === "guide" ? (
          <div className="mt-6">
            <p className="text-sm text-slate-600">
              Paso {guideStepIndex + 1} de {GUIDE_STEPS.length}
            </p>
            <div className="mt-2 rounded-2xl border bg-white p-6">
              <h3 className="text-lg font-bold">{GUIDE_STEPS[guideStepIndex].title}</h3>
              <p className="mt-2 text-slate-700">{GUIDE_STEPS[guideStepIndex].text}</p>
              <a
                href="https://example.com"
                target="_blank"
                rel="noopener noreferrer"
                className="mt-3 inline-flex items-center gap-2 font-semibold text-primary hover:underline"
              >
                Abrir la página del servicio <ExternalLink className="size-4" aria-hidden />
              </a>
            </div>
            <div className="mt-6 flex gap-2">
              {guideStepIndex > 0 ? (
                <Button variant="outline" size="lg" className="flex-1" onClick={prevGuideStep}>
                  Anterior
                </Button>
              ) : null}
              {guideStepIndex < GUIDE_STEPS.length - 1 ? (
                <Button size="lg" className="flex-1" onClick={nextGuideStep}>
                  Ya lo hice, siguiente
                </Button>
              ) : (
                <Button size="lg" variant="success" className="flex-1" onClick={confirmWaiting}>
                  Listo, ya la cancelé
                </Button>
              )}
            </div>
          </div>
        ) : null}

        {/* ===== 3. WAITING: esperando confirmación ===== */}
        {step === "waiting" ? (
          <div className="mt-8 py-6 text-center">
            <Loader2 className="mx-auto size-12 animate-spin text-primary" aria-hidden />
            <h3 className="mt-4 text-xl font-bold">Verificando la cancelación…</h3>
            <p className="mx-auto mt-2 max-w-sm text-slate-700">
              Estamos revisando tu correo por el email de confirmación de la baja.
            </p>
            <p className="mt-2 text-sm text-slate-600" aria-live="polite">
              Esto toma unos segundos.
            </p>
          </div>
        ) : null}

        {/* ===== 4. CONFIRMED ===== */}
        {step === "confirmed" ? (
          <div className="mt-8 py-4 text-center">
            <CheckCircle2 className="mx-auto size-16 text-success" aria-hidden />
            <h3 className="mt-4 text-2xl font-extrabold">
              ¡Cancelada! Vas a ahorrar {formatMoney(annualSavingsCents, subscription.currency)}/año
            </h3>
            <p className="mx-auto mt-3 max-w-sm text-slate-700">
              Detectamos el correo de confirmación de la baja. Te cobramos{" "}
              <strong>{formatMoney(feeCents, subscription.currency)}</strong> solo porque el
              ahorro se confirmó.
            </p>
            <Button size="lg" className="mt-6 w-full" onClick={handleClose}>
              Ver mi ahorro
            </Button>
          </div>
        ) : null}

        {/* ===== 5. FAILED ===== */}
        {step === "failed" ? (
          <div className="mt-8 py-4 text-center">
            <h3 className="text-xl font-bold">No pudimos confirmar la baja</h3>
            <p className="mx-auto mt-2 max-w-sm text-slate-700">
              Este servicio puede requerir otro método de cancelación. No te cobramos nada.
            </p>
            <div className="mt-6 flex gap-2">
              <Button variant="outline" size="lg" className="flex-1" onClick={handleClose}>
                Volver
              </Button>
              <Button size="lg" className="flex-1" onClick={() => setMethod("concierge")}>
                Pedir ayuda
              </Button>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );

  function setStepGuide() {
    useCancellationStore.setState({ step: "guide", guideStepIndex: 0 });
  }
}
