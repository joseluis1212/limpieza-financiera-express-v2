/**
 * Configuración central del sitio.
 * El copy vive acá para facilitar la localización por país (es-AR, es-MX, en-US).
 */
export const siteConfig = {
  name: "Limpieza Financiera Express",
  tagline: "Te recuperamos el dinero que estás tirando todos los meses",
  description:
    "Encontrá y cancelá tus suscripciones olvidadas. Solo cobramos si te ahorramos dinero.",
  url: "https://limpieza-financiera-express.com",
  contactEmail: "hola@limpieza-financiera-express.com",
  nav: [
    { label: "Cómo funciona", href: "#como-funciona" },
    { label: "Precios", href: "#precios" },
    { label: "Preguntas", href: "#preguntas" },
  ],
  /** Fee por país (success fee). */
  fees: {
    ar: { rate: 0.3, label: "30%", currency: "ARS", fixedPrice: "24.900" },
    mx: { rate: 0.35, label: "35%", currency: "MXN" },
    us: { rate: 0.4, label: "40%", currency: "USD" },
  },
} as const;
