import { relations } from "drizzle-orm";
import {
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
  uuid,
} from "drizzle-orm/pg-core";

/**
 * Schema de persistencia (PostgreSQL / Drizzle).
 *
 * Principio rector: NUNCA almacenar el cuerpo de los emails — solo metadatos
 * (remitente, asunto, snippet) y entidades extraídas.
 */

export type Finding = {
  merchant: string;
  amountCents: number | null;
  currency: string | null;
  recurrence: string;
  isTrial: boolean;
  category: string | null;
  confidence: "high" | "medium" | "low";
};

// ---- Usuarios ----

export const profiles = pgTable("profiles", {
  id: uuid("id").primaryKey(), // == auth.users.id
  email: text("email").notNull(),
  fullName: text("full_name"),
  avatarUrl: text("avatar_url"),
  country: text("country").default("AR").notNull(), // AR | MX | US
  locale: text("locale").default("es-AR").notNull(),
  feeRate: integer("fee_rate").default(30).notNull(), // 30 = 30%
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

// ---- Conexiones a proveedores de email ----

export const providerConnections = pgTable(
  "provider_connections",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => profiles.id, { onDelete: "cascade" }),
    provider: text("provider").notNull(), // 'gmail' | 'outlook'
    providerUserId: text("provider_user_id").notNull(),
    connectedAt: timestamp("connected_at", { withTimezone: true }).defaultNow().notNull(),
    revokedAt: timestamp("revoked_at", { withTimezone: true }),
  },
  (table) => ({
    userProviderUnique: index("provider_connections_user_provider_unique").on(
      table.userId,
      table.provider,
    ),
  }),
);

// ---- Índice de emails (SOLO metadatos, nunca el cuerpo) ----

export const emailsIndex = pgTable(
  "emails_index",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => profiles.id, { onDelete: "cascade" }),
    provider: text("provider").notNull(),
    providerMessageId: text("provider_message_id").notNull(),
    fromAddress: text("from_address").notNull(),
    subject: text("subject"),
    snippet: text("snippet"), // max ~150 chars
    receivedAt: timestamp("received_at", { withTimezone: true }).notNull(),
    isFinancial: boolean("is_financial").default(false).notNull(),
    scannedAt: timestamp("scanned_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    providerMessageUnique: index("emails_index_provider_message_unique").on(
      table.providerMessageId,
    ),
    userReceivedIdx: index("emails_index_user_received_idx").on(
      table.userId,
      table.receivedAt,
    ),
  }),
);

// ---- Suscripciones (deduplicadas) ----

export const subscriptions = pgTable(
  "subscriptions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => profiles.id, { onDelete: "cascade" }),
    merchant: text("merchant").notNull(),
    category: text("category").default("other").notNull(),
    amountCents: integer("amount_cents").notNull(),
    currency: text("currency").notNull(),
    recurrence: text("recurrence").notNull(), // monthly | annual | weekly | trial | one_time
    status: text("status").default("active").notNull(), // active | forgotten | trial | canceled
    confidence: text("confidence").default("medium").notNull(),
    lastChargedAt: timestamp("last_charged_at", { withTimezone: true }),
    nextExpectedAt: timestamp("next_expected_at", { withTimezone: true }),
    trialEndsAt: timestamp("trial_ends_at", { withTimezone: true }),
    findings: jsonb("findings").$type<Finding[]>().default([]).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    userStatusIdx: index("subscriptions_user_status_idx").on(table.userId, table.status),
    userMerchantIdx: index("subscriptions_user_merchant_idx").on(
      table.userId,
      table.merchant,
    ),
  }),
);

// ---- Cargos individuales (alimentan la dedupe) ----

export const subscriptionCharges = pgTable(
  "subscription_charges",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    subscriptionId: uuid("subscription_id")
      .notNull()
      .references(() => subscriptions.id, { onDelete: "cascade" }),
    amountCents: integer("amount_cents").notNull(),
    currency: text("currency").notNull(),
    chargedAt: timestamp("charged_at", { withTimezone: true }).notNull(),
    emailId: uuid("email_id").references(() => emailsIndex.id, { onDelete: "set null" }),
  },
  (table) => ({
    subscriptionDateIdx: index("charges_subscription_date_idx").on(
      table.subscriptionId,
      table.chargedAt,
    ),
  }),
);

// ---- Relaciones ----

export const profilesRelations = relations(profiles, ({ many }) => ({
  connections: many(providerConnections),
  emails: many(emailsIndex),
  subscriptions: many(subscriptions),
}));

export const subscriptionsRelations = relations(subscriptions, ({ many }) => ({
  charges: many(subscriptionCharges),
}));

export const emailsRelations = relations(emailsIndex, ({ one }) => ({
  profile: one(profiles, { fields: [emailsIndex.userId], references: [profiles.id] }),
}));

export const subscriptionChargesRelations = relations(subscriptionCharges, ({ one }) => ({
  subscription: one(subscriptions, {
    fields: [subscriptionCharges.subscriptionId],
    references: [subscriptions.id],
  }),
}));
