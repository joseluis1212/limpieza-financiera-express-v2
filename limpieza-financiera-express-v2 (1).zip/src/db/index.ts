import { drizzle, type NodePgDatabase } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import * as schema from "./schema";

/**
 * Cliente de base de datos (PostgreSQL vía node-postgres).
 *
 * - Lazy: el pool se crea solo en la primera query (no rompe el build ni el
 *   arranque si DATABASE_URL no está definida).
 * - En serverless/edge, usar el pooler de Supabase (puerto 6543, modo Transaction).
 */

const globalForDb = globalThis as typeof globalThis & {
  __lfePool?: Pool;
};

function createPool(): Pool {
  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl) {
    throw new Error(
      "DATABASE_URL no está configurada. Definí la cadena de conexión pooled de Supabase (puerto 6543).",
    );
  }
  return new Pool({
    connectionString: databaseUrl,
    max: 10,
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: 8_000,
  });
}

function getPool(): Pool {
  if (!globalForDb.__lfePool) {
    globalForDb.__lfePool = createPool();
  }
  return globalForDb.__lfePool;
}

/**
 * Instancia de Drizzle tipada. Lanza error descriptivo SOLO al usarse sin
 * DATABASE_URL (nunca al importar).
 */
export const db = new Proxy(
  {} as NodePgDatabase<typeof schema>,
  {
    get(_target, prop) {
      const instance = drizzle(getPool(), { schema });
      return instance[prop as keyof typeof instance];
    },
  },
);

export { schema };
