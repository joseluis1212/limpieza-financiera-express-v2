/**
 * Tipos compartidos del dominio.
 */

export type Recurrence = "monthly" | "annual" | "weekly" | "trial" | "one_time";

export type Confidence = "high" | "medium" | "low";

export type SubscriptionStatus = "active" | "forgotten" | "trial" | "canceled";

export type Subscription = {
  id: string;
  merchant: string;
  category: string;
  amountCents: number;
  currency: "ARS" | "MXN" | "USD";
  recurrence: Recurrence;
  status: SubscriptionStatus;
  confidence: Confidence;
  lastChargedAt?: string;
  nextExpectedAt?: string;
  /** Solo para trials: fecha en que se cobrará. */
  trialEndsAt?: string;
  /** Detección de "sin uso" (si aplica). */
  unusedMonths?: number;
};

export type SavingsSummary = {
  monthlyCents: number;
  annualCents: number;
  currency: Subscription["currency"];
  subscriptionsCount: number;
  forgottenCount: number;
  trialsCount: number;
};
