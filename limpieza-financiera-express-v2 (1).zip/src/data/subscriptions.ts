import type { Subscription } from "@/types";

/**
 * Datos de ejemplo (mock) para el flujo. En producción esto viene de la API
 * (`GET /subscriptions`) poblada por el motor de detección.
 *
 * Montos en centavos. Argentina usa ARS, México MXN, USA USD.
 */
export const mockSubscriptions: Subscription[] = [
  {
    id: "sub_netflix",
    merchant: "Netflix",
    category: "streaming",
    amountCents: 999000, // ARS 9.990
    currency: "ARS",
    recurrence: "monthly",
    status: "active",
    confidence: "high",
    lastChargedAt: "2026-08-05",
    nextExpectedAt: "2026-09-05",
  },
  {
    id: "sub_editor",
    merchant: "AppDeEdición",
    category: "software",
    amountCents: 1500, // USD 15
    currency: "USD",
    recurrence: "monthly",
    status: "forgotten",
    confidence: "high",
    lastChargedAt: "2026-07-12",
    nextExpectedAt: "2026-08-12",
    unusedMonths: 4,
  },
  {
    id: "sub_gym",
    merchant: "GymApp",
    category: "fitness",
    amountCents: 1499000, // ARS 14.990
    currency: "ARS",
    recurrence: "trial",
    status: "trial",
    confidence: "high",
    trialEndsAt: "2026-09-01",
    nextExpectedAt: "2026-09-01",
  },
  {
    id: "sub_cloud",
    merchant: "NubeCloud",
    category: "cloud_storage",
    amountCents: 999, // USD 9.99
    currency: "USD",
    recurrence: "monthly",
    status: "forgotten",
    confidence: "medium",
    lastChargedAt: "2026-07-20",
    nextExpectedAt: "2026-08-20",
    unusedMonths: 3,
  },
  {
    id: "sub_music",
    merchant: "MúsicaPlus",
    category: "streaming",
    amountCents: 34900, // MXN 349
    currency: "MXN",
    recurrence: "monthly",
    status: "active",
    confidence: "high",
    lastChargedAt: "2026-08-01",
    nextExpectedAt: "2026-09-01",
  },
  {
    id: "sub_news",
    merchant: "DiarioDigital",
    category: "news",
    amountCents: 89900, // MXN 899
    currency: "MXN",
    recurrence: "annual",
    status: "forgotten",
    confidence: "medium",
    lastChargedAt: "2026-01-15",
    nextExpectedAt: "2027-01-15",
    unusedMonths: 6,
  },
];
