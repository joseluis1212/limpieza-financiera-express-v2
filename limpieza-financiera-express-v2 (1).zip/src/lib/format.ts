/**
 * Formateo de montos y fechas para todo el flujo.
 */

type Currency = "ARS" | "MXN" | "USD";

const LOCALES: Record<Currency, string> = {
  ARS: "es-AR",
  MXN: "es-MX",
  USD: "en-US",
};

const ZERO_DECIMAL = new Set(["ARS", "MXN"]);

/** Formatea centavos a moneda local. ARS/MXN sin decimales; USD con 2. */
export function formatMoney(cents: number, currency: Currency): string {
  const decimals = ZERO_DECIMAL.has(currency) ? 0 : 2;
  return new Intl.NumberFormat(LOCALES[currency], {
    style: "currency",
    currency,
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }).format(cents / 100);
}

/** Formatea una fecha ISO a formato legible (ej. "5 ago 2026"). */
export function formatDate(iso?: string): string {
  if (!iso) return "—";
  return new Intl.DateTimeFormat("es-ES", {
    day: "numeric",
    month: "short",
    year: "numeric",
  }).format(new Date(iso));
}

/** Formatea solo día y mes (ej. "05/09"). */
export function formatDayMonth(iso?: string): string {
  if (!iso) return "—";
  return new Intl.DateTimeFormat("es-ES", {
    day: "2-digit",
    month: "2-digit",
  }).format(new Date(iso));
}
