/**
 * Agrupación y deduplicación: convierte cargos individuales en suscripciones
 * únicas por comercio, infiriendo recurrencia a partir de la serie de fechas.
 */

import type { Charge, Currency, Recurrence } from "./types";
import type { Subscription } from "@/types";

const DAY = 24 * 60 * 60 * 1000;

/** Normaliza el nombre del comercio para agrupar (canónico, minúsculas). */
function normalizeMerchant(merchant: string): string {
  return merchant.toLowerCase().replace(/^www\./, "").trim();
}

/** Infiere recurrencia a partir de intervalos entre cargos (en días). */
function inferRecurrenceFromDates(dates: number[]): Recurrence {
  if (dates.length < 2) return "one_time";
  const intervals = dates
    .slice(1)
    .map((d, i) => Math.abs(d - dates[i]) / DAY)
    .filter((x) => x > 0);

  if (intervals.length === 0) return "one_time";

  const median = intervals.sort((a, b) => a - b)[Math.floor(intervals.length / 2)];

  if (median >= 300 && median <= 420) return "annual";
  if (median >= 24 && median <= 38) return "monthly";
  if (median >= 5 && median <= 9) return "weekly";
  return "one_time";
}

/**
 * Agrupa cargos en suscripciones únicas.
 * - Deduplica por merchant (nombre normalizado).
 * - Recurrencia: señales del texto o inferida por fechas.
 * - Monto mensual: mediana de los cargos (ignora outliers de promociones).
 */
export function groupChargesIntoSubscriptions(charges: Charge[]): Subscription[] {
  const byMerchant = new Map<string, Charge[]>();

  for (const charge of charges) {
    if (charge.cancelled) continue; // una cancelación no es una suscripción
    const key = normalizeMerchant(charge.merchant);
    const list = byMerchant.get(key) ?? [];
    list.push(charge);
    byMerchant.set(key, list);
  }

  const subscriptions: Subscription[] = [];

  for (const [merchant, list] of byMerchant) {
    // Recurrencia por texto (si hay) o por fechas.
    const textRecurrence = list.find((c) => c.recurrence !== "one_time")?.recurrence;
    const chargedDates = list
      .map((c) => (c.chargedAt ? new Date(c.chargedAt).getTime() : NaN))
      .filter((t) => Number.isFinite(t));

    const recurrence: Recurrence =
      list.some((c) => c.isTrial)
        ? "trial"
        : textRecurrence ?? inferRecurrenceFromDates(chargedDates);

    // Monto: mediana de los importes detectados (sin null).
    const amounts = list
      .map((c) => c.amountCents)
      .filter((a): a is number => a !== null)
      .sort((a, b) => a - b);
    const amountCents = amounts.length ? amounts[Math.floor(amounts.length / 2)] : 0;

    // Moneda: la más frecuente entre los cargos con monto.
    const currency = list.find((c) => c.currency && c.amountCents)?.currency ?? "USD";

    const lastChargedAt =
      chargedDates.length
        ? new Date(Math.max(...chargedDates)).toISOString()
        : undefined;

    const isTrial = recurrence === "trial";
    const trial = list.find((c) => c.isTrial);

    const confidence: Subscription["confidence"] = list.some((c) => c.confidence === "high")
      ? "high"
      : list.some((c) => c.confidence === "medium")
        ? "medium"
        : "low";

    subscriptions.push({
      id: `sub_${merchant.replace(/[^a-z0-9]/g, "_")}`,
      merchant: list[0].merchant,
      category: list.find((c) => c.category)?.category ?? "other",
      amountCents,
      currency: currency as "ARS" | "MXN" | "USD",
      recurrence,
      status: isTrial ? "trial" : "active",
      confidence,
      lastChargedAt,
      nextExpectedAt: isTrial ? trial?.trialEndDate ?? undefined : undefined,
      trialEndsAt: isTrial ? trial?.trialEndDate ?? undefined : undefined,
    });
  }

  return subscriptions.sort((a, b) => b.amountCents - a.amountCents);
}
