import { describe, expect, it } from "vitest";
import { groupChargesIntoSubscriptions } from "./dedupe";
import type { Charge } from "./types";

function charge(partial: Partial<Charge> & { merchant: string }): Charge {
  return {
    amountCents: null,
    currency: null,
    recurrence: "one_time",
    isTrial: false,
    trialEndDate: null,
    category: null,
    action: "charge",
    cancelled: false,
    confidence: "medium",
    source: "rules",
    emailId: "e1",
    chargedAt: null,
    ...partial,
  };
}

describe("groupChargesIntoSubscriptions", () => {
  it("agrupa cargos del mismo comercio en una sola suscripción", () => {
    const charges = [
      charge({ merchant: "netflix.com", amountCents: 1549, currency: "USD", chargedAt: "2026-07-05T00:00:00Z" }),
      charge({ merchant: "netflix.com", amountCents: 1549, currency: "USD", chargedAt: "2026-08-05T00:00:00Z" }),
      charge({ merchant: "spotify.com", amountCents: 999, currency: "USD", chargedAt: "2026-08-01T00:00:00Z" }),
    ];

    const subs = groupChargesIntoSubscriptions(charges);
    expect(subs).toHaveLength(2);
  });

  it("infiere recurrencia mensual por intervalo de fechas", () => {
    const charges = [
      charge({ merchant: "netflix.com", amountCents: 1549, chargedAt: "2026-06-05T00:00:00Z" }),
      charge({ merchant: "netflix.com", amountCents: 1549, chargedAt: "2026-07-05T00:00:00Z" }),
      charge({ merchant: "netflix.com", amountCents: 1549, chargedAt: "2026-08-05T00:00:00Z" }),
    ];
    const [sub] = groupChargesIntoSubscriptions(charges);
    expect(sub.recurrence).toBe("monthly");
  });

  it("marca como trial cuando hay señal de trial", () => {
    const charges = [
      charge({
        merchant: "gymapp.com",
        isTrial: true,
        recurrence: "trial",
        trialEndDate: "2026-09-01",
      }),
    ];
    const [sub] = groupChargesIntoSubscriptions(charges);
    expect(sub.status).toBe("trial");
    expect(sub.trialEndsAt).toBe("2026-09-01");
  });

  it("ignora las cancelaciones (no generan suscripción)", () => {
    const charges = [charge({ merchant: "adobe.com", cancelled: true })];
    expect(groupChargesIntoSubscriptions(charges)).toHaveLength(0);
  });

  it("usa la mediana del monto para ignorar outliers", () => {
    const charges = [
      charge({ merchant: "netflix.com", amountCents: 100, chargedAt: "2026-06-05T00:00:00Z" }), // promo
      charge({ merchant: "netflix.com", amountCents: 1549, chargedAt: "2026-07-05T00:00:00Z" }),
      charge({ merchant: "netflix.com", amountCents: 1549, chargedAt: "2026-08-05T00:00:00Z" }),
    ];
    const [sub] = groupChargesIntoSubscriptions(charges);
    expect(sub.amountCents).toBe(1549);
  });
});
