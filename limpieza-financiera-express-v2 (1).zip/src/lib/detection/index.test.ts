import { describe, expect, it } from "vitest";
import { detectSubscriptions } from "./index";
import { mockEmails } from "./mock-emails";

describe("detectSubscriptions (end-to-end, sin LLM)", () => {
  it("descarta correos no financieros y detecta suscripciones", async () => {
    const result = await detectSubscriptions(mockEmails, { useLlm: false });

    // 9 emails, 1 no financiero ("Reunión del viernes") y 1 cancelación (Adobe).
    expect(result.emailsScanned).toBe(9);
    expect(result.emailsFinancial).toBe(8);

    // Suscripciones esperadas: Netflix, AppDeEdición, GymApp (trial),
    // NubeCloud, MúsicaPlus, DiarioDigital = 6 (Adobe es cancelación).
    expect(result.subscriptions.length).toBe(6);

    const merchants = result.subscriptions.map((s) => s.merchant.toLowerCase());
    expect(merchants).toContain("netflix.com");
    expect(merchants).toContain("gymapp.com");
    expect(merchants).not.toContain("adobe.com"); // cancelación, no suscripción
  });

  it("deduplica Netflix (2 cargos) en una sola suscripción", async () => {
    const result = await detectSubscriptions(mockEmails, { useLlm: false });
    const netflix = result.subscriptions.find((s) => s.merchant.toLowerCase() === "netflix.com");
    expect(netflix).toBeDefined();
    expect(netflix?.amountCents).toBe(999000); // ARS 9.990
    expect(netflix?.currency).toBe("ARS");
    expect(netflix?.recurrence).toBe("monthly");
  });

  it("detecta el trial de GymApp con fecha de cobro", async () => {
    const result = await detectSubscriptions(mockEmails, { useLlm: false });
    const gym = result.subscriptions.find((s) => s.merchant.toLowerCase() === "gymapp.com");
    expect(gym?.status).toBe("trial");
    expect(gym?.trialEndsAt).toBe("2026-09-01");
  });
});
