import type { EmailMetadata } from "@/lib/detection/types";

/**
 * Emails de ejemplo (metadata) para desarrollo y tests del motor.
 * En producción estos datos vienen de Gmail/Graph API (scope readonly).
 *
 * Los correos están pensados para que el motor produzca las mismas
 * suscripciones que `src/data/subscriptions.ts` (consistencia de demo → real).
 */
export const mockEmails: EmailMetadata[] = [
  {
    id: "m1",
    providerMessageId: "p1",
    from: "Netflix <info@netflix.com>",
    subject: "Tu plan de Netflix fue renovado",
    snippet: "Tu plan mensual de $9.990 ARS fue cobrado hoy. Gracias por ser miembro.",
    receivedAt: "2026-08-05T12:00:00Z",
  },
  {
    id: "m2",
    providerMessageId: "p2",
    from: "Netflix <info@netflix.com>",
    subject: "Tu factura de Netflix",
    snippet: "Se renovó tu plan mensual de ARS 9.990. Gracias por ser miembro.",
    receivedAt: "2026-07-05T12:00:00Z",
  },
  {
    id: "m3",
    providerMessageId: "p3",
    from: "AppDeEdición <billing@appedicion.com>",
    subject: "Your AppDeEdición invoice",
    snippet: "Your monthly plan of $15.00 was charged. You have not logged in for 4 months.",
    receivedAt: "2026-07-12T12:00:00Z",
  },
  {
    id: "m4",
    providerMessageId: "p4",
    from: "GymApp <no-reply@gymapp.com>",
    subject: "Tu prueba gratuita de 7 días termina pronto",
    snippet: "Tu prueba gratis termina el 2026-09-01. Después se te cobrará $14.990 ARS al mes.",
    receivedAt: "2026-08-25T12:00:00Z",
  },
  {
    id: "m5",
    providerMessageId: "p5",
    from: "NubeCloud <billing@nubecloud.com>",
    subject: "Receipt for NubeCloud",
    snippet: "Your monthly subscription of $9.99 has been charged.",
    receivedAt: "2026-07-20T12:00:00Z",
  },
  {
    id: "m6",
    providerMessageId: "p6",
    from: "MúsicaPlus <info@musicaplus.com>",
    subject: "Tu suscripción mensual fue renovada",
    snippet: "Tu plan mensual de $349 MXN fue cobrado hoy. Gracias por tu membresía.",
    receivedAt: "2026-08-01T12:00:00Z",
  },
  {
    id: "m7",
    providerMessageId: "p7",
    from: "DiarioDigital <suscripciones@diariodigital.com>",
    subject: "Renovación anual de tu suscripción",
    snippet: "Tu plan anual de $899 MXN ha sido renovado por un año más.",
    receivedAt: "2026-01-15T12:00:00Z",
  },
  // No financiero: el motor debe descartarlo.
  {
    id: "m8",
    providerMessageId: "p8",
    from: "Amigo <juan@gmail.com>",
    subject: "Reunión del viernes",
    snippet: "Hola, te confirmo la reunión del viernes a las 15hs.",
    receivedAt: "2026-08-10T12:00:00Z",
  },
  // Confirmación de cancelación: no es un cargo, es una señal de ahorro.
  {
    id: "m9",
    providerMessageId: "p9",
    from: "Adobe <billing@adobe.com>",
    subject: "We've cancelled your subscription",
    snippet: "Your plan has been cancelled. You will not be charged again.",
    receivedAt: "2026-08-18T12:00:00Z",
  },
];
