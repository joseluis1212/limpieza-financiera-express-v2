/**
 * Motor de reglas deterministas: rápido, barato y auditable.
 * Filtra correos no financieros (absorbe ~80% del volumen) y extrae
 * monto / moneda / comercio sin LLM.
 */

import type { Currency } from "./types";

// ---- Señales ----

const SUBSCRIPTION_SIGNALS = [
  /subscription/i,
  /suscripci[oó]n/i,
  /renovaci[oó]n/i,
  /renewal/i,
  /recurring/i,
  /recurrente/i,
  /membership/i,
  /membres[ií]a/i,
  /trial/i,
  /prueba gratuita/i,
  /plan mensual/i,
  /plan anual/i,
];

const INVOICE_SIGNALS = [
  /invoice/i,
  /factura/i,
  /receipt/i,
  /recibo/i,
  /payment/i,
  /pago/i,
  /charged/i,
  /cargo/i,
  /billing/i,
  /cobro/i,
];

const CANCELLATION_SIGNALS = [
  /cancell?ed/i,
  /cancelad[oa]/i,
  /hemos cancelado/i,
  /suscripci[oó]n.*cancel/i,
  /subscription.*cancel/i,
  /no longer be charged/i,
  /no se te volverá a cobrar/i,
];

/** ¿El email contiene señales financieras? (filtro previo, barato). */
export function isFinancial(text: string): boolean {
  return [...SUBSCRIPTION_SIGNALS, ...INVOICE_SIGNALS].some((r) => r.test(text));
}

/** ¿El email es una confirmación de cancelación? (dispara la verificación de ahorro). */
export function isCancellation(text: string): boolean {
  return CANCELLATION_SIGNALS.some((r) => r.test(text));
}

// ---- Extracción de monto y moneda ----

const CURRENCY_PATTERN = "(USD|US\\$|EUR|MXN|COP|ARS|CLP|\\$|€)";
const NUMBER_PATTERN =
  "([0-9]{1,3}(?:[.,][0-9]{3})*(?:[.,][0-9]{1,2})?|[0-9]+(?:[.,][0-9]{1,2})?)";

function numberPartToValue(numberPart: string): number | null {
  const hasComma = numberPart.includes(",");
  const hasDot = numberPart.includes(".");
  let value: number;

  if (hasComma && hasDot) {
    const lastComma = numberPart.lastIndexOf(",");
    const lastDot = numberPart.lastIndexOf(".");
    value =
      lastComma > lastDot
        ? parseFloat(numberPart.replace(/\./g, "").replace(",", ".")) // 1.234,56
        : parseFloat(numberPart.replace(/,/g, "")); // 1,234.56
  } else if (hasComma) {
    const trailing = numberPart.split(",").pop() ?? "";
    value =
      trailing.length > 0 && trailing.length <= 2
        ? parseFloat(numberPart.replace(/,/g, "."))
        : parseFloat(numberPart.replace(/,/g, ""));
  } else {
    const trailing = numberPart.split(".").pop() ?? "";
    value =
      hasDot && trailing.length === 3
        ? parseFloat(numberPart.replace(/\./g, "")) // miles con punto
        : parseFloat(numberPart);
  }

  return Number.isFinite(value) ? value : null;
}

/** Extrae el monto en centavos. Acepta moneda antes o después del número. */
export function extractAmountCents(text: string): number | null {
  let numberPart: string | null = null;

  const before = new RegExp(`${CURRENCY_PATTERN}\\s?${NUMBER_PATTERN}`, "i").exec(text);
  if (before?.[2]) {
    numberPart = before[2];
  } else {
    const after = new RegExp(`${NUMBER_PATTERN}\\s?${CURRENCY_PATTERN}`, "i").exec(text);
    if (after?.[1]) numberPart = after[1];
  }

  if (!numberPart) return null;
  const value = numberPartToValue(numberPart.replace(/\s/g, ""));
  return value === null ? null : Math.round(value * 100);
}

function normalizeCurrency(raw: string | undefined): Currency {
  if (!raw) return "USD";
  const upper = raw.toUpperCase();
  if (upper === "US$" || upper === "$") return "USD";
  if (upper === "€") return "EUR";
  return upper;
}

// Códigos ISO explícitos (sin ambigüedad). Se buscan ANTES que los símbolos.
const ISO_CURRENCIES = ["USD", "EUR", "ARS", "MXN", "COP", "CLP", "GBP", "BRL", "UYU"] as const;

/**
 * Devuelve el código de moneda detectado, o null.
 * Prioriza el código ISO explícito ("ARS", "MXN") sobre el símbolo ambiguo
 * ("$" puede ser USD o ARS según el contexto).
 */
export function extractCurrency(text: string): Currency | null {
  const upper = text.toUpperCase();
  for (const code of ISO_CURRENCIES) {
    if (new RegExp(`\\b${code}\\b`).test(upper)) return code;
  }
  // Fallback: símbolos (US$, $, €).
  const match = text.match(new RegExp(CURRENCY_PATTERN, "i"));
  return match ? normalizeCurrency(match[1]) : null;
}

/**
 * Extrae una fecha del texto (ISO "2026-09-01" o "01/09/2026"),
 * normalizada a ISO. Útil para la fecha de fin de trial sin LLM.
 */
export function extractDate(text: string): string | null {
  const iso = text.match(/\b(\d{4})-(\d{2})-(\d{2})\b/);
  if (iso) return `${iso[1]}-${iso[2]}-${iso[3]}`;

  const dmy = text.match(/\b(\d{1,2})[/-](\d{1,2})[/-](\d{4})\b/);
  if (dmy) {
    const [, d, m, y] = dmy;
    return `${y}-${m.padStart(2, "0")}-${d.padStart(2, "0")}`;
  }
  return null;
}

// ---- Extracción de comercio (dominio) ----

const NOISE_SUBDOMAINS = new Set([
  "mail", "notifications", "notification", "no-reply", "noreply", "accounts",
  "account", "billing", "payments", "payment", "news", "newsletter", "info",
  "hello", "team", "support", "updates", "emails", "email", "transactional", "app",
]);

const TWO_PART_TLDS = new Set([
  "com.ar", "com.mx", "com.br", "com.co", "com.au", "co.uk", "co.nz", "co.jp",
  "com.pe", "com.uy", "com.cl", "net.ar", "org.ar", "gob.ar",
]);

/** Extrae el dominio registrable de una dirección "From". */
export function extractDomain(from: string): string | null {
  const emailMatch = from.match(/<([^>]+)>/);
  const email = emailMatch?.[1] ?? from;
  if (!email.includes("@")) return null;

  const domain = email.split("@").at(-1)?.toLowerCase().trim();
  if (!domain) return null;

  const labels = domain.split(".").filter(Boolean);
  while (labels.length > 2 && NOISE_SUBDOMAINS.has(labels[0])) {
    labels.shift();
  }

  if (labels.length >= 3) {
    const lastTwo = labels.slice(-2).join(".");
    if (TWO_PART_TLDS.has(lastTwo)) {
      return labels.slice(-3).join(".");
    }
  }

  return labels.slice(-2).join(".");
}

/** Nombre del comercio: dominio limpio, o primera parte del asunto. */
export function extractMerchant(from: string, subject: string): string {
  const domain = extractDomain(from);
  if (domain) return domain;
  return subject.split(/[—\-:|]/)[0]?.trim().slice(0, 60) || "Comercio desconocido";
}

/** Infiere recurrencia desde el texto (señales simples). */
export function inferRecurrenceFromText(text: string): "monthly" | "annual" | "weekly" | "trial" | "one_time" {
  if (/prueba gratuita|free trial|trial|first month free/i.test(text)) return "trial";
  if (/anual|annual|per year|\/año|\/year/i.test(text)) return "annual";
  if (/semanal|weekly|per week|\/semana/i.test(text)) return "weekly";
  if (/mensual|monthly|per month|\/mes|\/month/i.test(text)) return "monthly";
  return "one_time";
}
