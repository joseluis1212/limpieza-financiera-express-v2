/**
 * Cliente LLM para extracción semántica.
 *
 * - Usa un endpoint compatible con OpenAI (Chat Completions).
 * - Valida la salida con zod (structured output manual).
 * - Si no hay OPENAI_API_KEY, devuelve null: el motor sigue funcionando
 *   SOLO con reglas (degradación elegante, sin romper el build).
 */

import { z } from "zod";
import { buildMessages } from "./prompt";

const extractionSchema = z.object({
  is_financial: z.boolean(),
  merchant: z.string().nullable(),
  amount: z.string().nullable(),
  currency: z.string().nullable(),
  recurrence_type: z.string().nullable(),
  is_trial: z.boolean(),
  trial_end_date: z.string().nullable(),
  next_charge_date: z.string().nullable(),
  category: z.string().nullable(),
  action: z.string(),
  cancelled: z.boolean(),
  confidence: z.enum(["high", "medium", "low"]),
});

export type LlmExtraction = z.infer<typeof extractionSchema>;

function isConfigured(): boolean {
  return Boolean(process.env.OPENAI_API_KEY);
}

/** Convierte el string "amount" a centavos, o null. */
function amountToCents(amount: string | null): number | null {
  if (!amount) return null;
  const value = Number.parseFloat(amount);
  return Number.isFinite(value) ? Math.round(value * 100) : null;
}

/**
 * Extrae datos de un email con el LLM. Devuelve null si no está configurado,
 * si el modelo responde que no es financiero, o si la respuesta es inválida.
 */
export async function extractWithLlm(email: {
  subject: string;
  from: string;
  snippet: string;
}): Promise<LlmExtraction | null> {
  if (!isConfigured()) return null;

  try {
    const response = await fetch(
      process.env.OPENAI_BASE_URL ?? "https://api.openai.com/v1/chat/completions",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
        },
        body: JSON.stringify({
          model: process.env.OPENAI_MODEL ?? "gpt-4o-mini",
          messages: buildMessages(email),
          temperature: 0,
          response_format: { type: "json_object" },
        }),
      },
    );

    if (!response.ok) {
      return null; // degradación: seguir con reglas
    }

    const data = (await response.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    const content = data.choices?.[0]?.message?.content;
    if (!content) return null;

    const parsed = extractionSchema.safeParse(JSON.parse(content));
    return parsed.success ? parsed.data : null;
  } catch {
    return null;
  }
}

export { amountToCents };
