# Motor de Detección — Documentación técnica

El motor convierte **metadatos de emails** (remitente, asunto, snippet — nunca el cuerpo
completo) en **suscripciones deduplicadas**.

## Arquitectura

```
src/lib/detection/
├── types.ts        # tipos del dominio (EmailMetadata, Charge, ...)
├── rules.ts        # reglas deterministas: filtro + extracción (monto, moneda, dominio, fecha)
├── prompt.ts       # prompt EXACTO del LLM (system + few-shot + schema)
├── llm.ts          # cliente LLM (OpenAI-compatible) con validación zod y degradación
├── dedupe.ts       # agrupación y deduplicación de cargos → suscripciones
├── index.ts        # orquestador: pipeline completo + fusión rules ⊕ LLM
└── mock-emails.ts  # emails de ejemplo para dev/tests
```

## Pipeline

```
1. Filtro de reglas (isFinancial)      → descarta ~80% (no financieros)
2. Extracción determinista (rules)     → monto, moneda, dominio, fecha
3. Extracción LLM (extractWithLlm)     → clasificación semántica (opcional)
4. Fusión (fuseCharge)                 → rules gana en montos; LLM en semántica
5. Deduplicación (groupCharges...)     → cargos → suscripciones únicas
```

## Decisiones clave

- **Reglas primero, LLM después.** Las reglas son baratas, audibles y deterministas; el LLM
  resuelve ambigüedades (moneda de "$", categoría, trials). Sin `OPENAI_API_KEY`, el motor
  **sigue funcionando solo con reglas** (degradación elegante, sin romper el build).
- **Las reglas ganan en montos** (son auditables); si hay empate se prioriza la regla.
- **Nunca se inventa data:** si un campo no está, es `null`. El LLM tiene instrucciones
  estrictas de no completar datos ausentes.
- **"$" es ambiguo:** las reglas priorizan el código ISO explícito ("ARS", "MXN"); el LLM usa
  el contexto del comercio para resolver "$" cuando no hay código.

## Configuración del LLM (env vars)

| Variable | Descripción | Default |
|---|---|---|
| `OPENAI_API_KEY` | Clave de la API (si no está, modo solo-reglas) | — |
| `OPENAI_MODEL` | Modelo a usar | `gpt-4o-mini` |
| `OPENAI_BASE_URL` | Endpoint compatible (para Anthropic/otro proxy) | `api.openai.com/v1` |

## Tests

```bash
npm run test   # 26 tests: rules (18), dedupe (5), integración (3)
```

Los tests cubren: filtro de señales, detección de cancelación, parser de montos (decimales,
miles con punto, moneda antes/después), prioridad ISO sobre símbolo, extracción de fechas,
dominio registrable (subdominios + TLDs de dos partes), deduplicación, inferencia de
recurrencia por intervalo, mediana de montos, y el pipeline end-to-end.

## Endpoint

`POST /api/scan` ejecuta el motor y devuelve las suscripciones. En producción debe:
1. autenticar (Supabase), 2. sincronizar emails del proveedor, 3. ejecutar el motor,
4. persistir en PostgreSQL.

## Nota de mejora (ya detectada por los tests)

Durante el desarrollo, los tests detectaron y se corrigieron:
- `extractCurrency` priorizaba el símbolo `$` sobre el código ISO explícito.
- Faltaba la extracción de fecha de fin de trial en el camino sin LLM.
- Interpretación de miles con punto ("$9.990" = 9.990 pesos, no 9.99).
