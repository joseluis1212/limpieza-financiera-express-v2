import { describe, expect, it } from "vitest";
import {
  extractAmountCents,
  extractCurrency,
  extractDate,
  extractDomain,
  extractMerchant,
  inferRecurrenceFromText,
  isCancellation,
  isFinancial,
} from "./rules";

describe("isFinancial", () => {
  it("detecta señales financieras", () => {
    expect(isFinancial("Your Netflix subscription has been renewed")).toBe(true);
    expect(isFinancial("Tu factura está disponible")).toBe(true);
    expect(isFinancial("Renovación de tu plan mensual")).toBe(true);
  });

  it("descarta correos no financieros", () => {
    expect(isFinancial("Reunión del viernes a las 15hs")).toBe(false);
    expect(isFinancial("Tu resumen semanal de noticias")).toBe(false);
  });
});

describe("isCancellation", () => {
  it("detecta confirmaciones de cancelación", () => {
    expect(isCancellation("We've cancelled your subscription")).toBe(true);
    expect(isCancellation("Tu suscripción ha sido cancelada")).toBe(true);
  });

  it("no marca un cargo como cancelación", () => {
    expect(isCancellation("Your subscription has been renewed")).toBe(false);
  });
});

describe("extractAmountCents", () => {
  it("parsea montos con decimales", () => {
    expect(extractAmountCents("plan of $15.49")).toBe(1549);
    expect(extractAmountCents("subscription of $9.99")).toBe(999);
  });

  it("parsea miles con punto (convención AR) como entero", () => {
    // "$9.990" = 9.990 pesos → 999.000 centavos (el punto separa miles)
    expect(extractAmountCents("cobro de $9.990")).toBe(999000);
    expect(extractAmountCents("$14.990 al mes")).toBe(1499000);
  });

  it("parsea miles y decimales combinados", () => {
    expect(extractAmountCents("$1,234.56")).toBe(123456);
    expect(extractAmountCents("1.234,56 €")).toBe(123456);
  });

  it("acepta moneda después del número", () => {
    expect(extractAmountCents("15.49 $")).toBe(1549);
  });

  it("devuelve null sin importe", () => {
    expect(extractAmountCents("Tu factura está disponible")).toBeNull();
  });
});

describe("extractCurrency", () => {
  it("prioriza el código ISO explícito sobre el símbolo $", () => {
    expect(extractCurrency("se te cobrará $14.990 ARS")).toBe("ARS");
    expect(extractCurrency("Tu plan de $349 MXN")).toBe("MXN");
  });

  it("usa el símbolo como fallback cuando no hay código ISO", () => {
    expect(extractCurrency("cobro de $15.49")).toBe("USD");
    expect(extractCurrency("factura 12,34 €")).toBe("EUR");
  });
});

describe("extractDate", () => {
  it("extrae fechas ISO", () => {
    expect(extractDate("termina el 2026-09-01")).toBe("2026-09-01");
  });

  it("normaliza fechas DD/MM/YYYY a ISO", () => {
    expect(extractDate("termina el 01/09/2026")).toBe("2026-09-01");
  });

  it("devuelve null sin fecha", () => {
    expect(extractDate("sin fecha aquí")).toBeNull();
  });
});

describe("extractDomain / extractMerchant", () => {
  it("extrae el dominio registrable y limpia subdominios", () => {
    expect(extractDomain("Netflix <info@netflix.com>")).toBe("netflix.com");
    expect(extractDomain("billing@accounts.adobe.com")).toBe("adobe.com");
    expect(extractDomain("no-reply@mail.spotify.com")).toBe("spotify.com");
  });

  it("respeta TLDs de dos partes", () => {
    expect(extractDomain("soporte@empresa.com.ar")).toBe("empresa.com.ar");
    expect(extractDomain("news@mail.servicio.com.mx")).toBe("servicio.com.mx");
  });

  it("usa el dominio limpio como merchant", () => {
    expect(extractMerchant("info@mail.netflix.com", "Tu factura")).toBe("netflix.com");
  });
});

describe("inferRecurrenceFromText", () => {
  it("infiere recurrencia por señales", () => {
    expect(inferRecurrenceFromText("prueba gratuita de 7 días")).toBe("trial");
    expect(inferRecurrenceFromText("renovación anual")).toBe("annual");
    expect(inferRecurrenceFromText("plan mensual")).toBe("monthly");
  });
});
