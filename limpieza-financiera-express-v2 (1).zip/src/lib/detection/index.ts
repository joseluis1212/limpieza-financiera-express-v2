/**
 * Orquestador del motor de detección.
 *
 * Pipeline:
 *   1. Filtro de reglas (¿es financiero?)
 *   2. Extracción determinista (monto, moneda, dominio)
 *   3. Extracción LLM (clasificación semántica, opcional)
 *   4. Fusión rules ⊕ LLM
 *   5. Deduplicación / agrupación → suscripciones
 */

import type { Charge, DetectionResult, EmailMetadata } from "./types";
import {
  extractAmountCents,
  extractCurrency,
  extractDate,
  extractDomain,
  extractMerchant,
  inferRecurrenceFromText,
  isCancellation,
  isFinancial,
} from "./rules";
import { amountToCents, extractWithLlm } from "./llm";
import { groupChargesIntoSubscriptions } from "./dedupe";

/** Fusión de reglas + LLM en un único cargo. Las reglas ganan en montos (auditable). */
function fuseCharge(
  email: EmailMetadata,
  llm: Awaited<ReturnType<typeof extractWithLlm>>,
): Charge | null {
  const searchable = `${email.subject} ${email.from} ${email.snippet}`;

  // Si el LLM dice explícitamente que no es financiero, lo descartamos
  // (solo si el LLM está disponible; si no, confiamos en las reglas).
  if (llm && llm.is_financial === false) return null;

  const cancelled = isCancellation(searchable) || llm?.cancelled === true;

  // Monto: regla primero (auditable); si no hay, el LLM.
  const ruleAmount = extractAmountCents(searchable);
  const llmAmount = llm ? amountToCents(llm.amount) : null;
  const amountCents = ruleAmount ?? llmAmount;

  // Moneda: regla primero; si no, LLM.
  const currency = extractCurrency(searchable) ?? (llm?.currency as Charge["currency"]) ?? null;

  const merchant =
    (llm?.merchant && llm.merchant.length > 0 && !llm.merchant.includes("@")
      ? llm.merchant
      : null) ?? extractMerchant(email.from, email.subject);

  const recurrence = llm?.is_trial
    ? "trial"
    : (llm?.recurrence_type as Charge["recurrence"]) ?? inferRecurrenceFromText(searchable);

  const isTrial = recurrence === "trial";

  const confidence: Charge["confidence"] =
    llm?.confidence ?? (amountCents !== null ? "high" : "medium");

  return {
    merchant,
    amountCents,
    currency,
    recurrence,
    isTrial,
    trialEndDate: isTrial ? (llm?.trial_end_date ?? extractDate(searchable)) : null,
    category: llm?.category ?? null,
    action: (llm?.action as Charge["action"]) ?? (cancelled ? "cancellation_confirmation" : "charge"),
    cancelled,
    confidence,
    source: llm ? "both" : "rules",
    emailId: email.id,
    chargedAt: email.receivedAt,
  };
}

/**
 * Ejecuta el pipeline completo sobre una lista de emails (metadata).
 * Devuelve los cargos y las suscripciones deduplicadas.
 */
export async function detectSubscriptions(
  emails: EmailMetadata[],
  opts?: { useLlm?: boolean },
): Promise<DetectionResult> {
  const useLlm = opts?.useLlm ?? true;

  const charges: Charge[] = [];
  let emailsFinancial = 0;

  for (const email of emails) {
    const searchable = `${email.subject} ${email.from} ${email.snippet}`;

    // 1. Filtro barato de reglas.
    if (!isFinancial(searchable)) continue;
    emailsFinancial++;

    // 2. Extracción LLM (opcional, degrada a null).
    const llm = useLlm ? await extractWithLlm(email) : null;

    // 3-4. Fusión.
    const charge = fuseCharge(email, llm);
    if (charge) charges.push(charge);
  }

  // 5. Agrupación.
  const subscriptions = groupChargesIntoSubscriptions(charges);

  return {
    charges,
    subscriptions,
    emailsScanned: emails.length,
    emailsFinancial,
  };
}

export { extractDomain };
