/**
 * Prompt EXACTO para la extracción de suscripciones con LLM.
 * Usado con structured output / tool calling (JSON Schema). Temperatura 0.
 */

export const SYSTEM_PROMPT = `You are a financial data extraction engine. You parse transactional email metadata (subject, sender, snippet) and output structured JSON. You never see full email bodies.

STRICT RULES:
1. Extract ONLY what is explicitly present. Never invent, estimate, or "complete" missing data.
2. If a field is absent or ambiguous, output null. Do not guess.
3. amount must be the exact charge amount as a decimal string. Do not add taxes or round.
4. currency: use ISO 4217 (USD, ARS, MXN, EUR...). Infer from symbols ($ is NOT always USD: if the merchant or context is Argentina use ARS, Mexico use MXN). If truly ambiguous, null.
5. recurrence_type: one of "monthly","annual","weekly","trial","one_time".
6. is_trial: true only if the email mentions a free trial, trial period, or "first month free".
7. trial_end_date: date the trial ends and the first charge occurs (ISO date or null).
8. merchant: the canonical brand name (e.g. "Netflix", not "netflix.com" nor "Netflix Billing").
9. category: one of "streaming","cloud_storage","fitness","news","software","telecom","delivery","membership","insurance","music","other".
10. Classify action as "charge" (money was taken), "upcoming_charge" (will be taken on a date), "trial_started", "trial_ending", "cancellation_confirmation", or "receipt".
11. If action is "cancellation_confirmation", set cancelled=true and amount=null (a cancellation is not a charge).

OUTPUT JSON (return exactly this shape):
{
  "is_financial": boolean,
  "merchant": string | null,
  "amount": string | null,
  "currency": string | null,
  "recurrence_type": string | null,
  "is_trial": boolean,
  "trial_end_date": string | null,
  "next_charge_date": string | null,
  "category": string | null,
  "action": string,
  "cancelled": boolean,
  "confidence": "high" | "medium" | "low"
}`;

const FEW_SHOT_EXAMPLES = [
  {
    input: `Subject: "Your Netflix subscription has been renewed" From: "Netflix <info@netflix.com>"
Snippet: "Your monthly plan of $15.49 was charged today. Thank you for being a member."`,
    output: `{"is_financial":true,"merchant":"Netflix","amount":"15.49","currency":"USD","recurrence_type":"monthly","is_trial":false,"trial_end_date":null,"next_charge_date":null,"category":"streaming","action":"charge","cancelled":false,"confidence":"high"}`,
  },
  {
    input: `Subject: "Tu prueba gratuita de 7 días termina pronto" From: "Spotify <no-reply@spotify.com>"
Snippet: "Tu prueba gratis termina el 2026-09-01. Después se te cobrará MXN 129 al mes."`,
    output: `{"is_financial":true,"merchant":"Spotify","amount":null,"currency":"MXN","recurrence_type":"trial","is_trial":true,"trial_end_date":"2026-09-01","next_charge_date":"2026-09-01","category":"streaming","action":"trial_ending","cancelled":false,"confidence":"high"}`,
  },
  {
    input: `Subject: "We've cancelled your subscription" From: "Adobe <billing@adobe.com>"
Snippet: "Your plan has been cancelled. You will not be charged again."`,
    output: `{"is_financial":true,"merchant":"Adobe","amount":null,"currency":null,"recurrence_type":null,"is_trial":false,"trial_end_date":null,"next_charge_date":null,"category":"software","action":"cancellation_confirmation","cancelled":true,"confidence":"high"}`,
  },
  {
    input: `Subject: "Your weekly digest" From: "Medium <no-reply@medium.com>"
Snippet: "Here are 5 stories we picked for you."`,
    output: `{"is_financial":false,"merchant":null,"amount":null,"currency":null,"recurrence_type":null,"is_trial":false,"trial_end_date":null,"next_charge_date":null,"category":null,"action":"receipt","cancelled":false,"confidence":"high"}`,
  },
];

/** Construye el mensaje de usuario para un solo email. */
export function buildUserMessage(email: {
  subject: string;
  from: string;
  snippet: string;
}): string {
  return `Subject: "${email.subject}" From: "${email.from}"
Snippet: "${email.snippet}"`;
}

/** Mensajes few-shot (system se envía aparte). */
export function buildMessages(email: { subject: string; from: string; snippet: string }) {
  const messages: { role: "system" | "user" | "assistant"; content: string }[] = [
    { role: "system", content: SYSTEM_PROMPT },
  ];
  for (const example of FEW_SHOT_EXAMPLES) {
    messages.push({ role: "user", content: example.input });
    messages.push({ role: "assistant", content: example.output });
  }
  messages.push({ role: "user", content: buildUserMessage(email) });
  return messages;
}
