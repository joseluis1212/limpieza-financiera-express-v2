/**
 * Tipos del motor de detección.
 *
 * Principio rector: trabajamos SOLO con metadatos de email (remitente, asunto,
 * snippet). Nunca con el cuerpo completo.
 */

export type Currency = "ARS" | "MXN" | "USD" | "EUR" | string;

export type Recurrence = "monthly" | "annual" | "weekly" | "trial" | "one_time";

export type Confidence = "high" | "medium" | "low";

export type ChargeAction =
  | "charge"
  | "upcoming_charge"
  | "trial_started"
  | "trial_ending"
  | "cancellation_confirmation"
  | "receipt";

/** Metadatos de un email, tal como los provee Gmail/Outlook (readonly). */
export type EmailMetadata = {
  id: string;
  providerMessageId: string;
  from: string; // "Netflix <info@netflix.com>"
  subject: string;
  snippet: string;
  receivedAt: string; // ISO date
};

/** Un cargo extraído de un email (antes de agrupar/deduplicar). */
export type Charge = {
  merchant: string;
  amountCents: number | null;
  currency: Currency | null;
  recurrence: Recurrence;
  isTrial: boolean;
  trialEndDate: string | null;
  category: string | null;
  action: ChargeAction;
  cancelled: boolean;
  confidence: Confidence;
  source: "rules" | "llm" | "both";
  emailId: string;
  chargedAt: string | null;
};

/** Resultado del pipeline completo. */
export type DetectionResult = {
  charges: Charge[];
  subscriptions: import("@/types").Subscription[];
  emailsScanned: number;
  emailsFinancial: number;
};
