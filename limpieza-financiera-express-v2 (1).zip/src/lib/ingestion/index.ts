import type { EmailMetadata } from "@/lib/detection/types";
import { syncGmailEmails } from "./gmail";
import { syncOutlookEmails } from "./outlook";
import type { Provider } from "./types";

export * from "./types";
export { syncGmailEmails, mapGmailMessage } from "./gmail";
export { syncOutlookEmails, mapGraphMessage } from "./outlook";
export { getProviderAccessToken } from "./provider-token";

/**
 * Sincroniza los emails de un proveedor y los devuelve normalizados.
 * Interfaz única para Gmail y Outlook.
 */
export async function syncEmails(
  provider: Provider,
  accessToken: string,
): Promise<EmailMetadata[]> {
  if (provider === "outlook") {
    return syncOutlookEmails(accessToken);
  }
  return syncGmailEmails(accessToken);
}
