import type { EmailMetadata } from "@/lib/detection/types";
import { FINANCIAL_QUERY, IngestionError, MAX_MESSAGES } from "./types";

/**
 * Cliente de Gmail API (v1) — solo lectura.
 * Sincroniza metadatos (From, Subject, Date, snippet) de los correos que
 * coinciden con señales financieras. NUNCA descarga el cuerpo completo.
 */

const GMAIL_BASE = "https://gmail.googleapis.com/gmail/v1/users/me";

type GmailListResponse = {
  messages?: { id: string; threadId: string }[];
  resultSizeEstimate?: number;
  nextPageToken?: string;
};

type GmailMessage = {
  id: string;
  snippet?: string;
  internalDate?: string;
  payload?: {
    headers?: { name: string; value: string }[];
  };
};

async function gmailFetch<T>(path: string, accessToken: string): Promise<T> {
  const response = await fetch(`${GMAIL_BASE}/${path}`, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
      Accept: "application/json",
    },
    cache: "no-store",
  });

  if (!response.ok) {
    const body = await response.text();
    throw new IngestionError(
      response.status,
      `Gmail API error ${response.status}: ${body.slice(0, 300)}`,
    );
  }

  return (await response.json()) as T;
}

function getHeader(message: GmailMessage, name: string): string {
  return (
    message.payload?.headers?.find(
      (h) => h.name.toLowerCase() === name.toLowerCase(),
    )?.value ?? ""
  );
}

/** Convierte un mensaje de Gmail a EmailMetadata (unificado). */
export function mapGmailMessage(message: GmailMessage): EmailMetadata {
  // Fecha: internalDate (epoch ms) o la cabecera Date. Fallback a "ahora" si
  // ambas faltan o son inválidas (nunca crashear por un email sin fecha).
  const dateFromHeader = new Date(getHeader(message, "Date"));
  const receivedAt = message.internalDate
    ? new Date(Number(message.internalDate)).toISOString()
    : Number.isFinite(dateFromHeader.getTime())
      ? dateFromHeader.toISOString()
      : new Date().toISOString();

  return {
    id: message.id,
    providerMessageId: message.id,
    from: getHeader(message, "From"),
    subject: getHeader(message, "Subject"),
    snippet: message.snippet ?? "",
    receivedAt,
  };
}

/** Ejecuta tareas con concurrencia limitada (evita reventar la cuota). */
async function mapWithConcurrency<T, R>(
  items: T[],
  limit: number,
  fn: (item: T) => Promise<R>,
): Promise<R[]> {
  const results: R[] = new Array(items.length);
  let cursor = 0;

  async function worker() {
    while (cursor < items.length) {
      const index = cursor++;
      results[index] = await fn(items[index]);
    }
  }

  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, worker));
  return results;
}

/**
 * Sincroniza los emails financieros de Gmail (últimos 180 días).
 * Devuelve EmailMetadata[] listos para el motor de detección.
 */
export async function syncGmailEmails(accessToken: string): Promise<EmailMetadata[]> {
  const query = `newer_than:180d ${FINANCIAL_QUERY}`;

  const list = await gmailFetch<GmailListResponse>(
    `messages?q=${encodeURIComponent(query)}&maxResults=${MAX_MESSAGES}`,
    accessToken,
  );

  const messages = list.messages ?? [];

  const detailed = await mapWithConcurrency(messages, 6, (message) =>
    gmailFetch<GmailMessage>(
      `messages/${message.id}?format=metadata&metadataHeaders=From&metadataHeaders=Subject&metadataHeaders=Date`,
      accessToken,
    ),
  );

  return detailed.map(mapGmailMessage);
}
