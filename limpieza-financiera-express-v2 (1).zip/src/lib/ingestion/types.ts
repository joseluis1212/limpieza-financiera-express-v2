import type { EmailMetadata } from "@/lib/detection/types";

/**
 * Tipos de la capa de ingestión de emails.
 */

export type Provider = "gmail" | "outlook";

/** Resultado de una sincronización de emails. */
export type SyncResult = {
  provider: Provider;
  emails: EmailMetadata[];
  /** Cursor/paginación (para escaneos incrementales futuros). */
  nextPageToken: string | null;
};

/** Señales financieras usadas como query para pre-filtrar en el proveedor. */
export const FINANCIAL_QUERY =
  "(subscription OR suscripción OR renew OR renovación OR invoice OR factura OR " +
  "receipt OR recibo OR payment OR pago OR charged OR billing OR trial OR prueba)";

/** Ventana de tiempo del escaneo (180 días). */
export const SCAN_WINDOW_DAYS = 180;

/** Máximo de mensajes a procesar por escaneo. */
export const MAX_MESSAGES = 50;

/**
 * Excepción tipada de la ingestión, con el estado HTTP del proveedor para
 * mapear a mensajes accionables (401 token vencido, 429 cuota, etc.).
 */
export class IngestionError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
    this.name = "IngestionError";
  }
}
