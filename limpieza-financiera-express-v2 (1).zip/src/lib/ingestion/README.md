# Ingestión de Emails — Documentación técnica

La capa de ingestión sincroniza los emails del proveedor (Gmail / Outlook) con **solo
lectura**, extrayendo únicamente metadatos (remitente, asunto, snippet, fecha). NUNCA se
descarga ni almacena el cuerpo completo del email.

## Estructura

```
src/lib/ingestion/
├── types.ts            # tipos + query financiera + IngestionError
├── provider-token.ts   # obtiene el access token del proveedor desde Supabase
├── gmail.ts            # cliente Gmail API (v1) + mapGmailMessage
├── outlook.ts          # cliente Microsoft Graph + mapGraphMessage
├── index.ts            # interfaz unificada syncEmails(provider, token)
└── index.test.ts       # tests de los mapeos (5 tests)
```

## Flujo

```
POST /api/scan
  → requireCurrentUser()                    # autenticación
  → getProviderAccessToken()                # session.provider_token de Supabase
  → syncEmails("gmail" | "outlook", token)  # ingestión (metadata readonly)
  → detectSubscriptions(emails)             # motor de detección
  → persistDetections(user.id, result)      # PostgreSQL
```

## Gmail API

- Query pre-filtrada con señales financieras (`newer_than:180d (subscription OR ...)`).
- `format=metadata` + `metadataHeaders=From,Subject,Date` → solo metadatos.
- Concurrencia limitada a 6 requests en paralelo (evita la cuota).
- **Scope requerido:** `https://www.googleapis.com/auth/gmail.readonly`.

## Microsoft Graph (Outlook)

- `GET /me/messages` con `$filter` por fecha (180 días) y `$select` de solo metadatos.
- El filtro financiero fino lo hace el motor de detección (Graph no soporta query por
  keywords arbitrarias sin `$search`).
- **Scope requerido:** `Mail.Read`.

## Manejo de errores (IngestionError)

| Estado | Significado | Respuesta de la API |
|---|---|---|
| 401 | Token vencido/revocado | 401 → "vuelve a conectar tu cuenta" |
| 429 | Cuota del proveedor | 429 → "intenta en unos minutos" |
| otro | Error de red/proveedor | 502 → "no se pudieron sincronizar" |

## Degradación

- Sin `NEXT_PUBLIC_SUPABASE_URL` (desarrollo): `/api/scan` usa `mockEmails` para validar la UI.
- Con Supabase pero sin token de proveedor: `/api/scan` devuelve 400 con mensaje accionable.
- La detección y persistencia son siempre reales cuando hay datos.

## Nota de seguridad

El token del proveedor (`provider_token`) viaja en la sesión de Supabase y se usa SOLO en el
servidor (nunca en el cliente). En una iteración futura se cifrará en reposo (KMS/Vault) para
soportar refresh tokens de larga duración.

## Próximos pasos

- **Refresh de token:** el `provider_token` de Google expira (~1 h). Para escaneos
  programados se necesita una Supabase Edge Function que refresque con
  `provider_refresh_token`.
- **Paginación incremental:** usar `nextPageToken` de Gmail / `@odata.nextLink` de Graph para
  escaneos incrementales (hoy se procesa una sola página de 50).
