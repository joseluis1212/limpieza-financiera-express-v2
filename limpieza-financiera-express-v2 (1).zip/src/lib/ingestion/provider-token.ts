import { createSupabaseServerClient } from "@/lib/supabase/server";

/**
 * Obtiene el access token del proveedor de email (Gmail/Outlook) desde la
 * sesión de Supabase.
 *
 * Supabase almacena el token del proveedor OAuth en `session.provider_token`
 * cuando el flujo se inicia con los scopes correctos (gmail.readonly / Mail.Read).
 */
export async function getProviderAccessToken(): Promise<string | null> {
  const supabase = await createSupabaseServerClient();
  if (!supabase) return null;

  const {
    data: { session },
  } = await supabase.auth.getSession();

  return session?.provider_token ?? null;
}
