import { describe, expect, it } from "vitest";
import { mapGmailMessage } from "./gmail";
import { mapGraphMessage } from "./outlook";
import { IngestionError } from "./types";

describe("mapGmailMessage", () => {
  it("mapea headers y snippet a EmailMetadata", () => {
    const mapped = mapGmailMessage({
      id: "abc123",
      snippet: "Tu plan mensual fue cobrado",
      internalDate: "1722859200000", // 2026-08-05
      payload: {
        headers: [
          { name: "From", value: "Netflix <info@netflix.com>" },
          { name: "Subject", value: "Tu factura de Netflix" },
          { name: "Date", value: "Mon, 5 Aug 2026 12:00:00 +0000" },
        ],
      },
    });

    expect(mapped.id).toBe("abc123");
    expect(mapped.providerMessageId).toBe("abc123");
    expect(mapped.from).toBe("Netflix <info@netflix.com>");
    expect(mapped.subject).toBe("Tu factura de Netflix");
    expect(mapped.snippet).toBe("Tu plan mensual fue cobrado");
    expect(mapped.receivedAt).toBe(new Date(1722859200000).toISOString());
  });

  it("maneja mensajes sin headers", () => {
    const mapped = mapGmailMessage({
      id: "empty",
      payload: { headers: [] },
    });
    expect(mapped.from).toBe("");
    expect(mapped.subject).toBe("");
    expect(mapped.snippet).toBe("");
  });
});

describe("mapGraphMessage", () => {
  it("mapea from (nombre + email) y bodyPreview", () => {
    const mapped = mapGraphMessage({
      id: "graph1",
      subject: "Your Spotify subscription",
      bodyPreview: "Your monthly plan of $9.99 was charged.",
      receivedDateTime: "2026-08-01T10:00:00Z",
      from: {
        emailAddress: { address: "no-reply@spotify.com", name: "Spotify" },
      },
    });

    expect(mapped.from).toBe("Spotify <no-reply@spotify.com>");
    expect(mapped.subject).toBe("Your Spotify subscription");
    expect(mapped.snippet).toBe("Your monthly plan of $9.99 was charged.");
    expect(mapped.receivedAt).toBe("2026-08-01T10:00:00Z");
  });

  it("maneja from sin nombre", () => {
    const mapped = mapGraphMessage({
      id: "graph2",
      from: { emailAddress: { address: "info@netflix.com" } },
    });
    expect(mapped.from).toBe("info@netflix.com");
  });
});

describe("IngestionError", () => {
  it("expone el estado HTTP para mapear a mensajes accionables", () => {
    const err = new IngestionError(401, "token expired");
    expect(err.status).toBe(401);
    expect(err.name).toBe("IngestionError");
  });
});
