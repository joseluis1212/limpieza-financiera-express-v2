import type { EmailMetadata } from "@/lib/detection/types";
import { IngestionError, MAX_MESSAGES, SCAN_WINDOW_DAYS } from "./types";

/**
 * Cliente de Microsoft Graph (Outlook) — solo lectura (Mail.Read).
 * Sincroniza metadatos de los correos recientes; el filtro financiero fino lo
 * hace el motor de detección (Graph no soporta query por keywords arbitrarias
 * sin $search, que requiere configuración adicional).
 */

const GRAPH_BASE = "https://graph.microsoft.com/v1.0";

type GraphMessage = {
  id: string;
  subject?: string;
  bodyPreview?: string;
  receivedDateTime?: string;
  from?: { emailAddress?: { address?: string; name?: string } };
};

type GraphListResponse = {
  value?: GraphMessage[];
  "@odata.nextLink"?: string;
};

async function graphFetch<T>(path: string, accessToken: string): Promise<T> {
  const response = await fetch(`${GRAPH_BASE}${path}`, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
      Accept: "application/json",
    },
    cache: "no-store",
  });

  if (!response.ok) {
    const body = await response.text();
    throw new IngestionError(
      response.status,
      `Microsoft Graph error ${response.status}: ${body.slice(0, 300)}`,
    );
  }

  return (await response.json()) as T;
}

/** Convierte un mensaje de Graph a EmailMetadata (unificado). */
export function mapGraphMessage(message: GraphMessage): EmailMetadata {
  const address = message.from?.emailAddress?.address ?? "";
  const name = message.from?.emailAddress?.name ?? "";
  const from = name ? `${name} <${address}>` : address;

  return {
    id: message.id,
    providerMessageId: message.id,
    from,
    subject: message.subject ?? "",
    snippet: message.bodyPreview ?? "",
    receivedAt: message.receivedDateTime ?? new Date().toISOString(),
  };
}

/**
 * Sincroniza los emails recientes de Outlook (últimos 180 días).
 * Devuelve EmailMetadata[] listos para el motor de detección.
 */
export async function syncOutlookEmails(accessToken: string): Promise<EmailMetadata[]> {
  const since = new Date(Date.now() - SCAN_WINDOW_DAYS * 24 * 60 * 60 * 1000).toISOString();

  const list = await graphFetch<GraphListResponse>(
    `/me/messages?$filter=receivedDateTime ge ${since}` +
      `&$orderby=receivedDateTime desc&$top=${MAX_MESSAGES}` +
      `&$select=id,subject,bodyPreview,receivedDateTime,from`,
    accessToken,
  );

  return (list.value ?? []).map(mapGraphMessage);
}
