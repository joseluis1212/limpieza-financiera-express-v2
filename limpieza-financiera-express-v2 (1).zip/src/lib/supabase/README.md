# Backend — Supabase Auth + Persistencia (PostgreSQL/Drizzle)

Documentación de la capa de backend implementada.

## Estructura

```
src/
├── lib/
│   ├── supabase/
│   │   ├── config.ts     # getBaseUrl() + getSupabaseConfig()
│   │   ├── client.ts     # cliente navegador (singleton)
│   │   └── server.ts     # cliente servidor (Server Components / Route Handlers)
│   ├── auth.ts           # getCurrentUser() / requireCurrentUser()
│   ├── logger.ts         # logger estructurado (JSON)
│   └── persistence.ts    # persistDetections() / getSubscriptions()
├── db/
│   ├── schema.ts         # schema Drizzle (5 tablas)
│   └── index.ts          # cliente lazy (no rompe sin DATABASE_URL)
├── middleware.ts         # protección de rutas + refresco de sesión
└── app/
    ├── login/page.tsx
    ├── onboarding/page.tsx        # consentimiento + OAuth real
    └── api/
        ├── auth/signin/route.ts   # inicia OAuth (gmail/outlook)
        ├── auth/callback/route.ts # intercambia code → sesión + upsert perfil
        ├── auth/signout/route.ts
        ├── scan/route.ts          # auth → detección → persistencia
        └── subscriptions/route.ts # GET suscripciones (DB o mock)
```

## Flujo de autenticación

```
Landing → /onboarding (elegir proveedor + consentimiento)
   → POST /api/auth/signin (provider=gmail|outlook)
   → Supabase OAuth (Google/Microsoft, scope readonly)
   → /api/auth/callback (exchangeCodeForSession + upsert perfil)
   → /dashboard (protegido por middleware)
```

## Schema (5 tablas)

| Tabla | Propósito |
|---|---|
| `profiles` | 1:1 con auth.users + país/locale/fee |
| `provider_connections` | conexión a Gmail/Outlook |
| `emails_index` | metadatos de emails (NUNCA el cuerpo) |
| `subscriptions` | suscripciones deduplicadas |
| `subscription_charges` | cargos individuales |

Migración en `drizzle/0000_confused_doomsday.sql`. RLS en `supabase/rls.sql`.

## Principios

- **Degradación elegante:** sin `NEXT_PUBLIC_SUPABASE_URL`/`DATABASE_URL`, la app arranca y
  muestra avisos; los endpoints protegidos redirigen a `/login`; `/api/subscriptions` cae al
  mock. Nada crashea.
- **Nunca el cuerpo del email:** solo metadatos + entidades extraídas.
- **Dedupe:** el índice `provider_message_id` evita re-procesar el mismo email.

## Pendiente (próximos pasos)

1. **Ingestión real de emails** (Gmail API / Microsoft Graph) reemplazando `mockEmails` en
   `/api/scan`.
2. **Cifrado de tokens OAuth** (KMS/Vault) — hoy Supabase gestiona el token.
3. **Cobro del fee** (Stripe/MercadoPago) tras la verificación de ahorro.
4. **i18n** (es-AR / es-MX / en-US).

## Configuración de Supabase

1. Crear proyecto en Supabase.
2. Auth → Providers → habilitar **Google** (con scope gmail.readonly) y **Azure** (Outlook).
3. Redirect URI: `https://<proyecto>.supabase.co/auth/v1/callback`.
4. DB → Connection string → modo **Transaction (puerto 6543)** → `DATABASE_URL`.
5. Pegar `drizzle/0000_confused_doomsday.sql` (o `drizzle-kit push`) + `supabase/rls.sql`.
