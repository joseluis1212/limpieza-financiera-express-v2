"use client";

import { createBrowserClient } from "@supabase/ssr";
import type { SupabaseClient } from "@supabase/supabase-js";
import { getSupabaseConfig } from "./config";

let client: SupabaseClient | null = null;

/**
 * Cliente de Supabase para el navegador (singleton).
 * Devuelve null si no está configurado (la UI debe manejarlo con un aviso).
 */
export function getBrowserSupabase(): SupabaseClient | null {
  const config = getSupabaseConfig();
  if (!config) return null;

  if (!client) {
    client = createBrowserClient(config.url, config.anonKey);
  }
  return client;
}
