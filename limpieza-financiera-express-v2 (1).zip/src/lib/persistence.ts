import { eq } from "drizzle-orm";
import { db, schema } from "@/db";
import type { Subscription } from "@/types";
import type { DetectionResult } from "@/lib/detection/types";

/**
 * Capa de persistencia de suscripciones.
 * Convierte el resultado del motor de detección en filas de DB.
 */

/** Persiste las suscripciones detectadas para un usuario. */
export async function persistDetections(
  userId: string,
  result: DetectionResult,
): Promise<number> {
  const { subscriptions } = result;

  for (const sub of subscriptions) {
    // Upsert por (user_id, merchant) para no duplicar en re-escaneos.
    const existing = await db
      .select({ id: schema.subscriptions.id })
      .from(schema.subscriptions)
      .where(
        eq(schema.subscriptions.userId, userId) &&
          eq(schema.subscriptions.merchant, sub.merchant),
      )
      .limit(1);

    const values = {
      userId,
      merchant: sub.merchant,
      category: sub.category ?? "other",
      amountCents: sub.amountCents,
      currency: sub.currency,
      recurrence: sub.recurrence,
      status: sub.status,
      confidence: sub.confidence,
      lastChargedAt: sub.lastChargedAt ? new Date(sub.lastChargedAt) : null,
      nextExpectedAt: sub.nextExpectedAt ? new Date(sub.nextExpectedAt) : null,
      trialEndsAt: sub.trialEndsAt ? new Date(sub.trialEndsAt) : null,
      updatedAt: new Date(),
    };

    if (existing.length > 0) {
      await db
        .update(schema.subscriptions)
        .set(values)
        .where(eq(schema.subscriptions.id, existing[0].id));
    } else {
      await db.insert(schema.subscriptions).values(values);
    }
  }

  return subscriptions.length;
}

/** Lee las suscripciones persistidas de un usuario, ordenadas por monto. */
export async function getSubscriptions(userId: string): Promise<Subscription[]> {
  const rows = await db
    .select()
    .from(schema.subscriptions)
    .where(eq(schema.subscriptions.userId, userId));

  return rows
    .map((row) => ({
      id: row.id,
      merchant: row.merchant,
      category: row.category,
      amountCents: row.amountCents,
      currency: row.currency as Subscription["currency"],
      recurrence: row.recurrence as Subscription["recurrence"],
      status: row.status as Subscription["status"],
      confidence: row.confidence as Subscription["confidence"],
      lastChargedAt: row.lastChargedAt?.toISOString(),
      nextExpectedAt: row.nextExpectedAt?.toISOString(),
      trialEndsAt: row.trialEndsAt?.toISOString(),
    }))
    .sort((a, b) => b.amountCents - a.amountCents);
}
