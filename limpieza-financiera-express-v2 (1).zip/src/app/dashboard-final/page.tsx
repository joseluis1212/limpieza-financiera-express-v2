"use client";

import Link from "next/link";
import { PiggyBank, Bell, History, ShieldCheck, Settings } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatMoney } from "@/lib/format";
import { useBillingStore } from "@/store/use-billing";
import { useSubscriptionsStore } from "@/store/use-subscriptions";

/**
 * Dashboard final (post-pago): estado de ahorro, monitoreo activo y control
 * de la cuenta.
 */
export default function DashboardFinalPage() {
  const { totalSavingsCents, currency, feeCents, paid } = useBillingStore();
  const { subscriptions } = useSubscriptionsStore();

  const canceled = subscriptions.filter((s) => s.status === "canceled");
  const remaining = subscriptions.filter((s) => s.status !== "canceled");

  return (
    <main className="min-h-screen bg-muted/40">
      <header className="border-b bg-white">
        <div className="container flex h-16 items-center justify-between">
          <span className="text-lg font-bold">
            Limpieza Financiera<span className="text-primary"> Express</span>
          </span>
          <Link
            href="/dashboard"
            className="grid size-10 place-items-center rounded-lg text-slate-600 hover:bg-muted"
            aria-label="Configuración"
          >
            <Settings className="size-5" aria-hidden />
          </Link>
        </div>
      </header>

      <div className="container py-8">
        {/* Banner de resultado */}
        <div className="rounded-3xl bg-primary p-8 text-white">
          <div className="flex items-center gap-3">
            <PiggyBank className="size-8 text-white" aria-hidden />
            <h1 className="text-2xl font-bold text-white sm:text-3xl">Tu ahorro total</h1>
          </div>
          <p className="mt-4 text-5xl font-extrabold tracking-tight text-white">
            {formatMoney(totalSavingsCents, currency)}
            <span className="text-lg font-semibold text-blue-100">/año</span>
          </p>
          <p className="mt-2 text-blue-100">
            {paid ? `Fee pagado: ${formatMoney(feeCents, currency)} · Gracias por confiar.` : "Pago pendiente."}
          </p>
        </div>

        {/* Métricas secundarias */}
        <div className="mt-6 grid gap-4 sm:grid-cols-3">
          <StatCard
            icon={History}
            label="Suscripciones canceladas"
            value={String(canceled.length)}
          />
          <StatCard icon={Bell} label="Alertas activas" value="Sí" />
          <StatCard icon={ShieldCheck} label="Correo conectado" value="Sí" />
        </div>

        {/* Listas */}
        <div className="mt-8 grid gap-6 lg:grid-cols-2">
          <section className="rounded-2xl border bg-white p-6">
            <h2 className="text-lg font-bold">Canceladas</h2>
            {canceled.length === 0 ? (
              <p className="mt-3 text-slate-600">Todavía no cancelaste ninguna.</p>
            ) : (
              <ul className="mt-3 space-y-2">
                {canceled.map((s) => (
                  <li
                    key={s.id}
                    className="flex items-center justify-between rounded-lg bg-muted px-4 py-3"
                  >
                    <span className="font-semibold">{s.merchant}</span>
                    <Badge variant="success">Cancelada</Badge>
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section className="rounded-2xl border bg-white p-6">
            <h2 className="text-lg font-bold">Seguís pagando</h2>
            {remaining.length === 0 ? (
              <p className="mt-3 text-slate-600">No tenés suscripciones activas.</p>
            ) : (
              <ul className="mt-3 space-y-2">
                {remaining.map((s) => (
                  <li
                    key={s.id}
                    className="flex items-center justify-between rounded-lg bg-muted px-4 py-3"
                  >
                    <span className="font-semibold">{s.merchant}</span>
                    <span className="text-slate-600">
                      {formatMoney(s.amountCents, s.currency)}
                    </span>
                  </li>
                ))}
              </ul>
            )}
            <Button asChild variant="outline" className="mt-4 w-full">
              <Link href="/dashboard">Gestionar suscripciones</Link>
            </Button>
          </section>
        </div>
      </div>
    </main>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof History;
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-2xl border bg-white p-6">
      <div className="flex items-center gap-2">
        <Icon className="size-5 text-primary" aria-hidden />
        <p className="text-sm font-semibold text-slate-600">{label}</p>
      </div>
      <p className="mt-3 text-2xl font-extrabold">{value}</p>
    </div>
  );
}
