"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft, CreditCard, Lock, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatMoney } from "@/lib/format";
import { useBillingStore } from "@/store/use-billing";

export default function PagoPage() {
  const router = useRouter();
  const { totalSavingsCents, currency, feeRate, feeCents, method, setMethod, pay, paid } =
    useBillingStore();
  const [processing, setProcessing] = useState(false);

  async function handlePay() {
    if (!method) return;
    setProcessing(true);
    // Simula el pago (en producción: Stripe PaymentIntent / MercadoPago).
    await new Promise((r) => setTimeout(r, 1200));
    pay();
    router.push("/exito");
  }

  return (
    <main className="container flex min-h-screen max-w-xl flex-col justify-center py-12">
      <Link href="/dashboard" className="mb-8 inline-flex items-center gap-2 text-slate-700 hover:text-primary">
        <ArrowLeft className="size-5" aria-hidden /> Volver al dashboard
      </Link>

      <h1 className="text-3xl font-bold tracking-tight">Completá el pago</h1>
      <p className="mt-2 text-lg text-slate-700">
        Tu ahorro ya está verificado. Esto es lo que te cobramos:
      </p>

      {/* Resumen del cobro */}
      <div className="mt-6 rounded-2xl border bg-white p-6">
        <dl className="space-y-3 text-slate-700">
          <div className="flex justify-between border-b pb-3">
            <dt>Ahorro verificado (año 1)</dt>
            <dd className="font-bold">{formatMoney(totalSavingsCents, currency)}</dd>
          </div>
          <div className="flex justify-between border-b pb-3">
            <dt>Nuestro fee ({Math.round(feeRate * 100)}%)</dt>
            <dd className="font-bold">{formatMoney(feeCents, currency)}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="font-bold">Total a pagar</dt>
            <dd className="text-2xl font-extrabold text-primary">{formatMoney(feeCents, currency)}</dd>
          </div>
        </dl>
        <p className="mt-4 flex items-center gap-2 text-sm text-slate-600">
          <Lock className="size-4" aria-hidden /> Pago seguro, único y sin suscripción mensual.
        </p>
      </div>

      {/* Métodos de pago */}
      <p className="mt-6 text-sm font-semibold text-slate-600">Elegí cómo pagar</p>
      <div className="mt-2 grid gap-2">
        {(
          [
            { id: "mercadopago", label: "MercadoPago", hint: "Tarjeta, débito o cuotas" },
            { id: "stripe", label: "Tarjeta internacional", hint: "Visa, Mastercard, Amex" },
          ] as const
        ).map(({ id, label, hint }) => (
          <button
            key={id}
            type="button"
            onClick={() => setMethod(id)}
            className={`flex h-16 items-center justify-between rounded-lg border px-4 text-left font-semibold transition-colors ${
              method === id ? "border-primary bg-primary/5" : "hover:bg-muted"
            }`}
          >
            <span className="flex items-center gap-3">
              <CreditCard className="size-5 text-primary" aria-hidden />
              <span>
                {label}
                <span className="block text-sm font-normal text-slate-600">{hint}</span>
              </span>
            </span>
            {method === id ? <CheckCircle2 className="size-5 text-primary" aria-hidden /> : null}
          </button>
        ))}
      </div>

      <Button size="lg" className="mt-6" disabled={!method || processing} onClick={handlePay}>
        {processing ? "Procesando…" : `Pagar ${formatMoney(feeCents, currency)}`}
      </Button>

      <p className="mt-4 text-center text-sm text-slate-600">
        Podés cancelar este pago en cualquier momento. Si el ahorro no se confirma, no te
        cobramos nada.
      </p>
    </main>
  );
}
