"use client";

import Link from "next/link";
import { CheckCircle2, Bell, ShieldCheck, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatMoney } from "@/lib/format";
import { useBillingStore } from "@/store/use-billing";

export default function ExitoPage() {
  const { totalSavingsCents, currency, feeCents } = useBillingStore();

  return (
    <main className="container flex min-h-screen max-w-xl flex-col justify-center py-12">
      <div className="text-center">
        <CheckCircle2 className="mx-auto size-20 text-success" aria-hidden />
        <h1 className="mt-6 text-3xl font-extrabold tracking-tight sm:text-4xl">
          ¡Dinero recuperado!
        </h1>
        <p className="mt-3 text-lg text-slate-700">
          Vas a ahorrar{" "}
          <strong className="text-success">
            {formatMoney(totalSavingsCents, currency)}
          </strong>{" "}
          en el primer año.
        </p>
      </div>

      {/* Resumen del resultado */}
      <div className="mt-8 rounded-2xl border bg-white p-6">
        <dl className="space-y-3 text-slate-700">
          <div className="flex justify-between border-b pb-3">
            <dt>Ahorro total (año 1)</dt>
            <dd className="font-bold text-success">{formatMoney(totalSavingsCents, currency)}</dd>
          </div>
          <div className="flex justify-between">
            <dt>Nuestro fee</dt>
            <dd className="font-bold">{formatMoney(feeCents, currency)}</dd>
          </div>
        </dl>
      </div>

      {/* Próximos pasos */}
      <div className="mt-6 space-y-3">
        <div className="flex items-center gap-3 rounded-2xl border bg-white p-4">
          <Bell className="size-6 text-primary" aria-hidden />
          <div>
            <p className="font-bold">Monitoreo activo</p>
            <p className="text-sm text-slate-600">
              Te avisamos si aparece un trial nuevo o una renovación de precio.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3 rounded-2xl border bg-white p-4">
          <ShieldCheck className="size-6 text-success" aria-hidden />
          <div>
            <p className="font-bold">Tu privacidad sigue protegida</p>
            <p className="text-sm text-slate-600">
              Podés desconectar tu correo cuando quieras.
            </p>
          </div>
        </div>
      </div>

      <Button asChild size="lg" className="mt-8">
        <Link href="/dashboard-final">
          Ver mi panel de ahorro
          <ArrowRight aria-hidden />
        </Link>
      </Button>
    </main>
  );
}
