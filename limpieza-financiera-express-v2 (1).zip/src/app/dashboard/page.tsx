"use client";

import { useEffect, useMemo, useState } from "react";
import { Metrics } from "@/components/dashboard/metrics";
import { Filters, type Filter } from "@/components/dashboard/filters";
import { SubscriptionCard } from "@/components/dashboard/subscription-card";
import { SubscriptionDetail } from "@/components/dashboard/subscription-detail";
import { EmptyState } from "@/components/dashboard/empty-state";
import { CancellationFlow } from "@/components/cancellation/cancellation-flow";
import { useSubscriptionsStore, selectMonthlySavings } from "@/store/use-subscriptions";
import { useCancellationStore } from "@/store/use-cancellation";
import { formatMoney } from "@/lib/format";

export default function DashboardPage() {
  const {
    subscriptions,
    filter,
    keptIds,
    selectedId,
    setFilter,
    select,
    toggleKeep,
    feeRate,
  } = useSubscriptionsStore();

  const { start, close } = useCancellationStore();
  const [cancelTarget, setCancelTarget] = useState<string | null>(null);

  // Cuando se elige cancelar una suscripción, se inicia el flujo.
  useEffect(() => {
    if (!cancelTarget) return;
    const sub = subscriptions.find((s) => s.id === cancelTarget);
    if (sub) start(sub, feeRate);
  }, [cancelTarget, subscriptions, feeRate, start]);

  const counts = useMemo(
    () => ({
      todas: subscriptions.filter((s) => s.status !== "canceled").length,
      activas: subscriptions.filter((s) => s.status === "active").length,
      olvidadas: subscriptions.filter((s) => s.status === "forgotten").length,
      trials: subscriptions.filter((s) => s.status === "trial").length,
    }),
    [subscriptions],
  );

  const visible = useMemo(() => {
    const notCanceled = subscriptions.filter((s) => s.status !== "canceled");
    if (filter === "todas") return notCanceled;
    if (filter === "activas") return notCanceled.filter((s) => s.status === "active");
    if (filter === "olvidadas") return notCanceled.filter((s) => s.status === "forgotten");
    return notCanceled.filter((s) => s.status === "trial");
  }, [subscriptions, filter]);

  const selected = subscriptions.find((s) => s.id === selectedId) ?? null;
  const { monthlyCents, currency } = selectMonthlySavings(subscriptions, keptIds);

  return (
    <main className="min-h-screen bg-muted/40">
      {/* Header */}
      <header className="border-b bg-white">
        <div className="container flex h-16 items-center justify-between">
          <span className="text-lg font-bold">
            Limpieza Financiera<span className="text-primary"> Express</span>
          </span>
          <span className="flex items-center gap-2 rounded-full bg-emerald-50 px-3 py-1.5 text-sm font-semibold text-emerald-800">
            <span className="size-2 rounded-full bg-success" aria-hidden />
            Correo conectado
          </span>
        </div>
      </header>

      <div className="container py-8">
        <h1 className="text-2xl font-bold sm:text-3xl">Hola, María 👋</h1>
        <p className="mt-1 text-slate-700">
          Encontramos <strong>{counts.todas} suscripciones</strong>. Este es tu ahorro potencial:
        </p>

        <div className="mt-6">
          <Metrics subscriptions={subscriptions} keptIds={keptIds} />
        </div>

        <div className="mt-8">
          <Filters value={filter} onChange={setFilter} counts={counts} />
        </div>

        <div className="mt-6">
          {visible.length === 0 ? (
            <EmptyState />
          ) : (
            <div className="grid gap-4 md:grid-cols-2">
              {visible.map((sub) => (
                <SubscriptionCard
                  key={sub.id}
                  subscription={sub}
                  isKept={keptIds.includes(sub.id)}
                  onSelect={() => select(sub.id)}
                  onCancel={() => setCancelTarget(sub.id)}
                  onKeep={() => toggleKeep(sub.id)}
                />
              ))}
            </div>
          )}
        </div>

        <p className="mt-8 text-center text-slate-600" aria-live="polite">
          Ahorro potencial mensual:{" "}
          <strong className="text-success">{formatMoney(monthlyCents, currency)}</strong>
        </p>
      </div>

      {/* Detalle de suscripción */}
      {selected ? (
        <SubscriptionDetail
          subscription={selected}
          onClose={() => select(null)}
          onCancel={() => {
            setCancelTarget(selected.id);
            select(null);
          }}
          onKeep={() => {
            toggleKeep(selected.id);
            select(null);
          }}
        />
      ) : null}

      {/* Flujo de cancelación */}
      {cancelTarget ? (
        <CancellationFlow
          onAfterClose={() => {
            const sub = subscriptions.find((s) => s.id === cancelTarget);
            if (sub && useCancellationStore.getState().step === "confirmed") {
              // Marca la suscripción como cancelada en el dashboard.
              useSubscriptionsStore.getState().markCanceled(sub.id);
            }
            close();
            setCancelTarget(null);
          }}
        />
      ) : null}
    </main>
  );
}
