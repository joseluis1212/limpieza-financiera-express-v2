import { NextResponse } from "next/server";
import { requireCurrentUser } from "@/lib/auth";
import { getSubscriptions } from "@/lib/persistence";
import { mockSubscriptions } from "@/data/subscriptions";

export const dynamic = "force-dynamic";

/**
 * GET /api/subscriptions — devuelve las suscripciones del usuario.
 * Lee de la base; si no hay DB configurada, devuelve los datos mock (desarrollo).
 */
export async function GET() {
  const user = await requireCurrentUser();

  try {
    const subscriptions = await getSubscriptions(user.id);
    return NextResponse.json({ ok: true, subscriptions });
  } catch {
    // Sin DB (desarrollo): devolvemos datos mock para que la UI funcione.
    return NextResponse.json({ ok: true, subscriptions: mockSubscriptions, mock: true });
  }
}
