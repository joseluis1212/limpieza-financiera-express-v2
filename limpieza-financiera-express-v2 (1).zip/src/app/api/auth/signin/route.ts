import { NextResponse, type NextRequest } from "next/server";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { getBaseUrl } from "@/lib/supabase/config";

export const dynamic = "force-dynamic";

const SCOPES: Record<string, string> = {
  gmail: "openid email profile https://www.googleapis.com/auth/gmail.readonly",
  // Microsoft Graph (Mail.Read, solo lectura)
  outlook: "openid email profile Mail.Read offline_access",
};

/**
 * Inicia el flujo OAuth con Supabase.
 * POST { provider: "gmail" | "outlook", next?: string }
 */
export async function POST(request: NextRequest) {
  const supabase = await createSupabaseServerClient();
  if (!supabase) {
    return NextResponse.redirect(
      new URL("/login?error=supabase_not_configured", request.url),
    );
  }

  const formData = await request.formData();
  const provider = String(formData.get("provider") ?? "gmail");
  const next = String(formData.get("next") ?? "/dashboard");

  // Sanitizar el redirect (evitar open redirect).
  const safeNext = next.startsWith("/") && !next.startsWith("//") ? next : "/dashboard";

  // Proveedor de Supabase: 'google' para Gmail, 'azure' para Outlook/Microsoft.
  const supabaseProvider = provider === "outlook" ? "azure" : "google";

  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: supabaseProvider,
    options: {
      redirectTo: `${getBaseUrl()}/api/auth/callback?next=${encodeURIComponent(safeNext)}`,
      scopes: SCOPES[provider] ?? SCOPES.gmail,
      queryParams: provider === "gmail" ? { access_type: "offline", prompt: "consent" } : undefined,
    },
  });

  if (error || !data.url) {
    return NextResponse.redirect(new URL("/login?error=oauth_start_failed", request.url));
  }

  return NextResponse.redirect(data.url);
}
