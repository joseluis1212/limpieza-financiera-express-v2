import { NextResponse, type NextRequest } from "next/server";
import { eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { logger } from "@/lib/logger";

export const dynamic = "force-dynamic";

/**
 * Callback de OAuth: intercambia el code por sesión y sincroniza el perfil.
 */
export async function GET(request: NextRequest) {
  const requestUrl = new URL(request.url);
  const code = requestUrl.searchParams.get("code");
  const next = requestUrl.searchParams.get("next") ?? "/dashboard";
  const safeNext = next.startsWith("/") && !next.startsWith("//") ? next : "/dashboard";

  if (!code) {
    return NextResponse.redirect(new URL("/login?error=missing_code", request.url));
  }

  const supabase = await createSupabaseServerClient();
  if (!supabase) {
    return NextResponse.redirect(new URL("/login?error=supabase_not_configured", request.url));
  }

  const { error } = await supabase.auth.exchangeCodeForSession(code);
  if (error) {
    return NextResponse.redirect(new URL("/login?error=callback_failed", request.url));
  }

  // Sincronizar el perfil en la base (mejor esfuerzo: no bloquear el login).
  try {
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (user?.id && user.email) {
      await db
        .insert(schema.profiles)
        .values({
          id: user.id,
          email: user.email,
          fullName:
            typeof user.user_metadata?.full_name === "string"
              ? user.user_metadata.full_name
              : null,
          avatarUrl:
            typeof user.user_metadata?.avatar_url === "string"
              ? user.user_metadata.avatar_url
              : null,
          updatedAt: new Date(),
        })
        .onConflictDoUpdate({
          target: schema.profiles.id,
          set: { email: user.email, updatedAt: new Date() },
        });
    }
  } catch (err) {
    logger.warn("No se pudo sincronizar el perfil en el callback", {
      error: err instanceof Error ? err.message : String(err),
    });
  }

  return NextResponse.redirect(new URL(safeNext, request.url));
}
