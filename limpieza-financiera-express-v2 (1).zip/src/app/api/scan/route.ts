import { NextResponse } from "next/server";
import { requireCurrentUser } from "@/lib/auth";
import { detectSubscriptions } from "@/lib/detection";
import { mockEmails } from "@/lib/detection/mock-emails";
import { syncEmails, getProviderAccessToken, IngestionError } from "@/lib/ingestion";
import { persistDetections } from "@/lib/persistence";
import { isSupabaseConfigured } from "@/lib/supabase/config";
import { logger } from "@/lib/logger";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

/**
 * POST /api/scan — ejecuta el motor de detección y persiste las suscripciones.
 *
 * Flujo completo:
 *   1. Autentica al usuario (Supabase).
 *   2. Obtiene el access token del proveedor (Gmail/Outlook).
 *   3. Sincroniza los emails reales (metadata, readonly).
 *   4. Ejecuta el motor de detección (reglas + IA).
 *   5. Persiste las suscripciones en PostgreSQL.
 *
 * Degradación: en desarrollo (sin Supabase) usa datos mock para validar la UI.
 * En producción, sin token de proveedor devuelve error accionable.
 */
export async function POST() {
  const user = await requireCurrentUser();

  // Desarrollo sin Supabase: usamos mock para poder probar la UI.
  if (!isSupabaseConfigured()) {
    const result = await detectSubscriptions(mockEmails);
    return NextResponse.json({
      ok: true,
      mock: true,
      emailsScanned: result.emailsScanned,
      emailsFinancial: result.emailsFinancial,
      subscriptionsFound: result.subscriptions.length,
      subscriptions: result.subscriptions,
    });
  }

  // 1. Token del proveedor.
  const accessToken = await getProviderAccessToken();

  if (!accessToken) {
    const message =
      "No hay conexión con tu correo. Vuelve a conectarlo aceptando el permiso de solo lectura.";
    logger.warn("Escaneo sin token de proveedor", { userId: user.id });
    return NextResponse.json({ ok: false, error: message }, { status: 400 });
  }

  // 2. Sincronizar emails reales.
  let emails;
  try {
    emails = await syncEmails("gmail", accessToken);
  } catch (error) {
    if (error instanceof IngestionError && error.status === 401) {
      const message =
        "El permiso de tu correo venció o fue revocado. Vuelve a conectar tu cuenta.";
      return NextResponse.json({ ok: false, error: message }, { status: 401 });
    }
    if (error instanceof IngestionError && error.status === 429) {
      const message = "Alcanzaste la cuota del proveedor. Intenta de nuevo en unos minutos.";
      return NextResponse.json({ ok: false, error: message }, { status: 429 });
    }
    logger.error("Error sincronizando emails", {
      userId: user.id,
      error: error instanceof Error ? error.message : String(error),
    });
    return NextResponse.json(
      { ok: false, error: "No se pudieron sincronizar tus correos." },
      { status: 502 },
    );
  }

  // 3. Detección (si no hay emails, el resultado es 0 suscripciones, correcto).
  const result = await detectSubscriptions(emails);

  // 4. Persistencia (mejor esfuerzo).
  let persisted = 0;
  try {
    persisted = await persistDetections(user.id, result);
  } catch (err) {
    logger.warn("No se pudo persistir el escaneo (¿falta DATABASE_URL?)", {
      userId: user.id,
      error: err instanceof Error ? err.message : String(err),
    });
  }

  return NextResponse.json({
    ok: true,
    emailsScanned: result.emailsScanned,
    emailsFinancial: result.emailsFinancial,
    subscriptionsFound: result.subscriptions.length,
    persisted,
    subscriptions: result.subscriptions,
  });
}
