import Link from "next/link";
import { Mail, ShieldCheck } from "lucide-react";
import { isSupabaseConfigured } from "@/lib/supabase/config";

export const dynamic = "force-dynamic";

export default function LoginPage() {
  const configured = isSupabaseConfigured();

  return (
    <main className="container flex min-h-screen max-w-md flex-col justify-center py-12">
      <Link href="/" className="mb-8 text-slate-700 hover:text-primary">
        ← Volver al inicio
      </Link>

      <h1 className="text-3xl font-bold tracking-tight">Iniciá sesión</h1>
      <p className="mt-3 text-lg text-slate-700">
        Conectá tu correo para descubrir y cancelar suscripciones olvidadas.
      </p>

      {!configured ? (
        <div className="mt-6 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800">
          Supabase no está configurado en este entorno. Definí{" "}
          <code className="font-mono">NEXT_PUBLIC_SUPABASE_URL</code> y{" "}
          <code className="font-mono">NEXT_PUBLIC_SUPABASE_ANON_KEY</code> para habilitar el
          login.
        </div>
      ) : null}

      <div className="mt-6 grid gap-3">
        <form action="/api/auth/signin" method="post">
          <input type="hidden" name="provider" value="gmail" />
          <input type="hidden" name="next" value="/dashboard" />
          <button
            type="submit"
            disabled={!configured}
            className="flex h-14 w-full items-center justify-center gap-3 rounded-lg border text-lg font-semibold transition-colors hover:bg-muted disabled:cursor-not-allowed disabled:opacity-50"
          >
            <Mail className="size-6 text-primary" aria-hidden />
            Continuar con Gmail
          </button>
        </form>

        <form action="/api/auth/signin" method="post">
          <input type="hidden" name="provider" value="outlook" />
          <input type="hidden" name="next" value="/dashboard" />
          <button
            type="submit"
            disabled={!configured}
            className="flex h-14 w-full items-center justify-center gap-3 rounded-lg border text-lg font-semibold transition-colors hover:bg-muted disabled:cursor-not-allowed disabled:opacity-50"
          >
            <Mail className="size-6 text-primary" aria-hidden />
            Continuar con Outlook
          </button>
        </form>
      </div>

      <p className="mt-6 flex items-start gap-2 text-sm text-slate-600">
        <ShieldCheck className="mt-0.5 size-5 shrink-0 text-success" aria-hidden />
        Acceso de solo lectura. Nunca vemos el contenido de tus correos.
      </p>
    </main>
  );
}
