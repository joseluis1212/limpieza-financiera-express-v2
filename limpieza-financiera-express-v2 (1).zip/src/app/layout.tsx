import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "Limpieza Financiera Express",
    template: "%s · Limpieza Financiera Express",
  },
  description:
    "Te recuperamos el dinero que estás tirando todos los meses. Encontrá y cancelá tus suscripciones olvidadas. Solo cobramos si te ahorramos dinero.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="es">
      <body className="min-h-screen bg-background font-sans text-foreground">
        {children}
      </body>
    </html>
  );
}
