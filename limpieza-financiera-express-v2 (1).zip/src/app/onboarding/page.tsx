"use client";

import { useState } from "react";
import Link from "next/link";
import { ArrowLeft, CheckCircle2, EyeOff, Lock, Mail, ShieldCheck } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useOnboardingStore, type Provider } from "@/store/use-onboarding";

/**
 * Onboarding: elegir proveedor → consentimiento claro → OAuth real.
 * El consentimiento granular es requerido por Google (verificación CASA) y por
 * las leyes de datos de AR/MX/US.
 */
export default function OnboardingPage() {
  const { provider, setProvider, step, setStep } = useOnboardingStore();
  const [accepted, setAccepted] = useState(false);

  const choose = (p: Provider) => {
    setProvider(p);
    setStep("consent");
  };

  if (step === "welcome") {
    return (
      <main className="container flex min-h-screen max-w-2xl flex-col justify-center py-12">
        <Link href="/" className="mb-8 inline-flex items-center gap-2 text-slate-700 hover:text-primary">
          <ArrowLeft className="size-5" aria-hidden /> Volver al inicio
        </Link>

        <Badge variant="success" className="mb-4 w-fit">
          Gratis · solo lectura
        </Badge>
        <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">
          Conectá tu correo para empezar
        </h1>
        <p className="mt-3 text-lg text-slate-700">
          Elegí la cuenta donde recibís tus facturas y suscripciones.
        </p>

        <div className="mt-8 grid gap-4">
          {(
            [
              { id: "gmail", label: "Continuar con Gmail" },
              { id: "outlook", label: "Continuar con Outlook" },
            ] as { id: Provider; label: string }[]
          ).map(({ id, label }) => (
            <button
              key={id}
              type="button"
              onClick={() => choose(id)}
              className="flex h-14 items-center justify-center gap-3 rounded-lg border text-lg font-semibold transition-colors hover:bg-muted"
            >
              <Mail className="size-6 text-primary" aria-hidden />
              {label}
            </button>
          ))}
        </div>
      </main>
    );
  }

  // Paso 2: consentimiento + OAuth real.
  return (
    <main className="container flex min-h-screen max-w-2xl flex-col justify-center py-12">
      <Link href="/" className="mb-8 inline-flex items-center gap-2 text-slate-700 hover:text-primary">
        <ArrowLeft className="size-5" aria-hidden /> Volver al inicio
      </Link>

      <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">
        Antes de continuar, que quede claro
      </h1>

      <div className="mt-8 space-y-3 rounded-2xl border bg-white p-6">
        {[
          { icon: ShieldCheck, text: "Acceso de SOLO LECTURA" },
          { icon: EyeOff, text: "Solo leemos asuntos, remitentes y datos de pagos" },
          { icon: Lock, text: "Nunca leemos el contenido completo de tus correos" },
          { icon: CheckCircle2, text: "Nunca borramos ni enviamos correos" },
        ].map(({ icon: Icon, text }) => (
          <div key={text} className="flex items-center gap-3 text-slate-700">
            <Icon className="size-6 shrink-0 text-success" aria-hidden />
            {text}
          </div>
        ))}
      </div>

      <label className="mt-6 flex cursor-pointer items-start gap-3 text-slate-700">
        <input
          type="checkbox"
          checked={accepted}
          onChange={(e) => setAccepted(e.target.checked)}
          className="mt-1 size-5 accent-primary"
        />
        <span>
          Acepto los{" "}
          <Link href="/terminos" className="text-primary underline">
            Términos
          </Link>{" "}
          y la{" "}
          <Link href="/privacidad" className="text-primary underline">
            Política de privacidad
          </Link>
          .
        </span>
      </label>

      <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
        {/* Form que dispara el OAuth real vía Supabase */}
        <form action="/api/auth/signin" method="post">
          <input type="hidden" name="provider" value={provider ?? "gmail"} />
          <input type="hidden" name="next" value="/dashboard" />
          <Button type="submit" size="lg" disabled={!accepted}>
            Entiendo y quiero continuar
          </Button>
        </form>
        <Button size="lg" variant="ghost" onClick={() => setStep("welcome")}>
          Volver
        </Button>
      </div>
    </main>
  );
}
