# Limpieza Financiera Express — Sistema de Diseño & UI

> Diseño orientado a **todos**: jóvenes, adultos y personas mayores. Principios rectores:
> **confianza, simplicidad, legibilidad.** Accesible por defecto (WCAG 2.2 AA).

---

## 1. Sistema de Diseño (Design Tokens)

### 1.1 Paleta de colores

| Token | Color | Hex | Uso |
|---|---|---|---|
| `primary` (azul confiable) | Blue-600 | `#2563EB` | Botones principales, enlaces, acentos |
| `primary-hover` | Blue-700 | `#1D4ED8` | Hover de botones (contraste 7.7:1 sobre blanco) |
| `success` (verde ahorro) | Emerald-600 | `#059669` | Ahorros, números positivos, "cancelado", éxito |
| `success-soft` | Emerald-50 | `#ECFDF5` | Fondos de tarjetas de ahorro |
| `background` | Blanco | `#FFFFFF` | Fondo principal |
| `muted` (gris claro) | Slate-50 | `#F8FAFC` | Superficies secundarias, fondos de sección |
| `border` | Slate-200 | `#E2E8F0` | Bordes, divisores |
| `text-primary` | Slate-900 | `#0F172A` | Títulos (contraste 17:1) |
| `text-body` | Slate-700 | `#334155` | Cuerpo (contraste 7.5:1) |
| `text-muted` | Slate-600 | `#475569` | Solo texto no esencial |
| `destructive` | Red-600 | `#DC2626` | Errores, "eliminar" |
| `warning` | Amber-600 | `#D97706` | Trials a punto de cobrar |

**Regla de accesibilidad:** todo texto esencial usa `text-primary` o `text-body`. El gris
claro (`slate-400/500`) **nunca** se usa para texto importante.

### 1.2 Tipografía

- **Familia:** Inter (fallback: `system-ui, -apple-system, sans-serif`).
- **Escala (grande, para lectura cómoda):**

| Token | Tamaño | Uso |
|---|---|---|
| Display | `clamp(2.25rem, 5vw, 3.75rem)` / 800 | H1 de hero |
| H1 | `2.5rem` / 800 | Títulos de página |
| H2 | `1.875rem` / 700 | Secciones |
| H3 | `1.375rem` / 700 | Subtítulos |
| Body | `1.0625rem` (17px) / 400 | Texto general |
| Body-large | `1.125rem` (18px) | Párrafos clave |
| Small | `0.875rem` (14px) | Solo metadatos no esenciales |

- **Line-height:** títulos `1.2`, cuerpo `1.6`.
- **Mínimo absoluto:** nunca texto por debajo de 14px para contenido.

### 1.3 Espaciado y layout

- Base 4px. Secciones con `py-16` a `py-24` (aire generoso).
- Contenedor máximo **1120px** (`max-w-6xl`), centrado.
- Tarjetas con `p-6` a `p-8`, radio `rounded-2xl` (0.75–1rem).
- Mucho **espacio en blanco**: nunca dos bloques densos juntos.

### 1.4 Iconos

- [lucide-react](https://lucide.dev) (trazo 2px, simples y reconocibles).
- Siempre acompañados de texto (nunca icono solo como única señal).

### 1.5 Accesibilidad (requisitos obligatorios)

1. **Contraste AA** (4.5:1 normal, 3:1 grande) en todo el texto.
2. **Targets táctiles ≥ 44×44px** (botones default `h-12` = 48px).
3. **Focus visible** en todo elemento interactivo (ring 2px + offset 2px).
4. **`prefers-reduced-motion`** respetado (animaciones sutiles se desactivan).
5. **HTML semántico**: `header`, `nav`, `main`, `section`, `footer`, landmarks.
6. **Skip link** "Saltar al contenido" al inicio.
7. **`aria-live`** en zonas dinámicas (progreso de escaneo, confirmaciones).
8. **Formularios con labels** explícitos asociados, nunca solo placeholder.
9. Lenguaje **simple, sin tecnicismos**, en voz activa y amigable.

---

## 2. Landing Page — diseño detallado

### Objetivo
Convertir: transmitir confianza, explicar el valor en 5 segundos, y llevar al usuario a
"Escanear mi correo" (única acción principal repetida).

### Estructura (top → bottom)

| # | Sección | Propósito |
|---|---|---|
| 1 | Skip link + Header sticky | Navegación + CTA siempre visible |
| 2 | Hero | Propuesta de valor + CTA + confianza |
| 3 | Barra de confianza | "Solo lectura" + proveedores |
| 4 | Cómo funciona (3 pasos) | Entender el proceso en segundos |
| 5 | El costo de no hacer nada | Dolor + urgencia (con ejemplo visual) |
| 6 | Beneficios (grid 6) | Razones para confiar |
| 7 | Precios transparentes | "Solo cobramos si ahorrás" |
| 8 | Testimonios (3) | Prueba social |
| 9 | Preguntas frecuentes (FAQ) | Objeciones |
| 10 | CTA final | Última oportunidad de conversión |
| 11 | Footer | Legal + idioma |

### 2.1 Header (sticky)

- **Izquierda:** logo (icono de escudo/ahorro) + "Limpieza Financiera Express".
- **Centro (desktop):** Cómo funciona · Precios · Preguntas.
- **Derecha:** CTA primario **"Escanear mi correo"**.
- **Mobile:** menú hamburguesa con las mismas opciones.
- **Accesibilidad:** `aria-label="Menú principal"`, focus trap en el menú móvil, contraste alto.

### 2.2 Hero

```
[Badge: ✅ Solo cobramos si te ahorramos dinero]

H1 (Display): Te recuperamos el dinero que estás
              tirando todos los meses.

Sub (18px): Conectá tu correo y te mostramos todas las suscripciones que
            tenés activas, las olvidadas y las pruebas gratis a punto de
            cobrarte. Sin leer tus emails. Sin cargos sorpresa.

[ Botón primario: Escanear mi correo gratis → ]   [ Ver cómo funciona ]

✓ Solo lectura, nunca vemos tus correos
✓ Sin cargos: te mostramos el monto antes de cobrar
✓ Para Argentina, México y Estados Unidos
```

- Fondo blanco con acento azul muy sutil. A la derecha (desktop), **mockup del dashboard**
  (tarjeta con "Ahorro potencial" y lista de suscripciones) — comunica el resultado antes de
  explicar el proceso.
- **Accesibilidad:** contraste máximo en H1; CTA con `aria-label` descriptivo; el mockup es
  decorativo (`aria-hidden`).

### 2.3 Cómo funciona (3 pasos)

Tarjetas numeradas grandes (1, 2, 3) con icono + título + texto simple:

1. **Conectá tu correo** — "Gmail o Outlook, en un clic. Solo lectura."
2. **Encontramos todo** — "Suscripciones activas, olvidadas y trials."
3. **Cancelás y ahorrás** — "Pagás solo un % de lo que recuperás."

### 2.4 Precios (transparencia como feature)

3 tarjetas, sin letra chica:

- **Gratis** — "Escaneo completo + ahorro potencial. $0 siempre."
- **Por resultado** — "30% del ahorro del primer año. Te mostramos el monto exacto antes."
- **Pago fijo (Argentina)** — "$24.900 una vez, 12 meses de monitoreo."

Cada tarjeta con botón claro y texto accesible. Badge "Más elegido" en la de por-resultado.

### 2.5 FAQ

Acordeón con preguntas reales: *¿Ven mis correos? ¿Cuánto me cobran? ¿Y si no ahorro nada?
¿Cómo sé cuánto ahorré?* Respuestas cortas y en lenguaje simple.

---

## 3. Dashboard principal — diseño detallado

### 3.1 Layout general

```
┌───────────────────────────────────────────────────────────┐
│ [logo]  Resumen  Suscripciones  Ahorro  Configuración   [avatar] │
├───────────────────────────────────────────────────────────┤
│ "Hola, María 👋"          [Conectado: Gmail ✓]            │
│                                                           │
│ ┌──────────────┐ ┌─────────┐ ┌─────────┐ ┌──────────────┐ │
│ │ Ahorro       │ │ Suscrip.│ │ Olvidadas│ │ Trials        │ │
│ │ potencial    │ │   8     │ │   3     │ │ a cobrar: 2   │ │
│ │ $XX.XXX/mes  │ │         │ │         │ │ (cobra el 01/09)│ │
│ └──────────────┘ └─────────┘ └─────────┘ └──────────────┘ │
│                                                           │
│ [Filtros: Todas | Activas | Olvidadas | Trials]           │
│                                                           │
│ ┌ Tarjeta suscripción ┐ ┌ Tarjeta suscripción ┐           │
│ │ ...                 │ │ ...                 │           │
└───────────────────────────────────────────────────────────┘
```

### 3.2 Elementos y organización

- **Navegación lateral (desktop) / superior (mobile).** Ítems con icono + texto.
- **Encabezado:** saludo con nombre ("Hola, María"), estado de conexión (verde = conectado).
- **Banda de métricas (4 tarjetas):** la primera (Ahorro potencial) es la dominante, en verde,
  con número grande. Las demás en gris claro.
- **Filtros:** píldoras grandes táctiles, con contador.
- **Lista de suscripciones:** tarjetas verticales, una por suscripción.

### 3.3 Tarjeta de suscripción (elemento central)

```
┌───────────────────────────────────────────────────────┐
│ [icono] Netflix          [badge: Streaming]   [● alta] │
│                                                       │
│ $9.999 / mes                         Último: 05/08    │
│ (grande, negrita)                    Próximo: 05/09   │
│                                                       │
│ "Hace 3 meses sin uso"  (solo si aplica)              │
│                                                       │
│ [ Cancelar ]   [ Lo uso, mantener ]                   │
└───────────────────────────────────────────────────────┘
```

- **Jerarquía:** nombre del comercio (H3), monto (grande, negrita), categoría (badge), fechas
  (small, muted), estado de uso (solo si detectado).
- **Confianza:** indicador de confianza de detección (alta/media/baja) con tooltip simple.
- **Acciones:** dos botones grandes con contraste diferenciado — "Cancelar" (primario/azul) y
  "Lo uso, mantener" (secundario/outline). Ambos ≥ 48px.
- **Accesibilidad:** el monto con su moneda explícita; el badge de categoría con texto (no solo
  color); la acción destructiva se confirma en un segundo paso.

### 3.4 Estados

- **Cargando:** skeleton (esqueleto gris) — nunca pantalla en blanco.
- **Vacío:** "Todavía no encontramos suscripciones. Volvé a escanear o conectá otro correo."
- **Error:** mensaje claro con acción ("Reintentar").
- **Trial a punto de cobrar:** tarjeta con borde ámbar + "Te cobrarán $X el DD/MM".

### 3.5 Detalle de suscripción (al tocar una tarjeta)

Panel/drawer con: historial de cargos (lista de fechas y montos), frecuencia, y las acciones
de cancelación. Botón "Cancelar esta suscripción" + "Mantenerla".

---

## 4. Lenguaje de botones y mensajes (sugeridos)

| Contexto | Texto |
|---|---|
| CTA principal | "Escanear mi correo gratis" |
| CTA secundario | "Ver cómo funciona" |
| Conectar email | "Continuar con Google" / "Continuar con Outlook" |
| Consentimiento | "Entiendo y quiero continuar" |
| Escaneando | "Analizando tu correo… esto toma menos de un minuto" |
| Cancelar | "Cancelar esta suscripción" |
| Mantener | "Lo uso, mantenerla" |
| Confirmar cancelación | "Sí, quiero cancelarla" |
| Éxito | "¡Listo! Vas a ahorrar $X por año" |
| Cobro del fee | "Te cobramos $X solo porque el ahorro se confirmó" |

---

## 5. Notas de implementación (resumen)

- Base 17px, botones ≥ 48px, contraste AA, `prefers-reduced-motion`, skip-link, landmarks.
- El verde (`success`) se reserva para **ahorro y éxito**; el azul (`primary`) para **acciones**.
- Animaciones sutiles: fade-in de tarjetas (150–200ms), sin parallax ni movimientos bruscos.
