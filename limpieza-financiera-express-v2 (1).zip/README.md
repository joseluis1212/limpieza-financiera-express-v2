# Limpieza Financiera Express — v2 (rebuild de producción)

> **Tagline:** Te recuperamos el dinero que estás tirando todos los meses.

Rebuild completo de la plataforma con stack moderno y accesible por diseño.

## Stack

- **Next.js 15** (App Router) + **React 19** + **TypeScript**
- **TailwindCSS 3.4** + **shadcn/ui** (new-york)
- **Zustand** para estado global del cliente
- **lucide-react** para iconos

## Cómo correrlo

```bash
npm install
npm run dev        # http://localhost:3000
```

## Estructura y diseño

- Ver `STRUCTURE.md` para el árbol de carpetas completo.
- Ver `DESIGN.md` para el sistema de diseño (tokens, paleta, accesibilidad) y las
  especificaciones detalladas de la Landing Page y el Dashboard.

## Estado actual

Implementado:
- ✅ Sistema de diseño (tokens en `globals.css` + `tailwind.config.ts`)
- ✅ Componentes base shadcn/ui (`button`, `card`, `badge`)
- ✅ Landing Page completa (12 secciones)
- ✅ Onboarding (elegir proveedor + consentimiento, con Zustand)
- ✅ **Dashboard de resultados** (métricas, filtros, tarjeta de suscripción)
- ✅ **Detalle de suscripción** (drawer con historial y ahorro estimado)
- ✅ **Flujo de cancelación** (fee transparente → guía → verificación → éxito)
- ✅ **Página de pago** del success fee (MercadoPago/Stripe)
- ✅ **Pantalla de éxito** + **dashboard final post-pago**
- ✅ **Motor de detección** (reglas + IA + deduplicación) con 26 tests
- ✅ Endpoint `/api/scan` que ejecuta el motor
- ✅ **Supabase Auth** (OAuth Gmail/Outlook, middleware de sesión, login, callback, signout)
- ✅ **Persistencia** (PostgreSQL/Drizzle: 5 tablas + migración + RLS)
- ✅ **Ingestión real de emails** (Gmail API + Microsoft Graph, solo lectura)
- ✅ Endpoints `/api/auth/*`, `/api/scan`, `/api/subscriptions`

Pendiente (próximas iteraciones):
- ⬜ Refresh automático del token del proveedor (Supabase Edge Function)
- ⬜ Cifrado de tokens OAuth (KMS/Vault)
- ⬜ i18n (es-AR / es-MX / en-US) y páginas legales
- ⬜ Cobro real del fee (Stripe PaymentIntent / MercadoPago)
