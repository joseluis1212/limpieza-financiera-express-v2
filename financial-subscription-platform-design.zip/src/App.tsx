import { useEffect } from "react";
import { HashRouter, Navigate, Route, Routes, useLocation } from "react-router-dom";
import { AppProvider } from "@/lib/store";
import { AppShell, Layout } from "@/components/Layout";
import Landing from "@/screens/Landing";
import Onboarding from "@/screens/Onboarding";
import Scanning from "@/screens/Scanning";
import Dashboard from "@/screens/Dashboard";
import Subscriptions from "@/screens/Subscriptions";
import SubscriptionDetail from "@/screens/SubscriptionDetail";
import CancelFlow from "@/screens/CancelFlow";
import Success from "@/screens/Success";
import FinalDashboard from "@/screens/FinalDashboard";

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

export default function App() {
  return (
    <AppProvider>
      <HashRouter>
        <ScrollToTop />
        <Routes>
          <Route
            path="/"
            element={
              <Layout>
                <Landing />
              </Layout>
            }
          />
          <Route
            path="/onboarding"
            element={
              <AppShell>
                <Onboarding />
              </AppShell>
            }
          />
          <Route
            path="/scanning"
            element={
              <AppShell>
                <Scanning />
              </AppShell>
            }
          />
          <Route
            path="/dashboard"
            element={
              <AppShell>
                <Dashboard />
              </AppShell>
            }
          />
          <Route
            path="/subscriptions"
            element={
              <AppShell>
                <Subscriptions />
              </AppShell>
            }
          />
          <Route
            path="/subscription/:id"
            element={
              <AppShell>
                <SubscriptionDetail />
              </AppShell>
            }
          />
          <Route
            path="/cancel/:id"
            element={
              <AppShell>
                <CancelFlow />
              </AppShell>
            }
          />
          <Route
            path="/cancel"
            element={
              <AppShell>
                <CancelFlow />
              </AppShell>
            }
          />
          <Route
            path="/success"
            element={
              <AppShell>
                <Success />
              </AppShell>
            }
          />
          <Route
            path="/final"
            element={
              <AppShell>
                <FinalDashboard />
              </AppShell>
            }
          />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </HashRouter>
    </AppProvider>
  );
}
