import type { Country, Localized } from "./types";

export interface CountryConfig {
  code: Country;
  name: Localized;
  currency: "ARS" | "MXN" | "USD";
  locale: string;
  flag: string;
  /** Tipo de cambio de referencia: 1 USD = X moneda local */
  rateToUsd: number;
  /** Success fee (porcentaje del ahorro anual del primer año) */
  feePercent: number;
  /** Opción de pago fijo en moneda local (solo algunos países) */
  fixedFee?: number;
  /** Decimales a mostrar en precios */
  fractionDigits: number;
}

export const COUNTRIES: Record<Country, CountryConfig> = {
  AR: {
    code: "AR",
    name: { es: "Argentina", en: "Argentina" },
    currency: "ARS",
    locale: "es-AR",
    flag: "🇦🇷",
    rateToUsd: 1050,
    feePercent: 0.3,
    fixedFee: 24900,
    fractionDigits: 0,
  },
  MX: {
    code: "MX",
    name: { es: "México", en: "Mexico" },
    currency: "MXN",
    locale: "es-MX",
    flag: "🇲🇽",
    rateToUsd: 18.5,
    feePercent: 0.35,
    fractionDigits: 0,
  },
  US: {
    code: "US",
    name: { es: "Estados Unidos", en: "United States" },
    currency: "USD",
    locale: "en-US",
    flag: "🇺🇸",
    rateToUsd: 1,
    feePercent: 0.4,
    fractionDigits: 2,
  },
};

export const COUNTRY_ORDER: Country[] = ["AR", "MX", "US"];

export function getCountry(code: Country): CountryConfig {
  return COUNTRIES[code];
}

/** Convierte un monto en USD a moneda local */
export function toLocal(usd: number, country: Country): number {
  return usd * COUNTRIES[country].rateToUsd;
}

/** Formatea dinero local a partir de un monto base en USD */
export function formatMoney(
  usd: number,
  country: Country,
  opts?: { compact?: boolean; fractionDigits?: number }
): string {
  const cfg = COUNTRIES[country];
  const value = toLocal(usd, country);
  return new Intl.NumberFormat(cfg.locale, {
    style: "currency",
    currency: cfg.currency,
    notation: opts?.compact ? "compact" : "standard",
    minimumFractionDigits: 0,
    maximumFractionDigits: opts?.fractionDigits ?? cfg.fractionDigits,
  }).format(value);
}

/** Formatea un número en moneda local (ya convertido, sin símbolo de base) */
export function formatLocalAmount(amount: number, country: Country): string {
  const cfg = COUNTRIES[country];
  return new Intl.NumberFormat(cfg.locale, {
    style: "currency",
    currency: cfg.currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: cfg.fractionDigits,
  }).format(amount);
}

export function formatPercent(pct: number): string {
  return `${Math.round(pct * 100)}%`;
}

export interface FeeResult {
  annualSavingsUsd: number;
  annualSavingsLocal: number;
  /** Fee calculado como % del ahorro */
  percentFeeLocal: number;
  /** Fee fijo (si aplica) */
  fixedFeeLocal?: number;
  /** La opción más conveniente para el usuario */
  bestFeeLocal: number;
  bestFeeLabel: "percent" | "fixed";
  bestFeeUsd: number;
}

/** Calcula el success fee y la opción más conveniente para el usuario */
export function computeFee(annualSavingsUsd: number, country: Country): FeeResult {
  const cfg = COUNTRIES[country];
  const annualSavingsLocal = toLocal(annualSavingsUsd, country);
  const percentFeeLocal = annualSavingsLocal * cfg.feePercent;
  const fixedFeeLocal = cfg.fixedFee;

  const useFixed = fixedFeeLocal != null && fixedFeeLocal < percentFeeLocal;
  const bestFeeLocal = useFixed ? fixedFeeLocal! : percentFeeLocal;

  return {
    annualSavingsUsd,
    annualSavingsLocal,
    percentFeeLocal,
    fixedFeeLocal,
    bestFeeLocal,
    bestFeeLabel: useFixed ? "fixed" : "percent",
    bestFeeUsd: toLocal(annualSavingsUsd, country) === 0 ? 0 : bestFeeLocal / cfg.rateToUsd,
  };
}
