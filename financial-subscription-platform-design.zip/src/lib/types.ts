export type Lang = "es" | "en";
export type Country = "AR" | "MX" | "US";
export type Currency = "ARS" | "MXN" | "USD";

/** Texto localizado español / inglés */
export type Localized = { es: string; en: string };
/** Lista de textos localizados */
export type LocalizedArr = { es: string[]; en: string[] };

export type SubStatus = "activa" | "olvidada" | "trial" | "cancelando";
export type CancelMethod = "automatica" | "guiada" | "manual";

export interface Subscription {
  id: string;
  /** Nombre visible de la marca */
  name: string;
  /** Clave de categoría */
  category: string;
  /** Costo mensual en USD (moneda base de cálculo) */
  monthlyUsd: number;
  /** Fecha del último cobro (ISO) */
  lastCharge: string;
  /** Fecha del próximo cobro (ISO) */
  nextCharge: string;
  status: SubStatus;
  /** Método de cancelación detectado */
  method: CancelMethod;
  /** Confianza de detección 0-100 */
  confidence: number;
  /** Cantidad de correos detectados */
  emailsFound: number;
  emoji: string;
  /** Color de fondo del avatar */
  color: string;
  description: Localized;
  /** Marcada como "olvidada" (no usada en meses) */
  isForgotten: boolean;
  /** Meses sin uso aparente */
  monthsIdle?: number;
}

export interface Testimonial {
  name: string;
  location: Localized;
  quote: Localized;
  savingsUsd: number;
  initials: string;
  color: string;
}

export interface FaqItem {
  q: Localized;
  a: Localized;
}

export interface CategoryInfo {
  key: string;
  label: Localized;
  emoji: string;
}
