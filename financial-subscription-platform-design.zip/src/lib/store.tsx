import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import type { Country, Lang } from "./types";
import { COUNTRIES } from "./currency";
import { t } from "./i18n";

interface AppContextValue {
  lang: Lang;
  setLang: (l: Lang) => void;
  country: Country;
  setCountry: (c: Country) => void;
  email: string | null;
  setEmail: (e: string | null) => void;
  selected: string[];
  toggleSelected: (id: string) => void;
  setSelected: (ids: string[]) => void;
  cancelled: string[];
  markCancelled: (id: string) => void;
  paid: boolean;
  setPaid: (v: boolean) => void;
  reset: () => void;
  t: ReturnType<typeof t>;
}

const AppContext = createContext<AppContextValue | null>(null);

function readLang(): Lang {
  try {
    const v = localStorage.getItem("lfe_lang");
    return v === "en" ? "en" : "es";
  } catch {
    return "es";
  }
}

function readCountry(): Country {
  try {
    const v = localStorage.getItem("lfe_country") as Country;
    return v && v in COUNTRIES ? v : "AR";
  } catch {
    return "AR";
  }
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(readLang);
  const [country, setCountryState] = useState<Country>(readCountry);
  const [email, setEmail] = useState<string | null>(null);
  const [selected, setSelected] = useState<string[]>([]);
  const [cancelled, setCancelled] = useState<string[]>([]);
  const [paid, setPaid] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem("lfe_lang", lang);
    } catch {
      /* ignore */
    }
  }, [lang]);

  useEffect(() => {
    try {
      localStorage.setItem("lfe_country", country);
    } catch {
      /* ignore */
    }
  }, [country]);

  const setLang = useCallback((l: Lang) => setLangState(l), []);
  const setCountry = useCallback((c: Country) => setCountryState(c), []);

  const toggleSelected = useCallback((id: string) => {
    setSelected((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  }, []);

  const markCancelled = useCallback((id: string) => {
    setCancelled((prev) => (prev.includes(id) ? prev : [...prev, id]));
    setSelected((prev) => prev.filter((x) => x !== id));
  }, []);

  const reset = useCallback(() => {
    setEmail(null);
    setSelected([]);
    setCancelled([]);
    setPaid(false);
  }, []);

  const value = useMemo<AppContextValue>(
    () => ({
      lang,
      setLang,
      country,
      setCountry,
      email,
      setEmail,
      selected,
      toggleSelected,
      setSelected,
      cancelled,
      markCancelled,
      paid,
      setPaid,
      reset,
      t: t(lang),
    }),
    [
      lang,
      setLang,
      country,
      setCountry,
      email,
      selected,
      toggleSelected,
      cancelled,
      markCancelled,
      paid,
      reset,
    ]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp debe usarse dentro de AppProvider");
  return ctx;
}
