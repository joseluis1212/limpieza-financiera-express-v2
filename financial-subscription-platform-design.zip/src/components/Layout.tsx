import { useEffect, useState, type ReactNode } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Menu, X } from "lucide-react";
import { Logo } from "./Logo";
import { Container, LinkButton } from "./ui";
import { useApp } from "@/lib/store";
import { COUNTRIES, COUNTRY_ORDER } from "@/lib/currency";
import { cn } from "@/utils/cn";
import type { Country, Lang } from "@/lib/types";

function useScrollToSection() {
  const navigate = useNavigate();
  const location = useLocation();
  return (id: string) => {
    if (location.pathname !== "/") {
      navigate("/");
      window.setTimeout(() => {
        document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
      }, 120);
    } else {
      document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };
}

function LangToggle({ className }: { className?: string }) {
  const { lang, setLang } = useApp();
  return (
    <div
      className={cn(
        "inline-flex items-center rounded-full border border-line bg-white p-0.5",
        className
      )}
      role="group"
      aria-label="Idioma"
    >
      {(["es", "en"] as Lang[]).map((l) => (
        <button
          key={l}
          type="button"
          onClick={() => setLang(l)}
          aria-pressed={lang === l}
          className={cn(
            "rounded-full px-2.5 py-1 text-xs font-bold uppercase transition-colors",
            lang === l ? "bg-brand text-white" : "text-muted hover:text-ink"
          )}
        >
          {l === "es" ? "ES" : "EN"}
        </button>
      ))}
    </div>
  );
}

function CountrySelect({ className }: { className?: string }) {
  const { country, setCountry, lang, t } = useApp();
  return (
    <label className={cn("relative inline-flex items-center", className)}>
      <span className="sr-only">{t.common.country}</span>
      <select
        value={country}
        onChange={(e) => setCountry(e.target.value as Country)}
        className="cursor-pointer appearance-none rounded-full border border-line bg-white py-1.5 pl-3 pr-8 text-sm font-semibold text-ink transition-colors hover:border-slate-300"
      >
        {COUNTRY_ORDER.map((c) => (
          <option key={c} value={c}>
            {COUNTRIES[c].flag} {COUNTRIES[c].name[lang]}
          </option>
        ))}
      </select>
      <svg
        className="pointer-events-none absolute right-2.5 h-4 w-4 text-muted"
        viewBox="0 0 20 20"
        fill="currentColor"
        aria-hidden="true"
      >
        <path
          fillRule="evenodd"
          d="M5.23 7.21a.75.75 0 011.06.02L10 11.17l3.71-3.94a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z"
          clipRule="evenodd"
        />
      </svg>
    </label>
  );
}

function Header() {
  const { t } = useApp();
  const scrollTo = useScrollToSection();
  const [open, setOpen] = useState(false);

  const navItems = [
    { id: "how", label: t.nav.howItWorks },
    { id: "benefits", label: t.nav.benefits },
    { id: "pricing", label: t.nav.pricing },
    { id: "faq", label: t.nav.faq },
  ];

  return (
    <header className="sticky top-0 z-40 border-b border-line/70 bg-white/85 backdrop-blur-md">
      <Container className="flex h-16 items-center justify-between gap-3">
        <Link to="/" aria-label={t.common.logo} className="shrink-0">
          <Logo title={t.common.logo} suffix={t.common.logoSuffix} />
        </Link>

        <nav className="hidden items-center gap-1 lg:flex" aria-label="Principal">
          {navItems.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => scrollTo(item.id)}
              className="rounded-full px-3.5 py-2 text-sm font-semibold text-muted transition-colors hover:bg-surface hover:text-ink"
            >
              {item.label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-2.5">
          <LangToggle className="hidden sm:inline-flex" />
          <CountrySelect className="hidden md:inline-flex" />
          <LinkButton to="/onboarding" size="sm" className="hidden sm:inline-flex">
            {t.nav.start}
          </LinkButton>
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            className="inline-flex h-10 w-10 items-center justify-center rounded-xl border border-line text-ink lg:hidden"
            aria-label="Menú"
            aria-expanded={open}
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </Container>

      {open && (
        <div className="border-t border-line bg-white lg:hidden">
          <Container className="flex flex-col gap-1 py-4">
            {navItems.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setOpen(false);
                  scrollTo(item.id);
                }}
                className="rounded-xl px-3 py-3 text-left text-base font-semibold text-ink hover:bg-surface"
              >
                {item.label}
              </button>
            ))}
            <div className="mt-2 flex items-center gap-3 border-t border-line pt-4">
              <LangToggle />
              <CountrySelect />
            </div>
            <LinkButton to="/onboarding" className="mt-2 w-full">
              {t.nav.start}
            </LinkButton>
          </Container>
        </div>
      )}
    </header>
  );
}

function Footer() {
  const { t } = useApp();
  const scrollTo = useScrollToSection();

  const productLinks = [
    { id: "how", label: t.footer.links.how },
    { id: "benefits", label: t.footer.links.benefits },
    { id: "pricing", label: t.footer.links.pricing },
    { id: "faq", label: t.footer.links.faq },
  ];
  const companyLinks = [t.footer.links.about, t.footer.links.contact];
  const legalLinks = [t.footer.links.terms, t.footer.links.privacy, t.footer.links.security];

  return (
    <footer className="border-t border-line bg-surface">
      <Container className="py-14">
        <div className="grid gap-10 md:grid-cols-[1.6fr_1fr_1fr_1fr]">
          <div className="max-w-sm">
            <Logo title={t.common.logo} suffix={t.common.logoSuffix} />
            <p className="mt-4 text-muted">{t.footer.tagline}</p>
            <p className="mt-4 text-sm text-muted">{t.footer.disclaimer}</p>
          </div>
          <FooterCol title={t.footer.product}>
            {productLinks.map((l) => (
              <button
                key={l.id}
                type="button"
                onClick={() => scrollTo(l.id)}
                className="text-left text-sm text-muted transition-colors hover:text-ink"
              >
                {l.label}
              </button>
            ))}
          </FooterCol>
          <FooterCol title={t.footer.company}>
            {companyLinks.map((l) => (
              <a
                key={l}
                href="#"
                onClick={(e) => e.preventDefault()}
                className="text-sm text-muted transition-colors hover:text-ink"
              >
                {l}
              </a>
            ))}
          </FooterCol>
          <FooterCol title={t.footer.legal}>
            {legalLinks.map((l) => (
              <a
                key={l}
                href="#"
                onClick={(e) => e.preventDefault()}
                className="text-sm text-muted transition-colors hover:text-ink"
              >
                {l}
              </a>
            ))}
          </FooterCol>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-line pt-6 sm:flex-row">
          <p className="text-sm text-muted">
            © {new Date().getFullYear()} {t.common.logo} {t.common.logoSuffix}. {t.footer.rights}
          </p>
          <div className="flex items-center gap-2.5">
            <LangToggle />
            <CountrySelect />
          </div>
        </div>
      </Container>
    </footer>
  );
}

function FooterCol({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div>
      <h3 className="text-sm font-bold uppercase tracking-wider text-ink">{title}</h3>
      <div className="mt-4 flex flex-col gap-3">{children}</div>
    </div>
  );
}

export function Layout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded-lg focus:bg-white focus:px-4 focus:py-2 focus:text-brand"
      >
        Saltar al contenido
      </a>
      <Header />
      <main id="main" className="flex-1">
        {children}
      </main>
      <Footer />
    </div>
  );
}

/* ----------------------- Shell de la app (flujo) ----------------------- */
export function AppShell({ children }: { children: ReactNode }) {
  const { t } = useApp();
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="flex min-h-screen flex-col bg-surface">
      <header
        className={cn(
          "sticky top-0 z-40 border-b bg-white/90 backdrop-blur-md transition-shadow",
          scrolled ? "border-line shadow-sm" : "border-transparent"
        )}
      >
        <Container className="flex h-16 items-center justify-between gap-3">
          <Link to="/" aria-label={t.common.logo}>
            <Logo title={t.common.logo} suffix={t.common.logoSuffix} />
          </Link>
          <div className="flex items-center gap-2.5">
            <LangToggle />
            <CountrySelect className="hidden sm:inline-flex" />
          </div>
        </Container>
      </header>
      <main className="flex-1">{children}</main>
      <footer className="border-t border-line bg-white py-6">
        <Container className="flex flex-col items-center justify-between gap-3 sm:flex-row">
          <p className="text-sm text-muted">{t.footer.disclaimer}</p>
          <p className="text-sm text-muted">
            © {new Date().getFullYear()} {t.common.logo} {t.common.logoSuffix}
          </p>
        </Container>
      </footer>
    </div>
  );
}

export { LangToggle, CountrySelect };
