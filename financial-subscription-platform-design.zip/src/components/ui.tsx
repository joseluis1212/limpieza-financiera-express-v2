import {
  useEffect,
  useRef,
  type ButtonHTMLAttributes,
  type ReactNode,
} from "react";
import { Link } from "react-router-dom";
import { Check } from "lucide-react";
import { cn } from "@/utils/cn";

/* ----------------------------- Botones ----------------------------- */
export type ButtonVariant =
  | "primary"
  | "secondary"
  | "success"
  | "ghost"
  | "dark"
  | "danger";
export type ButtonSize = "sm" | "md" | "lg";

const buttonBase =
  "inline-flex items-center justify-center gap-2 rounded-full font-semibold transition-all duration-200 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-brand/30 disabled:opacity-50 disabled:pointer-events-none select-none cursor-pointer";

const buttonVariants: Record<ButtonVariant, string> = {
  primary: "bg-brand text-white shadow-sm shadow-brand/20 hover:bg-brand-dark hover:shadow-md",
  secondary:
    "bg-white text-ink border border-line hover:border-slate-300 hover:bg-surface",
  success: "bg-save text-white shadow-sm shadow-save/20 hover:bg-save-dark",
  ghost: "text-brand hover:bg-brand-soft",
  dark: "bg-ink text-white hover:bg-ink-soft",
  danger: "bg-red-600 text-white hover:bg-red-700",
};

const buttonSizes: Record<ButtonSize, string> = {
  sm: "text-sm px-4 py-2",
  md: "text-base px-6 py-3",
  lg: "text-lg px-8 py-4",
};

export function buttonClasses(
  variant: ButtonVariant = "primary",
  size: ButtonSize = "md",
  className?: string
) {
  return cn(buttonBase, buttonVariants[variant], buttonSizes[size], className);
}

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
}

export function Button({
  variant = "primary",
  size = "md",
  className,
  children,
  ...props
}: ButtonProps) {
  return (
    <button className={buttonClasses(variant, size, className)} {...props}>
      {children}
    </button>
  );
}

export function LinkButton({
  to,
  variant = "primary",
  size = "md",
  className,
  children,
}: {
  to: string;
  variant?: ButtonVariant;
  size?: ButtonSize;
  className?: string;
  children: ReactNode;
}) {
  return (
    <Link to={to} className={buttonClasses(variant, size, className)}>
      {children}
    </Link>
  );
}

/* ----------------------------- Badge ----------------------------- */
type BadgeVariant = "brand" | "save" | "neutral" | "warning" | "danger" | "outline";

const badgeVariants: Record<BadgeVariant, string> = {
  brand: "bg-brand-soft text-brand-dark",
  save: "bg-save-soft text-save-dark",
  neutral: "bg-slate-100 text-slate-700",
  warning: "bg-amber-50 text-amber-700",
  danger: "bg-red-50 text-red-700",
  outline: "border border-line text-muted",
};

export function Badge({
  variant = "neutral",
  className,
  children,
}: {
  variant?: BadgeVariant;
  className?: string;
  children: ReactNode;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold",
        badgeVariants[variant],
        className
      )}
    >
      {children}
    </span>
  );
}

/* ----------------------------- Layout helpers ----------------------------- */
export function Container({
  className,
  children,
}: {
  className?: string;
  children: ReactNode;
}) {
  return (
    <div className={cn("mx-auto w-full max-w-6xl px-5 sm:px-8", className)}>
      {children}
    </div>
  );
}

export function Card({
  className,
  children,
  onClick,
}: {
  className?: string;
  children: ReactNode;
  onClick?: () => void;
}) {
  return (
    <div
      onClick={onClick}
      className={cn(
        "rounded-2xl border border-line bg-white shadow-sm shadow-slate-100",
        className
      )}
    >
      {children}
    </div>
  );
}

/* ----------------------------- Section heading ----------------------------- */
export function SectionHeading({
  eyebrow,
  title,
  subtitle,
  align = "center",
  className,
}: {
  eyebrow?: string;
  title: ReactNode;
  subtitle?: ReactNode;
  align?: "center" | "left";
  className?: string;
}) {
  return (
    <div
      className={cn(
        "max-w-2xl",
        align === "center" ? "mx-auto text-center" : "text-left",
        className
      )}
    >
      {eyebrow && (
        <p className="mb-3 text-sm font-bold uppercase tracking-[0.18em] text-save">
          {eyebrow}
        </p>
      )}
      <h2 className="text-3xl font-extrabold tracking-tight text-ink sm:text-4xl">
        {title}
      </h2>
      {subtitle && (
        <p className="mt-4 text-lg leading-relaxed text-muted">{subtitle}</p>
      )}
    </div>
  );
}

/* ----------------------------- Reveal on scroll ----------------------------- */
export function Reveal({
  children,
  className,
  delay = 0,
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            el.classList.add("is-visible");
            obs.disconnect();
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -40px 0px" }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return (
    <div
      ref={ref}
      className={cn("reveal", className)}
      style={delay ? { transitionDelay: `${delay}ms` } : undefined}
    >
      {children}
    </div>
  );
}

/* ----------------------------- Stepper ----------------------------- */
export interface StepState {
  label: string;
  state: "done" | "current" | "todo";
}

export function Stepper({ steps }: { steps: StepState[] }) {
  return (
    <ol className="flex w-full items-center" aria-label="Progreso">
      {steps.map((step, i) => (
        <li
          key={i}
          className={cn("flex items-center", i < steps.length - 1 && "flex-1")}
        >
          <div className="flex flex-col items-center gap-1.5">
            <span
              className={cn(
                "flex h-9 w-9 items-center justify-center rounded-full border-2 text-sm font-bold transition-colors",
                step.state === "done" &&
                  "border-save bg-save text-white",
                step.state === "current" &&
                  "border-brand bg-brand text-white shadow-md shadow-brand/30",
                step.state === "todo" && "border-line bg-white text-muted"
              )}
            >
              {step.state === "done" ? <Check className="h-5 w-5" /> : i + 1}
            </span>
            <span
              className={cn(
                "hidden text-xs font-semibold sm:block",
                step.state === "current"
                  ? "text-ink"
                  : step.state === "done"
                    ? "text-save-dark"
                    : "text-muted"
              )}
            >
              {step.label}
            </span>
          </div>
          {i < steps.length - 1 && (
            <span
              className={cn(
                "mx-2 mb-6 h-0.5 flex-1 rounded sm:mb-0",
                step.state === "done" ? "bg-save" : "bg-line"
              )}
            />
          )}
        </li>
      ))}
    </ol>
  );
}

/* ----------------------------- Stat ----------------------------- */
export function Stat({
  label,
  value,
  icon,
  accent = "text-brand",
  className,
}: {
  label: string;
  value: ReactNode;
  icon?: ReactNode;
  accent?: string;
  className?: string;
}) {
  return (
    <Card className={cn("p-5", className)}>
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-sm font-medium text-muted">{label}</p>
          <p className={cn("mt-2 text-3xl font-extrabold tracking-tight", accent)}>
            {value}
          </p>
        </div>
        {icon && (
          <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-brand-soft text-brand">
            {icon}
          </span>
        )}
      </div>
    </Card>
  );
}
