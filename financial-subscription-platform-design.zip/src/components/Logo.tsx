import { useId } from "react";
import { cn } from "@/utils/cn";

export function LogoMark({ className }: { className?: string }) {
  const id = useId();
  return (
    <svg viewBox="0 0 40 40" className={className} aria-hidden="true">
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#3b82f6" />
          <stop offset="100%" stopColor="#1d4ed8" />
        </linearGradient>
      </defs>
      <rect width="40" height="40" rx="11" fill={`url(#${id})`} />
      <path
        d="M12 20.5l5.4 5.4L28.5 14.5"
        fill="none"
        stroke="#ffffff"
        strokeWidth="3.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="29" cy="11" r="6.5" fill="#059669" stroke="#ffffff" strokeWidth="1.8" />
      <path
        d="M29 8.2v5.6M26.2 11h5.6"
        fill="none"
        stroke="#ffffff"
        strokeWidth="2.2"
        strokeLinecap="round"
      />
    </svg>
  );
}

export function Logo({
  title = "Limpieza Financiera",
  suffix = "Express",
  className,
  textClassName,
  showText = true,
}: {
  title?: string;
  suffix?: string;
  className?: string;
  textClassName?: string;
  showText?: boolean;
}) {
  return (
    <span className={cn("inline-flex items-center gap-2.5", className)}>
      <LogoMark className="h-9 w-9 shrink-0 drop-shadow-sm" />
      {showText && (
        <span className={cn("flex flex-col leading-none", textClassName)}>
          <span className="text-[1.05rem] font-extrabold tracking-tight text-ink">{title}</span>
          <span className="text-[0.66rem] font-bold uppercase tracking-[0.22em] text-brand">
            {suffix}
          </span>
        </span>
      )}
    </span>
  );
}
