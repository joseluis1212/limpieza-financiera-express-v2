import { useNavigate } from "react-router-dom";
import { Check, ChevronRight, Mail } from "lucide-react";
import { Badge } from "./ui";
import { useApp } from "@/lib/store";
import { formatMoney } from "@/lib/currency";
import { formatDate, getCategory } from "@/lib/data";
import { cn } from "@/utils/cn";
import type { Subscription } from "@/lib/types";

export function statusBadge(
  status: Subscription["status"],
  t: ReturnType<typeof import("@/lib/i18n").t>
): { variant: "neutral" | "danger" | "warning" | "save"; label: string } {
  switch (status) {
    case "olvidada":
      return { variant: "danger", label: t.subscriptions.legendForgotten };
    case "trial":
      return { variant: "warning", label: t.subscriptions.legendTrial };
    case "activa":
      return { variant: "neutral", label: t.subscriptions.legendActive };
    case "cancelando":
      return { variant: "save", label: t.final.badgeProtected };
  }
}

export function SubscriptionCard({
  sub,
  isCancelled,
}: {
  sub: Subscription;
  isCancelled?: boolean;
}) {
  const navigate = useNavigate();
  const { lang, country, t, selected, toggleSelected } = useApp();
  const cat = getCategory(sub.category);
  const badge = statusBadge(sub.status, t);
  const isSelected = selected.includes(sub.id);
  const cancelled = isCancelled || sub.status === "cancelando";

  return (
    <div
      role="button"
      tabIndex={0}
      onClick={() => navigate(`/subscription/${sub.id}`)}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          navigate(`/subscription/${sub.id}`);
        }
      }}
      className={cn(
        "group flex w-full cursor-pointer items-center gap-4 rounded-2xl border bg-white p-4 text-left transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md",
        isSelected ? "border-brand ring-2 ring-brand/20" : "border-line",
        cancelled && "opacity-70"
      )}
    >
      <button
        type="button"
        aria-label={isSelected ? "Quitar selección" : "Seleccionar"}
        aria-pressed={isSelected}
        onClick={(e) => {
          e.stopPropagation();
          if (!cancelled) toggleSelected(sub.id);
        }}
        disabled={cancelled}
        className={cn(
          "flex h-7 w-7 shrink-0 items-center justify-center rounded-full border-2 transition-colors",
          isSelected
            ? "border-save bg-save text-white"
            : cancelled
              ? "border-save bg-save-soft text-save"
              : "border-slate-300 text-transparent hover:border-brand"
        )}
      >
        <Check className="h-4 w-4" />
      </button>

      <span
        className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl text-2xl"
        style={{ backgroundColor: sub.color }}
        aria-hidden="true"
      >
        {sub.emoji}
      </span>

      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2">
          <h3 className="truncate text-base font-bold text-ink">{sub.name}</h3>
          <Badge variant={badge.variant}>{badge.label}</Badge>
        </div>
        <p className="mt-1 flex items-center gap-1.5 text-sm text-muted">
          <span>
            {cat.emoji} {cat.label[lang]}
          </span>
          <span className="text-slate-300">·</span>
          <span className="inline-flex items-center gap-1">
            <Mail className="h-3.5 w-3.5" />
            {sub.emailsFound}
          </span>
          {sub.monthsIdle ? (
            <>
              <span className="text-slate-300">·</span>
              <span className="text-red-600">
                {sub.monthsIdle} {t.detail.monthsIdle}
              </span>
            </>
          ) : null}
        </p>
      </div>

      <div className="hidden text-right sm:block">
        <p className="text-lg font-extrabold text-ink">
          {formatMoney(sub.monthlyUsd, country)}
          <span className="text-sm font-medium text-muted">{t.common.perMonth}</span>
        </p>
        <p className="text-xs text-muted">
          {t.subscriptions.yearTotal}:{" "}
          <span className="font-semibold text-save-dark">
            {formatMoney(sub.monthlyUsd * 12, country)}
          </span>
        </p>
      </div>

      <ChevronRight className="h-5 w-5 shrink-0 text-slate-300 transition-transform group-hover:translate-x-0.5 group-hover:text-brand" />
    </div>
  );
}

export function ChargeLine({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between border-b border-line py-3 last:border-0">
      <span className="text-sm text-muted">{label}</span>
      <span className="text-sm font-bold text-ink">{value}</span>
    </div>
  );
}

export function formatChargeDate(iso: string, lang: "es" | "en") {
  return formatDate(iso, lang);
}
