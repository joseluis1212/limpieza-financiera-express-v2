import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Check, Loader2, Mail, ScanSearch, ShieldCheck } from "lucide-react";
import { Container } from "@/components/ui";
import { useApp } from "@/lib/store";
import { SUBSCRIPTIONS } from "@/lib/data";
import { cn } from "@/utils/cn";

export default function Scanning() {
  const { t, email } = useApp();
  const navigate = useNavigate();
  const [progress, setProgress] = useState(0);

  const steps = useMemo(
    () => [
      t.scanning.steps.connecting,
      t.scanning.steps.reading,
      t.scanning.steps.detecting,
      t.scanning.steps.grouping,
      t.scanning.steps.saving,
    ],
    [t]
  );

  useEffect(() => {
    const interval = window.setInterval(() => {
      setProgress((p) => {
        const next = p + Math.random() * 4 + 1.6;
        return next >= 100 ? 100 : next;
      });
    }, 130);
    return () => window.clearInterval(interval);
  }, []);

  useEffect(() => {
    if (progress >= 100) {
      const timer = window.setTimeout(() => navigate("/dashboard"), 750);
      return () => window.clearTimeout(timer);
    }
  }, [progress, navigate]);

  const activeIndex = Math.min(
    Math.floor(progress / (100 / steps.length)),
    steps.length - 1
  );
  const found = Math.round((progress / 100) * SUBSCRIPTIONS.length);

  return (
    <Container className="flex items-center justify-center py-16">
      <div className="w-full max-w-xl">
        <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-3xl bg-brand text-white shadow-lg shadow-brand/30">
          {progress >= 100 ? (
            <Check className="h-10 w-10 animate-pop" />
          ) : (
            <div className="relative">
              <ScanSearch className="h-9 w-9" />
              <span className="absolute -right-1.5 -top-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-save text-white">
                <Mail className="h-3 w-3" />
              </span>
            </div>
          )}
        </div>

        <h1 className="mt-8 text-center text-3xl font-extrabold tracking-tight text-ink">
          {progress >= 100 ? t.dashboard.eyebrow : t.scanning.title}
        </h1>
        <p className="mt-3 text-center text-lg text-muted">
          {email ? `${email} · ` : ""}
          {t.scanning.subtitle}
        </p>

        <div className="mt-8">
          <div className="flex items-center justify-between text-sm font-semibold">
            <span className="text-muted">{t.scanning.found}</span>
            <span className="text-brand">{found}</span>
          </div>
          <div className="mt-2 h-3 w-full overflow-hidden rounded-full bg-slate-100">
            <div
              className="progress-stripes h-full rounded-full bg-brand transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="mt-2 text-right text-sm font-bold text-brand">
            {Math.round(progress)}%
          </p>
        </div>

        <ul className="mt-8 space-y-3">
          {steps.map((label, i) => {
            const done = i < activeIndex || progress >= 100;
            const active = i === activeIndex && progress < 100;
            return (
              <li
                key={label}
                className={cn(
                  "flex items-center gap-3 rounded-2xl border bg-white px-4 py-3.5 transition-all duration-300",
                  active ? "border-brand ring-2 ring-brand/10" : "border-line",
                  !done && !active && "opacity-60"
                )}
              >
                <span
                  className={cn(
                    "flex h-7 w-7 shrink-0 items-center justify-center rounded-full",
                    done
                      ? "bg-save text-white"
                      : active
                        ? "bg-brand-soft text-brand"
                        : "bg-slate-100 text-slate-400"
                  )}
                >
                  {done ? (
                    <Check className="h-4 w-4 animate-pop" />
                  ) : active ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <span className="h-2 w-2 rounded-full" />
                  )}
                </span>
                <span
                  className={cn(
                    "text-base font-semibold",
                    done ? "text-ink" : active ? "text-ink" : "text-muted"
                  )}
                >
                  {label}
                </span>
                {active && (
                  <span className="ml-auto text-xs font-semibold text-brand">
                    {Math.round(((progress % (100 / steps.length)) / (100 / steps.length)) * 100)}%
                  </span>
                )}
              </li>
            );
          })}
        </ul>

        <div className="mt-8 flex items-start gap-2.5 rounded-2xl bg-save-soft p-4">
          <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-save" />
          <p className="text-sm text-save-dark">{t.scanning.trust}</p>
        </div>
      </div>
    </Container>
  );
}
