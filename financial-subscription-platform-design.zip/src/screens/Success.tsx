import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  ArrowRight,
  BadgePercent,
  Check,
  CreditCard,
  PartyPopper,
  ShieldCheck,
  Sparkles,
  Wallet,
} from "lucide-react";
import { Badge, Button, Card, Container, Reveal } from "@/components/ui";
import { useApp } from "@/lib/store";
import { computeFee, formatLocalAmount, formatMoney, formatPercent, getCountry } from "@/lib/currency";
import { SUBSCRIPTIONS } from "@/lib/data";
import { cn } from "@/utils/cn";

export default function Success() {
  const { t, country, cancelled, setPaid } = useApp();
  const navigate = useNavigate();
  const cfg = getCountry(country);

  const cancelledSubs = useMemo(
    () => SUBSCRIPTIONS.filter((s) => cancelled.includes(s.id)),
    [cancelled]
  );
  const annualUsd = cancelledSubs.reduce((a, s) => a + s.monthlyUsd * 12, 0);
  const monthlyUsd = cancelledSubs.reduce((a, s) => a + s.monthlyUsd, 0);
  const fee = computeFee(annualUsd, country);

  const [option, setOption] = useState<"percent" | "fixed">(fee.bestFeeLabel);

  const pay = () => {
    setPaid(true);
    navigate("/final");
  };

  return (
    <Container className="py-12">
      <div className="mx-auto max-w-3xl">
        {/* Cabecera */}
        <div className="text-center">
          <span className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-save text-white shadow-lg shadow-save/30">
            <PartyPopper className="h-10 w-10 animate-pop" />
          </span>
          <p className="mt-6 text-sm font-bold uppercase tracking-[0.18em] text-save">
            {t.success.eyebrow}
          </p>
          <h1 className="mt-2 text-4xl font-black tracking-tight text-ink sm:text-5xl">
            {t.success.title}
          </h1>
          <p className="mx-auto mt-3 max-w-xl text-lg text-muted">{t.success.subtitle}</p>
        </div>

        {/* Ahorro */}
        <Reveal>
          <Card className="mt-10 overflow-hidden p-0">
            <div className="bg-gradient-to-br from-save to-save-dark p-8 text-center text-white">
              <p className="text-sm font-semibold text-white/80">{t.success.annualSavings}</p>
              <p className="mt-2 text-5xl font-black tracking-tight">
                {formatMoney(annualUsd, country)}
              </p>
              <p className="mt-2 text-white/80">
                {t.success.monthlySavings}: {formatMoney(monthlyUsd, country)}
                {t.common.perMonth}
              </p>
            </div>
            <div className="grid gap-4 p-6 sm:grid-cols-2">
              <div className="flex items-center gap-3 rounded-2xl bg-surface p-4">
                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-save-soft text-save">
                  <Check className="h-6 w-6" />
                </span>
                <div>
                  <p className="text-sm text-muted">{t.success.cancelledCount}</p>
                  <p className="text-2xl font-extrabold text-ink">{cancelledSubs.length}</p>
                </div>
              </div>
              <div className="flex items-center gap-3 rounded-2xl bg-surface p-4">
                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-soft text-brand">
                  <Wallet className="h-6 w-6" />
                </span>
                <div>
                  <p className="text-sm text-muted">{t.success.monthlySavings}</p>
                  <p className="text-2xl font-extrabold text-ink">
                    {formatMoney(monthlyUsd, country)}
                  </p>
                </div>
              </div>
            </div>
            <div className="px-6 pb-6">
              <div className="flex flex-wrap gap-2">
                {cancelledSubs.map((s) => (
                  <Badge key={s.id} variant="save">
                    {s.emoji} {s.name}
                  </Badge>
                ))}
              </div>
            </div>
          </Card>
        </Reveal>

        {/* Success fee */}
        <Reveal delay={80}>
          <Card className="mt-6 p-6">
            <div className="flex items-center gap-3">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-soft text-brand">
                <BadgePercent className="h-6 w-6" />
              </span>
              <div>
                <h2 className="text-xl font-bold text-ink">{t.success.feeTitle}</h2>
                <p className="text-sm text-muted">{t.success.feeText}</p>
              </div>
            </div>

            <div className="mt-6 grid gap-3 sm:grid-cols-2">
              <button
                type="button"
                onClick={() => setOption("percent")}
                aria-pressed={option === "percent"}
                className={cn(
                  "rounded-2xl border-2 p-5 text-left transition-all",
                  option === "percent"
                    ? "border-brand bg-brand-soft ring-2 ring-brand/10"
                    : "border-line hover:border-slate-300"
                )}
              >
                <div className="flex items-center justify-between">
                  <p className="font-bold text-ink">{t.success.feePercent}</p>
                  <span
                    className={cn(
                      "flex h-5 w-5 items-center justify-center rounded-full border-2",
                      option === "percent" ? "border-brand bg-brand text-white" : "border-slate-300"
                    )}
                  >
                    {option === "percent" && <Check className="h-3.5 w-3.5" />}
                  </span>
                </div>
                <p className="mt-2 text-3xl font-black text-ink">
                  {formatLocalAmount(fee.percentFeeLocal, country)}
                </p>
                <p className="mt-1 text-sm text-muted">
                  {formatPercent(cfg.feePercent)} {t.success.feePercentText}
                </p>
              </button>

              {cfg.fixedFee != null && (
                <button
                  type="button"
                  onClick={() => setOption("fixed")}
                  aria-pressed={option === "fixed"}
                  className={cn(
                    "rounded-2xl border-2 p-5 text-left transition-all",
                    option === "fixed"
                      ? "border-save bg-save-soft ring-2 ring-save/10"
                      : "border-line hover:border-slate-300"
                  )}
                >
                  <div className="flex items-center justify-between">
                    <p className="font-bold text-ink">{t.success.feeFixed}</p>
                    <span
                      className={cn(
                        "flex h-5 w-5 items-center justify-center rounded-full border-2",
                        option === "fixed" ? "border-save bg-save text-white" : "border-slate-300"
                      )}
                    >
                      {option === "fixed" && <Check className="h-3.5 w-3.5" />}
                    </span>
                  </div>
                  <p className="mt-2 text-3xl font-black text-ink">
                    {formatLocalAmount(cfg.fixedFee, country)}
                  </p>
                  <p className="mt-1 text-sm text-muted">{t.success.feeFixedText}</p>
                </button>
              )}
            </div>

            <div className="mt-6 flex flex-col gap-3">
              <Button size="lg" onClick={pay}>
                <CreditCard className="h-5 w-5" />
                {t.success.payBtn} ·{" "}
                {formatLocalAmount(
                  option === "fixed" ? fee.fixedFeeLocal ?? fee.percentFeeLocal : fee.percentFeeLocal,
                  country
                )}
              </Button>
              <p className="flex items-center justify-center gap-2 text-sm text-muted">
                <ShieldCheck className="h-4 w-4 text-save" />
                {t.success.securePay}
              </p>
            </div>
          </Card>
        </Reveal>

        {/* Y ahora qué */}
        <Reveal delay={120}>
          <div className="mt-6 rounded-2xl border border-line bg-white p-6">
            <h2 className="text-lg font-bold text-ink">{t.success.whatNowTitle}</h2>
            <ul className="mt-4 grid gap-3 sm:grid-cols-3">
              {[t.success.whatNow1, t.success.whatNow2, t.success.whatNow3].map((txt, i) => (
                <li key={i} className="flex items-start gap-2.5">
                  <Sparkles className="mt-0.5 h-5 w-5 shrink-0 text-save" />
                  <span className="text-sm text-ink-soft">{txt}</span>
                </li>
              ))}
            </ul>
          </div>
        </Reveal>

        <div className="mt-8 text-center">
          <button
            type="button"
            onClick={() => navigate("/final")}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-muted transition-colors hover:text-ink"
          >
            {t.final.title} <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </div>
    </Container>
  );
}
