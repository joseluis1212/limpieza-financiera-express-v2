import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import {
  AlertTriangle,
  BellRing,
  CheckCircle2,
  CreditCard,
  MailPlus,
  PiggyBank,
  RefreshCw,
  ShieldCheck,
  TrendingUp,
} from "lucide-react";
import { Badge, Button, Card, Container, Reveal, Stat } from "@/components/ui";
import { useApp } from "@/lib/store";
import { formatDate, getCategory, SUBSCRIPTIONS } from "@/lib/data";
import { formatMoney } from "@/lib/currency";

export default function FinalDashboard() {
  const { t, country, lang, cancelled, paid } = useApp();
  const navigate = useNavigate();

  const cancelledSubs = useMemo(
    () => SUBSCRIPTIONS.filter((s) => cancelled.includes(s.id)),
    [cancelled]
  );
  const remaining = useMemo(
    () => SUBSCRIPTIONS.filter((s) => !cancelled.includes(s.id)),
    [cancelled]
  );
  const annualSecured = cancelledSubs.reduce((a, s) => a + s.monthlyUsd * 12, 0);
  const alerts = remaining.filter((s) => s.status === "trial").length;

  return (
    <Container className="py-10">
      <div className="flex flex-col gap-6">
        {/* Cabecera */}
        <div className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <Badge variant="save">
              <ShieldCheck className="h-4 w-4" />
              {t.final.eyebrow}
            </Badge>
            <h1 className="mt-3 text-3xl font-extrabold tracking-tight text-ink sm:text-4xl">
              {t.final.title}
            </h1>
            <p className="mt-2 max-w-2xl text-lg text-muted">{t.final.subtitle}</p>
          </div>
          <div className="flex shrink-0 flex-wrap gap-2.5">
            <Button variant="secondary" onClick={() => navigate("/scanning")}>
              <RefreshCw className="h-4 w-4" />
              {t.final.rescan}
            </Button>
            <Button variant="secondary" onClick={() => navigate("/onboarding")}>
              <MailPlus className="h-4 w-4" />
              {t.final.addEmail}
            </Button>
          </div>
        </div>

        {/* Aviso de honorario pendiente */}
        {!paid && cancelledSubs.length > 0 && (
          <Reveal>
            <div className="flex flex-col items-start gap-4 rounded-2xl border border-amber-200 bg-amber-50 p-5 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-3">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-amber-100 text-amber-700">
                  <AlertTriangle className="h-6 w-6" />
                </span>
                <div>
                  <p className="font-bold text-ink">{t.success.feeTitle}</p>
                  <p className="text-sm text-muted">{t.success.feeText}</p>
                </div>
              </div>
              <Button size="sm" onClick={() => navigate("/success")}>
                <CreditCard className="h-4 w-4" />
                {t.success.payBtn}
              </Button>
            </div>
          </Reveal>
        )}

        {/* Stats */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Reveal>
            <Stat
              label={t.final.cardActive}
              value={remaining.length}
              icon={<ShieldCheck className="h-6 w-6" />}
              accent="text-ink"
            />
          </Reveal>
          <Reveal delay={60}>
            <Stat
              label={t.final.cardCancelled}
              value={cancelledSubs.length}
              icon={<CheckCircle2 className="h-6 w-6" />}
              accent="text-save-dark"
            />
          </Reveal>
          <Reveal delay={120}>
            <Stat
              label={t.final.cardSaving}
              value={formatMoney(annualSecured, country)}
              icon={<PiggyBank className="h-6 w-6" />}
              accent="text-save-dark"
            />
          </Reveal>
          <Reveal delay={180}>
            <Stat
              label={t.final.cardAlert}
              value={alerts}
              icon={<BellRing className="h-6 w-6" />}
              accent="text-amber-600"
            />
          </Reveal>
        </div>

        {/* Suscripciones canceladas */}
        {cancelledSubs.length > 0 && (
          <Reveal>
            <Card className="p-6">
              <div className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-save" />
                <h2 className="text-xl font-bold text-ink">{t.final.cardCancelled}</h2>
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                {cancelledSubs.map((s) => (
                  <Badge key={s.id} variant="save">
                    <CheckCircle2 className="h-3.5 w-3.5" />
                    {s.emoji} {s.name}
                  </Badge>
                ))}
              </div>
            </Card>
          </Reveal>
        )}

        <div className="grid gap-6 lg:grid-cols-2">
          {/* Monitoreo */}
          <Reveal>
            <Card className="h-full p-6">
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-brand-soft text-brand">
                <ShieldCheck className="h-6 w-6" />
              </span>
              <h2 className="mt-4 text-xl font-bold text-ink">{t.final.monitoringTitle}</h2>
              <p className="mt-2 leading-relaxed text-muted">{t.final.monitoringText}</p>
              <div className="mt-5 flex items-center gap-3 rounded-2xl bg-save-soft p-4">
                <span className="relative flex h-3 w-3">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-save opacity-75" />
                  <span className="relative inline-flex h-3 w-3 rounded-full bg-save" />
                </span>
                <p className="font-semibold text-save-dark">{t.final.badgeProtected}</p>
              </div>
            </Card>
          </Reveal>

          {/* Próximas renovaciones */}
          <Reveal delay={80}>
            <Card className="h-full p-6">
              <div className="flex items-center gap-2">
                <BellRing className="h-5 w-5 text-brand" />
                <h2 className="text-xl font-bold text-ink">{t.final.alertTitle}</h2>
              </div>
              {remaining.length === 0 ? (
                <p className="mt-4 text-muted">{t.final.alertEmpty}</p>
              ) : (
                <ul className="mt-4 divide-y divide-line">
                  {remaining.slice(0, 4).map((s) => (
                    <li key={s.id} className="flex items-center gap-3 py-3">
                      <span
                        className="flex h-10 w-10 items-center justify-center rounded-lg text-xl"
                        style={{ backgroundColor: s.color }}
                        aria-hidden
                      >
                        {s.emoji}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-bold text-ink">{s.name}</p>
                        <p className="text-xs text-muted">
                          {t.final.tableNext}: {formatDate(s.nextCharge, lang)}
                        </p>
                      </div>
                      <span className="text-sm font-bold text-ink">
                        {formatMoney(s.monthlyUsd, country)}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </Card>
          </Reveal>
        </div>

        {/* Tabla de suscripciones restantes */}
        <Reveal>
          <Card className="overflow-hidden p-0">
            <div className="border-b border-line bg-surface px-6 py-4">
              <h2 className="text-lg font-bold text-ink">{t.final.cardActive}</h2>
            </div>
            <div className="divide-y divide-line">
              {remaining.map((s) => {
                const cat = getCategory(s.category);
                return (
                  <div key={s.id} className="flex items-center gap-4 px-6 py-4">
                    <span
                      className="flex h-11 w-11 items-center justify-center rounded-xl text-xl"
                      style={{ backgroundColor: s.color }}
                      aria-hidden
                    >
                      {s.emoji}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-bold text-ink">{s.name}</p>
                      <p className="text-sm text-muted">
                        {cat.emoji} {cat.label[lang]}
                      </p>
                    </div>
                    <Badge variant={s.status === "trial" ? "warning" : "neutral"}>
                      {s.status === "trial"
                        ? t.subscriptions.legendTrial
                        : t.subscriptions.legendActive}
                    </Badge>
                    <span className="hidden text-sm font-bold text-ink sm:block">
                      {formatMoney(s.monthlyUsd, country)}
                      {t.common.perMonth}
                    </span>
                  </div>
                );
              })}
              {remaining.length === 0 && (
                <p className="px-6 py-8 text-center text-muted">{t.final.alertEmpty}</p>
              )}
            </div>
          </Card>
        </Reveal>
      </div>
    </Container>
  );
}
