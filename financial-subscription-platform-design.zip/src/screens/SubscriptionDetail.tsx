import { Link, useNavigate, useParams } from "react-router-dom";
import {
  ArrowLeft,
  ArrowRight,
  CalendarClock,
  CheckCircle2,
  Mail,
  MousePointerClick,
  Sparkles,
  Zap,
} from "lucide-react";
import { Badge, Button, Card, Container } from "@/components/ui";
import { ChargeLine, statusBadge } from "@/components/SubscriptionCard";
import { useApp } from "@/lib/store";
import { formatMoney } from "@/lib/currency";
import { formatDate, getCategory, SUBSCRIPTIONS } from "@/lib/data";

export default function SubscriptionDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { t, country, lang, cancelled } = useApp();

  const sub = SUBSCRIPTIONS.find((s) => s.id === id);
  if (!sub) {
    navigate("/subscriptions");
    return null;
  }

  const cat = getCategory(sub.category);
  const badge = statusBadge(sub.status, t);
  const isCancelled = cancelled.includes(sub.id) || sub.status === "cancelando";

  const MethodIcon =
    sub.method === "automatica" ? Zap : sub.method === "guiada" ? MousePointerClick : Mail;
  const methodLabel =
    sub.method === "automatica"
      ? t.detail.methodAutomatica
      : sub.method === "guiada"
        ? t.detail.methodGuiada
        : t.detail.methodManual;

  const statusText =
    sub.status === "olvidada"
      ? t.detail.statusForgotten
      : sub.status === "trial"
        ? t.detail.statusTrial
        : t.detail.statusActive;

  return (
    <Container className="py-10">
      <Link
        to="/subscriptions"
        className="inline-flex items-center gap-2 text-sm font-semibold text-muted transition-colors hover:text-ink"
      >
        <ArrowLeft className="h-4 w-4" />
        {t.detail.back}
      </Link>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        {/* Columna principal */}
        <div className="lg:col-span-2">
          <Card className="p-6 sm:p-8">
            <div className="flex flex-col gap-5 sm:flex-row sm:items-start">
              <span
                className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl text-4xl"
                style={{ backgroundColor: sub.color }}
                aria-hidden
              >
                {sub.emoji}
              </span>
              <div className="flex-1">
                <div className="flex flex-wrap items-center gap-2.5">
                  <h1 className="text-3xl font-extrabold tracking-tight text-ink">{sub.name}</h1>
                  <Badge variant={badge.variant}>{badge.label}</Badge>
                </div>
                <p className="mt-1 text-sm font-semibold text-muted">
                  {cat.emoji} {cat.label[lang]}
                </p>
                <p className="mt-4 text-lg leading-relaxed text-ink-soft">
                  {sub.description[lang]}
                </p>
                {sub.monthsIdle ? (
                  <p className="mt-3 inline-flex items-center gap-2 rounded-full bg-red-50 px-3 py-1.5 text-sm font-semibold text-red-700">
                    <CalendarClock className="h-4 w-4" />
                    {statusText} · {sub.monthsIdle} {t.detail.monthsIdle}
                  </p>
                ) : (
                  <p className="mt-3 text-sm text-muted">{statusText}</p>
                )}
              </div>
            </div>

            <div className="mt-8 border-t border-line pt-6">
              <h2 className="text-sm font-bold uppercase tracking-wider text-muted">
                {t.detail.detectedEmails}
              </h2>
              <div className="mt-3 divide-y divide-line rounded-2xl border border-line bg-surface px-5">
                <ChargeLine
                  label={t.detail.monthlyCost}
                  value={`${formatMoney(sub.monthlyUsd, country)}${t.common.perMonth}`}
                />
                <ChargeLine
                  label={t.detail.annualCost}
                  value={formatMoney(sub.monthlyUsd * 12, country)}
                />
                <ChargeLine label={t.detail.lastCharge} value={formatDate(sub.lastCharge, lang)} />
                <ChargeLine label={t.detail.nextCharge} value={formatDate(sub.nextCharge, lang)} />
                <ChargeLine label={t.detail.detectedEmails} value={`${sub.emailsFound}`} />
              </div>
            </div>
          </Card>
        </div>

        {/* Columna lateral */}
        <div className="space-y-5">
          <Card className="p-6">
            <h2 className="text-lg font-bold text-ink">{t.dashboard.recapTitle}</h2>
            <div className="mt-4 rounded-2xl bg-save-soft p-5">
              <p className="text-sm font-semibold text-save-dark">{t.detail.annualCost}</p>
              <p className="mt-1 text-3xl font-black tracking-tight text-save-dark">
                {formatMoney(sub.monthlyUsd * 12, country)}
              </p>
              <p className="mt-1 text-sm text-save-dark/80">
                {formatMoney(sub.monthlyUsd, country)}
                {t.common.perMonth}
              </p>
            </div>

            {isCancelled ? (
              <div className="mt-5 flex items-center gap-3 rounded-2xl border border-save-100 bg-save-soft p-4">
                <CheckCircle2 className="h-6 w-6 shrink-0 text-save" />
                <p className="font-semibold text-save-dark">{t.cancel.autoDone}</p>
              </div>
            ) : (
              <Button
                size="lg"
                variant="danger"
                className="mt-5 w-full"
                onClick={() => navigate(`/cancel/${sub.id}`)}
              >
                {t.detail.cancelCta}
                <ArrowRight className="h-5 w-5" />
              </Button>
            )}

            <p className="mt-4 flex items-start gap-2 text-sm text-muted">
              <Sparkles className="mt-0.5 h-4 w-4 shrink-0 text-save" />
              {t.detail.cancelNote}
            </p>
          </Card>

          <Card className="p-6">
            <div className="flex items-center gap-3">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-soft text-brand">
                <MethodIcon className="h-5 w-5" />
              </span>
              <div>
                <p className="text-sm text-muted">{t.detail.cancelMethod}</p>
                <p className="font-bold text-ink">{methodLabel}</p>
              </div>
            </div>

            <div className="mt-5">
              <div className="flex items-center justify-between text-sm">
                <span className="font-semibold text-muted">{t.detail.confidence}</span>
                <span className="font-bold text-ink">{sub.confidence}%</span>
              </div>
              <div className="mt-2 h-2.5 w-full overflow-hidden rounded-full bg-slate-100">
                <div
                  className="h-full rounded-full bg-save"
                  style={{ width: `${sub.confidence}%` }}
                />
              </div>
            </div>

            <div className="mt-5 flex items-center justify-between border-t border-line pt-4 text-sm">
              <span className="flex items-center gap-1.5 text-muted">
                <Mail className="h-4 w-4" />
                {t.detail.detectedEmails}
              </span>
              <span className="font-bold text-ink">{sub.emailsFound}</span>
            </div>
          </Card>
        </div>
      </div>
    </Container>
  );
}
