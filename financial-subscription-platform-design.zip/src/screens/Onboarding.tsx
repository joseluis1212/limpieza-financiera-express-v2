import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  Loader2,
  Lock,
  ShieldCheck,
  X,
} from "lucide-react";
import { Button, Container, Stepper, type StepState } from "@/components/ui";
import { useApp } from "@/lib/store";
import { COUNTRIES, COUNTRY_ORDER, formatPercent } from "@/lib/currency";
import { cn } from "@/utils/cn";
import type { Country } from "@/lib/types";

function GoogleIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={className} aria-hidden="true">
      <path
        fill="#FFC107"
        d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.3 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.9 1.2 8 3l5.7-5.7C34.6 6.1 29.6 4 24 4 13 4 4 13 4 24s9 20 20 20 20-9 20-20c0-1.2-.1-2.3-.4-3.5z"
      />
      <path
        fill="#FF3D00"
        d="M6.3 14.7l6.6 4.8C14.7 15.1 18.9 12 24 12c3.1 0 5.9 1.2 8 3l5.7-5.7C34.6 6.1 29.6 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"
      />
      <path
        fill="#4CAF50"
        d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.3 0-9.7-3.3-11.3-8l-6.5 5C9.5 39.6 16.2 44 24 44z"
      />
      <path
        fill="#1976D2"
        d="M43.6 20.5H42V20H24v8h11.3c-.8 2.3-2.3 4.3-4.1 5.7l6.2 5.2C41.4 35.4 44 30.3 44 24c0-1.2-.1-2.3-.4-3.5z"
      />
    </svg>
  );
}

function MicrosoftIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 23 23" className={className} aria-hidden="true">
      <path fill="#f35325" d="M1 1h10v10H1z" />
      <path fill="#81bc06" d="M12 1h10v10H12z" />
      <path fill="#05a6f0" d="M1 12h10v10H1z" />
      <path fill="#ffba08" d="M12 12h10v10H12z" />
    </svg>
  );
}

export default function Onboarding() {
  const { country, setCountry, setEmail, t, lang } = useApp();
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [agreed, setAgreed] = useState(false);
  const [connecting, setConnecting] = useState<string | null>(null);

  const labels = [
    t.onboarding.steps.country,
    t.onboarding.steps.consent,
    t.onboarding.steps.connect,
  ];
  const steps: StepState[] = labels.map((label, i) => ({
    label,
    state: i < step ? "done" : i === step ? "current" : "todo",
  }));

  const connect = (provider: string) => {
    setConnecting(provider);
    window.setTimeout(() => {
      setEmail(provider);
      navigate("/scanning");
    }, 1500);
  };

  return (
    <Container className="py-10">
      <div className="mx-auto max-w-3xl">
        <Stepper steps={steps} />

        <div className="mt-10">
          {/* STEP 0 — País */}
          {step === 0 && (
            <div key="country" className="animate-fade-up">
              <h1 className="text-3xl font-extrabold tracking-tight text-ink">
                {t.onboarding.countryTitle}
              </h1>
              <p className="mt-3 text-lg text-muted">{t.onboarding.countryText}</p>

              <div className="mt-8 grid gap-4 sm:grid-cols-3">
                {COUNTRY_ORDER.map((code: Country) => {
                  const cfg = COUNTRIES[code];
                  const active = country === code;
                  return (
                    <button
                      key={code}
                      type="button"
                      onClick={() => setCountry(code)}
                      aria-pressed={active}
                      className={cn(
                        "relative rounded-2xl border-2 bg-white p-6 text-left transition-all",
                        active
                          ? "border-brand shadow-md ring-4 ring-brand/10"
                          : "border-line hover:border-slate-300"
                      )}
                    >
                      {active && (
                        <span className="absolute right-3 top-3 flex h-6 w-6 items-center justify-center rounded-full bg-brand text-white">
                          <Check className="h-4 w-4" />
                        </span>
                      )}
                      <span className="text-4xl">{cfg.flag}</span>
                      <p className="mt-3 text-lg font-bold text-ink">{cfg.name[lang]}</p>
                      <p className="mt-1 text-sm text-muted">
                        {t.landing.pricing.feeLabel}:{" "}
                        <span className="font-semibold text-brand">
                          {formatPercent(cfg.feePercent)}
                        </span>
                      </p>
                    </button>
                  );
                })}
              </div>

              <div className="mt-10 flex justify-end">
                <Button size="lg" onClick={() => setStep(1)}>
                  {t.common.next}
                  <ArrowRight className="h-5 w-5" />
                </Button>
              </div>
            </div>
          )}

          {/* STEP 1 — Consentimiento */}
          {step === 1 && (
            <div key="consent" className="animate-fade-up">
              <div className="flex items-center gap-3">
                <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-brand-soft text-brand">
                  <ShieldCheck className="h-6 w-6" />
                </span>
                <h1 className="text-3xl font-extrabold tracking-tight text-ink">
                  {t.onboarding.consentTitle}
                </h1>
              </div>
              <p className="mt-3 text-lg text-muted">{t.onboarding.consentText}</p>

              <div className="mt-8 grid gap-5 sm:grid-cols-2">
                <div className="rounded-2xl border border-save-100 bg-save-soft p-6">
                  <p className="text-sm font-bold uppercase tracking-wide text-save-dark">
                    ✓
                  </p>
                  <ul className="mt-3 space-y-3">
                    {[t.onboarding.consentOk1, t.onboarding.consentOk2, t.onboarding.consentOk3].map(
                      (txt) => (
                        <li key={txt} className="flex items-start gap-2.5 text-ink">
                          <Check className="mt-0.5 h-5 w-5 shrink-0 text-save" />
                          <span>{txt}</span>
                        </li>
                      )
                    )}
                  </ul>
                </div>
                <div className="rounded-2xl border border-line bg-white p-6">
                  <p className="text-sm font-bold uppercase tracking-wide text-muted">✕</p>
                  <ul className="mt-3 space-y-3">
                    {[t.onboarding.consentNo1, t.onboarding.consentNo2, t.onboarding.consentNo3].map(
                      (txt) => (
                        <li key={txt} className="flex items-start gap-2.5 text-muted">
                          <X className="mt-0.5 h-5 w-5 shrink-0 text-slate-400" />
                          <span>{txt}</span>
                        </li>
                      )
                    )}
                  </ul>
                </div>
              </div>

              <label className="mt-8 flex cursor-pointer items-start gap-3 rounded-2xl border border-line bg-white p-5">
                <input
                  type="checkbox"
                  checked={agreed}
                  onChange={(e) => setAgreed(e.target.checked)}
                  className="mt-1 h-5 w-5 rounded border-slate-300 text-brand focus:ring-brand"
                />
                <span className="text-base font-semibold text-ink">
                  {t.onboarding.consentAgree}
                </span>
              </label>

              <div className="mt-8 flex items-center justify-between">
                <Button variant="ghost" onClick={() => setStep(0)}>
                  <ArrowLeft className="h-5 w-5" />
                  {t.common.back}
                </Button>
                <Button size="lg" disabled={!agreed} onClick={() => setStep(2)}>
                  {t.common.next}
                  <ArrowRight className="h-5 w-5" />
                </Button>
              </div>
            </div>
          )}

          {/* STEP 2 — Conexión de email */}
          {step === 2 && (
            <div key="connect" className="animate-fade-up">
              <h1 className="text-3xl font-extrabold tracking-tight text-ink">
                {t.onboarding.connectTitle}
              </h1>
              <p className="mt-3 text-lg text-muted">{t.onboarding.connectText}</p>

              <div className="mt-8 grid gap-4 sm:grid-cols-2">
                <button
                  type="button"
                  onClick={() => connect("Gmail")}
                  disabled={connecting != null}
                  className="group flex items-center gap-4 rounded-2xl border-2 border-line bg-white p-6 text-left transition-all hover:border-slate-300 hover:shadow-md disabled:opacity-60"
                >
                  <GoogleIcon className="h-10 w-10" />
                  <span className="flex-1">
                    <span className="block text-lg font-bold text-ink">{t.onboarding.gmail}</span>
                    <span className="text-sm text-muted">Gmail · Google</span>
                  </span>
                  {connecting === "Gmail" ? (
                    <Loader2 className="h-5 w-5 animate-spin text-brand" />
                  ) : (
                    <ArrowRight className="h-5 w-5 text-slate-300 transition-transform group-hover:translate-x-0.5 group-hover:text-brand" />
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => connect("Outlook")}
                  disabled={connecting != null}
                  className="group flex items-center gap-4 rounded-2xl border-2 border-line bg-white p-6 text-left transition-all hover:border-slate-300 hover:shadow-md disabled:opacity-60"
                >
                  <MicrosoftIcon className="h-10 w-10" />
                  <span className="flex-1">
                    <span className="block text-lg font-bold text-ink">{t.onboarding.outlook}</span>
                    <span className="text-sm text-muted">Outlook · Microsoft</span>
                  </span>
                  {connecting === "Outlook" ? (
                    <Loader2 className="h-5 w-5 animate-spin text-brand" />
                  ) : (
                    <ArrowRight className="h-5 w-5 text-slate-300 transition-transform group-hover:translate-x-0.5 group-hover:text-brand" />
                  )}
                </button>
              </div>

              {connecting && (
                <div className="mt-6 flex items-center justify-center gap-3 rounded-2xl bg-brand-soft p-4 text-brand-dark">
                  <Loader2 className="h-5 w-5 animate-spin" />
                  <span className="font-semibold">{t.scanning.steps.connecting}</span>
                </div>
              )}

              <div className="mt-6 flex items-start gap-2.5 rounded-2xl border border-line bg-white p-5">
                <Lock className="mt-0.5 h-5 w-5 shrink-0 text-save" />
                <p className="text-sm text-muted">{t.onboarding.oauthNote}</p>
              </div>

              <div className="mt-4 rounded-2xl border border-dashed border-line p-5">
                <p className="font-bold text-ink">{t.onboarding.otherProvider}</p>
                <p className="mt-1 text-sm text-muted">{t.onboarding.otherProviderNote}</p>
              </div>

              <div className="mt-8 flex justify-start">
                <Button variant="ghost" onClick={() => setStep(1)} disabled={connecting != null}>
                  <ArrowLeft className="h-5 w-5" />
                  {t.common.back}
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </Container>
  );
}
