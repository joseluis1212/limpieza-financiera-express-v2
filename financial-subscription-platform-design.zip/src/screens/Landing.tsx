import { useState } from "react";
import {
  ArrowRight,
  BadgeCheck,
  BadgePercent,
  BellRing,
  Check,
  ChevronDown,
  DollarSign,
  Lock,
  Mail,
  MousePointerClick,
  PiggyBank,
  Quote,
  ScanSearch,
  Search,
  ShieldCheck,
  TrendingUp,
  Users,
} from "lucide-react";
import { Badge, Button, Card, Container, LinkButton, Reveal, SectionHeading } from "@/components/ui";
import { useApp } from "@/lib/store";
import { COUNTRIES, COUNTRY_ORDER, formatLocalAmount, formatMoney, formatPercent } from "@/lib/currency";
import { FAQ, SUBSCRIPTIONS, TESTIMONIALS } from "@/lib/data";
import { cn } from "@/utils/cn";

const howIcons = [Mail, ScanSearch, BadgeCheck];
const benefitIcons = [Search, MousePointerClick, Lock, BellRing, TrendingUp, BadgePercent];

function HeroVisual() {
  const { t, country } = useApp();
  const forgotten = SUBSCRIPTIONS.filter((s) => s.isForgotten || s.status === "trial");
  const annual = forgotten.reduce((a, s) => a + s.monthlyUsd * 12, 0);
  const top = [...forgotten].sort((a, b) => b.monthlyUsd - a.monthlyUsd).slice(0, 3);

  return (
    <div className="relative mx-auto w-full max-w-md">
      <div className="absolute -left-8 -top-8 h-40 w-40 rounded-full bg-brand/10 blur-3xl" aria-hidden />
      <div className="absolute -bottom-10 -right-6 h-44 w-44 rounded-full bg-save/10 blur-3xl" aria-hidden />

      <Card className="animate-float relative overflow-hidden p-6 shadow-2xl shadow-brand/10">
        <div className="flex items-center justify-between">
          <span className="inline-flex items-center gap-2 text-sm font-bold text-ink">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand text-white">
              <ScanSearch className="h-4 w-4" />
            </span>
            {t.landing.how.step2Title}
          </span>
          <Badge variant="save">
            <Check className="h-3.5 w-3.5" /> {t.dashboard.eyebrow}
          </Badge>
        </div>

        <div className="mt-6">
          <p className="text-sm text-muted">{t.landing.stats.avg}</p>
          <p className="mt-1 text-4xl font-black tracking-tight text-save-dark">
            {formatMoney(annual, country)}
          </p>
        </div>

        <div className="mt-6 space-y-2.5">
          {top.map((s) => (
            <div
              key={s.id}
              className="flex items-center gap-3 rounded-xl bg-surface px-3 py-2.5"
            >
              <span
                className="flex h-9 w-9 items-center justify-center rounded-lg text-lg"
                style={{ backgroundColor: s.color }}
                aria-hidden
              >
                {s.emoji}
              </span>
              <span className="min-w-0 flex-1 truncate text-sm font-semibold text-ink">
                {s.name}
              </span>
              <span className="text-sm font-bold text-ink">
                {formatMoney(s.monthlyUsd, country)}
              </span>
              <span className="flex h-5 w-5 items-center justify-center rounded-full bg-save text-white">
                <Check className="h-3.5 w-3.5" />
              </span>
            </div>
          ))}
        </div>

        <div className="mt-5 flex items-center justify-between rounded-xl bg-save-soft px-4 py-3">
          <span className="text-sm font-bold text-save-dark">{t.success.cancelledCount}</span>
          <span className="text-sm font-extrabold text-save-dark">{forgotten.length}</span>
        </div>
      </Card>

      <div className="absolute -right-3 top-24 hidden animate-pop rounded-xl border border-line bg-white px-3 py-2 shadow-lg sm:block">
        <p className="flex items-center gap-1 text-xs font-bold text-save-dark">
          <Check className="h-3.5 w-3.5" />
          {forgotten.length} {t.success.cancelledCount}
        </p>
      </div>
    </div>
  );
}

function StatStrip() {
  const { t, lang } = useApp();
  const users = lang === "es" ? "48.000" : "48,000";
  const stats = [
    { value: "12.4M", label: t.landing.stats.emails, icon: Mail },
    { value: "$2.1M", label: t.landing.stats.money, icon: DollarSign },
    { value: users, label: t.landing.stats.users, icon: Users },
    { value: "$320", label: t.landing.stats.avg, icon: PiggyBank },
  ];
  return (
    <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
      {stats.map((s) => (
        <Reveal key={s.label}>
          <Card className="flex items-center gap-4 p-5">
            <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-brand-soft text-brand">
              <s.icon className="h-6 w-6" />
            </span>
            <div>
              <p className="text-2xl font-extrabold tracking-tight text-ink">{s.value}</p>
              <p className="text-sm text-muted">{s.label}</p>
            </div>
          </Card>
        </Reveal>
      ))}
    </div>
  );
}

function PricingCards() {
  const { t, lang } = useApp();
  return (
    <div className="grid gap-5 md:grid-cols-3">
      {COUNTRY_ORDER.map((code) => {
        const cfg = COUNTRIES[code];
        return (
          <Reveal key={code}>
            <Card className="flex h-full flex-col p-6">
              <div className="flex items-center gap-3">
                <span className="text-3xl">{cfg.flag}</span>
                <div>
                  <h3 className="text-lg font-bold text-ink">{cfg.name[lang]}</h3>
                  <p className="text-sm text-muted">{t.landing.pricing.feeLabel}</p>
                </div>
              </div>
              <p className="mt-5 text-4xl font-black tracking-tight text-brand">
                {formatPercent(cfg.feePercent)}
              </p>
              <p className="mt-2 text-sm leading-relaxed text-muted">{t.landing.pricing.feeText}</p>
              {cfg.fixedFee != null && (
                <div className="mt-4 rounded-xl bg-save-soft px-4 py-3">
                  <p className="text-xs font-bold uppercase tracking-wide text-save-dark">
                    {t.landing.pricing.fixedLabel}
                  </p>
                  <p className="mt-1 text-lg font-extrabold text-save-dark">
                    {formatLocalAmount(cfg.fixedFee, code)}
                  </p>
                  <p className="text-xs text-muted">{t.landing.pricing.fixedText}</p>
                </div>
              )}
            </Card>
          </Reveal>
        );
      })}
    </div>
  );
}

function Testimonials() {
  const { lang, country, t } = useApp();
  return (
    <div className="grid gap-5 md:grid-cols-2">
      {TESTIMONIALS.map((tm) => (
        <Reveal key={tm.name}>
          <Card className="flex h-full flex-col p-6">
            <Quote className="h-8 w-8 text-brand/30" />
            <p className="mt-3 flex-1 text-lg leading-relaxed text-ink">“{tm.quote[lang]}”</p>
            <div className="mt-5 flex items-center gap-3 border-t border-line pt-5">
              <span
                className="flex h-11 w-11 items-center justify-center rounded-full text-sm font-bold text-ink"
                style={{ backgroundColor: tm.color }}
              >
                {tm.initials}
              </span>
              <div className="flex-1">
                <p className="font-bold text-ink">{tm.name}</p>
                <p className="text-sm text-muted">{tm.location[lang]}</p>
              </div>
              <Badge variant="save">
                <PiggyBank className="h-3.5 w-3.5" />
                {formatMoney(tm.savingsUsd, country)}
                {t.common.perYear}
              </Badge>
            </div>
          </Card>
        </Reveal>
      ))}
    </div>
  );
}

function Faq() {
  const { lang } = useApp();
  const [open, setOpen] = useState<number | null>(0);
  return (
    <div className="mx-auto max-w-3xl space-y-3">
      {FAQ.map((item, i) => {
        const isOpen = open === i;
        return (
          <Reveal key={i}>
            <div className="overflow-hidden rounded-2xl border border-line bg-white">
              <button
                type="button"
                onClick={() => setOpen(isOpen ? null : i)}
                aria-expanded={isOpen}
                className="flex w-full items-center justify-between gap-4 px-6 py-5 text-left"
              >
                <span className="text-lg font-semibold text-ink">{item.q[lang]}</span>
                <ChevronDown
                  className={cn(
                    "h-5 w-5 shrink-0 text-muted transition-transform duration-200",
                    isOpen && "rotate-180"
                  )}
                />
              </button>
              {isOpen && (
                <p className="animate-fade-in px-6 pb-6 text-base leading-relaxed text-muted">
                  {item.a[lang]}
                </p>
              )}
            </div>
          </Reveal>
        );
      })}
    </div>
  );
}

export default function Landing() {
  const { t } = useApp();

  return (
    <div className="overflow-hidden">
      {/* HERO */}
      <section className="relative bg-gradient-to-b from-brand-soft via-white to-white">
        <div
          className="pointer-events-none absolute inset-x-0 top-0 h-[500px] bg-[radial-gradient(60%_60%_at_50%_0%,rgba(37,99,235,0.08),transparent)]"
          aria-hidden
        />
        <Container className="relative grid items-center gap-12 py-16 lg:grid-cols-2 lg:py-24">
          <div className="text-center lg:text-left">
            <Badge variant="brand" className="mb-6">
              <ShieldCheck className="h-4 w-4" />
              {t.landing.hero.badge}
            </Badge>
            <h1 className="text-4xl font-black leading-[1.1] tracking-tight text-ink sm:text-5xl lg:text-6xl">
              {t.landing.hero.titlePre}{" "}
              <span className="text-brand underline decoration-save decoration-4 underline-offset-8">
                {t.landing.hero.titleHighlight}
              </span>{" "}
              {t.landing.hero.titlePost}
            </h1>
            <p className="mx-auto mt-6 max-w-xl text-lg leading-relaxed text-muted lg:mx-0 lg:text-xl">
              {t.landing.hero.subtitle}
            </p>
            <div className="mt-8 flex flex-col items-center gap-3 sm:flex-row lg:justify-start">
              <LinkButton to="/onboarding" size="lg" className="w-full sm:w-auto">
                {t.landing.hero.ctaPrimary}
                <ArrowRight className="h-5 w-5" />
              </LinkButton>
              <Button
                variant="secondary"
                size="lg"
                className="w-full sm:w-auto"
                onClick={() =>
                  document.getElementById("how")?.scrollIntoView({ behavior: "smooth" })
                }
              >
                {t.landing.hero.ctaSecondary}
              </Button>
            </div>
            <ul className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-3 lg:justify-start">
              {[t.landing.hero.trust1, t.landing.hero.trust2, t.landing.hero.trust3].map((txt) => (
                <li key={txt} className="flex items-center gap-2 text-sm font-medium text-muted">
                  <span className="flex h-5 w-5 items-center justify-center rounded-full bg-save-soft text-save">
                    <Check className="h-3.5 w-3.5" />
                  </span>
                  {txt}
                </li>
              ))}
            </ul>
          </div>

          <HeroVisual />
        </Container>
      </section>

      {/* STATS */}
      <section className="py-12">
        <Container>
          <StatStrip />
        </Container>
      </section>

      {/* HOW */}
      <section id="how" className="scroll-mt-20 py-20">
        <Container>
          <SectionHeading title={t.landing.how.title} subtitle={t.landing.how.subtitle} />
          <div className="mt-14 grid gap-6 md:grid-cols-3">
            {[
              { icon: howIcons[0], title: t.landing.how.step1Title, text: t.landing.how.step1Text },
              { icon: howIcons[1], title: t.landing.how.step2Title, text: t.landing.how.step2Text },
              { icon: howIcons[2], title: t.landing.how.step3Title, text: t.landing.how.step3Text },
            ].map((step, i) => (
              <Reveal key={step.title} delay={i * 100}>
                <div className="relative h-full rounded-2xl border border-line bg-white p-8">
                  <span className="absolute right-6 top-6 text-5xl font-black text-brand-soft">
                    {i + 1}
                  </span>
                  <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-brand text-white shadow-md shadow-brand/20">
                    <step.icon className="h-7 w-7" />
                  </span>
                  <h3 className="mt-6 text-xl font-bold text-ink">{step.title}</h3>
                  <p className="mt-3 leading-relaxed text-muted">{step.text}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </Container>
      </section>

      {/* BENEFITS */}
      <section id="benefits" className="scroll-mt-20 bg-surface py-20">
        <Container>
          <SectionHeading title={t.landing.benefits.title} subtitle={t.landing.benefits.subtitle} />
          <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {t.landing.benefits.items.map((item, i) => (
              <Reveal key={item.title} delay={(i % 3) * 90}>
                <Card className="h-full p-7">
                  <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-save-soft text-save">
                    {(() => {
                      const Icon = benefitIcons[i];
                      return <Icon className="h-6 w-6" />;
                    })()}
                  </span>
                  <h3 className="mt-5 text-lg font-bold text-ink">{item.title}</h3>
                  <p className="mt-2 leading-relaxed text-muted">{item.text}</p>
                </Card>
              </Reveal>
            ))}
          </div>
        </Container>
      </section>

      {/* PRICING */}
      <section id="pricing" className="scroll-mt-20 py-20">
        <Container>
          <SectionHeading title={t.landing.pricing.title} subtitle={t.landing.pricing.subtitle} />
          <div className="mt-14">
            <PricingCards />
          </div>
          <Reveal className="mt-8">
            <div className="flex flex-col items-center gap-4 rounded-2xl bg-brand-soft px-6 py-6 text-center sm:flex-row sm:justify-between sm:text-left">
              <div className="flex items-center gap-3">
                <ShieldCheck className="h-8 w-8 shrink-0 text-brand" />
                <p className="text-lg font-semibold text-ink">{t.landing.pricing.guarantee}</p>
              </div>
              <LinkButton to="/onboarding" size="sm">
                {t.landing.hero.ctaPrimary}
              </LinkButton>
            </div>
          </Reveal>
        </Container>
      </section>

      {/* TESTIMONIALS */}
      <section className="bg-surface py-20">
        <Container>
          <SectionHeading
            title={t.landing.testimonials.title}
            subtitle={t.landing.testimonials.subtitle}
          />
          <div className="mt-14">
            <Testimonials />
          </div>
        </Container>
      </section>

      {/* FAQ */}
      <section id="faq" className="scroll-mt-20 py-20">
        <Container>
          <SectionHeading title={t.landing.faqTitle} subtitle={t.landing.faqSubtitle} />
          <div className="mt-12">
            <Faq />
          </div>
        </Container>
      </section>

      {/* FINAL CTA */}
      <section className="py-20">
        <Container>
          <Reveal>
            <div className="relative overflow-hidden rounded-3xl bg-ink px-6 py-16 text-center text-white sm:px-16">
              <div
                className="pointer-events-none absolute -right-16 -top-16 h-64 w-64 rounded-full bg-brand/40 blur-3xl"
                aria-hidden
              />
              <div
                className="pointer-events-none absolute -bottom-16 -left-16 h-64 w-64 rounded-full bg-save/40 blur-3xl"
                aria-hidden
              />
              <div className="relative">
                <h2 className="mx-auto max-w-2xl text-3xl font-black tracking-tight sm:text-4xl">
                  {t.landing.final.title}
                </h2>
                <p className="mx-auto mt-4 max-w-xl text-lg text-slate-300">
                  {t.landing.final.text}
                </p>
                <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
                  <LinkButton to="/onboarding" size="lg" variant="success">
                    {t.landing.final.cta}
                    <ArrowRight className="h-5 w-5" />
                  </LinkButton>
                </div>
                <p className="mt-5 text-sm text-slate-400">{t.landing.final.note}</p>
              </div>
            </div>
          </Reveal>
        </Container>
      </section>
    </div>
  );
}
