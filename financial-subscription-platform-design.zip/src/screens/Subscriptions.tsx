import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowRight, CheckCheck, ListChecks, PiggyBank } from "lucide-react";
import { Badge, Button, Container } from "@/components/ui";
import { SubscriptionCard } from "@/components/SubscriptionCard";
import { useApp } from "@/lib/store";
import { formatMoney } from "@/lib/currency";
import { SUBSCRIPTIONS } from "@/lib/data";
import { cn } from "@/utils/cn";
import type { Subscription } from "@/lib/types";

type Filter = "all" | "forgotten" | "trial" | "active";

export default function Subscriptions() {
  const { t, country, selected, setSelected, cancelled } = useApp();
  const navigate = useNavigate();
  const [filter, setFilter] = useState<Filter>("all");

  const visible = useMemo(
    () => SUBSCRIPTIONS.filter((s) => !cancelled.includes(s.id)),
    [cancelled]
  );
  const actionable = useMemo(
    () => visible.filter((s) => s.isForgotten || s.status === "trial"),
    [visible]
  );

  const filtered = useMemo(() => {
    switch (filter) {
      case "forgotten":
        return visible.filter((s) => s.isForgotten);
      case "trial":
        return visible.filter((s) => s.status === "trial");
      case "active":
        return visible.filter((s) => s.status === "activa");
      default:
        return visible;
    }
  }, [filter, visible]);

  const countBy = (f: Filter) => {
    if (f === "all") return visible.length;
    if (f === "forgotten") return visible.filter((s) => s.isForgotten).length;
    if (f === "trial") return visible.filter((s) => s.status === "trial").length;
    return visible.filter((s) => s.status === "activa").length;
  };

  const selectedSubs = visible.filter((s) => selected.includes(s.id));
  const selectedAnnual = selectedSubs.reduce((a, s) => a + s.monthlyUsd * 12, 0);
  const potentialAnnual = actionable.reduce((a, s) => a + s.monthlyUsd * 12, 0);
  const allSelected = actionable.length > 0 && actionable.every((s) => selected.includes(s.id));

  const toggleAll = () => {
    if (allSelected) {
      setSelected(selected.filter((id) => !actionable.some((s) => s.id === id)));
    } else {
      setSelected(Array.from(new Set([...selected, ...actionable.map((s) => s.id)])));
    }
  };

  const filters: { key: Filter; label: string }[] = [
    { key: "all", label: t.subscriptions.filterAll },
    { key: "forgotten", label: t.subscriptions.filterForgotten },
    { key: "trial", label: t.subscriptions.filterTrial },
    { key: "active", label: t.subscriptions.filterActive },
  ];

  return (
    <Container className="pb-36 pt-10">
      <div className="flex flex-col gap-5">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight text-ink sm:text-4xl">
            {t.subscriptions.title}
          </h1>
          <p className="mt-2 max-w-2xl text-lg text-muted">{t.subscriptions.subtitle}</p>
        </div>

        {/* Filtros */}
        <div className="flex flex-wrap gap-2" role="tablist" aria-label="Filtros">
          {filters.map((f) => (
            <button
              key={f.key}
              type="button"
              role="tab"
              aria-selected={filter === f.key}
              onClick={() => setFilter(f.key)}
              className={cn(
                "rounded-full px-4 py-2 text-sm font-semibold transition-colors",
                filter === f.key
                  ? "bg-ink text-white"
                  : "bg-white text-muted border border-line hover:border-slate-300"
              )}
            >
              {f.label}
              <span className={cn("ml-1.5", filter === f.key ? "text-slate-300" : "text-slate-400")}>
                {countBy(f.key)}
              </span>
            </button>
          ))}
        </div>

        {/* Seleccionar todas */}
        <div className="flex flex-col gap-3 rounded-2xl border border-line bg-white p-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <ListChecks className="h-6 w-6 shrink-0 text-brand" />
            <div>
              <p className="font-bold text-ink">{t.subscriptions.totalPotential}</p>
              <p className="text-sm text-muted">
                {actionable.length} {t.subscriptions.foundCount}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-xl font-extrabold text-save-dark">
              {formatMoney(potentialAnnual, country)}
              <span className="text-sm font-medium text-muted">{t.common.perYear}</span>
            </span>
            <Button variant="secondary" size="sm" onClick={toggleAll}>
              <CheckCheck className="h-4 w-4" />
              {allSelected ? t.subscriptions.clearSelection : t.subscriptions.selectAll}
            </Button>
          </div>
        </div>

        {/* Lista */}
        {filtered.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-line bg-white p-12 text-center">
            <p className="text-lg text-muted">{t.subscriptions.empty}</p>
          </div>
        ) : (
          <div className="space-y-3">
            {filtered.map((s: Subscription) => (
              <SubscriptionCard key={s.id} sub={s} />
            ))}
          </div>
        )}

        {cancelled.length > 0 && (
          <p className="text-center text-sm font-semibold text-save-dark">
            ✓ {cancelled.length} {t.success.cancelledCount.toLowerCase()}
          </p>
        )}
      </div>

      {/* Barra inferior fija */}
      <div className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-white/95 backdrop-blur-md">
        <Container className="flex flex-col gap-3 py-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-save-soft text-save">
              <PiggyBank className="h-6 w-6" />
            </span>
            <div>
              <p className="text-sm text-muted">{t.subscriptions.selectedSavings}</p>
              <p className="text-xl font-extrabold text-save-dark">
                {formatMoney(selectedAnnual, country)}
                <span className="text-sm font-medium text-muted">{t.common.perYear}</span>
              </p>
            </div>
            {selected.length > 0 && (
              <Badge variant="save" className="ml-2">
                {selected.length}
              </Badge>
            )}
          </div>
          <Button
            size="lg"
            disabled={selected.length === 0}
            onClick={() => navigate("/cancel")}
          >
            {t.subscriptions.cancel}
            <ArrowRight className="h-5 w-5" />
          </Button>
        </Container>
      </div>
    </Container>
  );
}
