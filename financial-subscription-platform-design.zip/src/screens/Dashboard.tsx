import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import {
  ArrowRight,
  BellRing,
  ChevronRight,
  PiggyBank,
  RefreshCw,
  ScanSearch,
  TrendingUp,
} from "lucide-react";
import { Badge, Button, Card, Container, LinkButton, Reveal, Stat } from "@/components/ui";
import { useApp } from "@/lib/store";
import { formatMoney } from "@/lib/currency";
import { CATEGORIES, SUBSCRIPTIONS } from "@/lib/data";
import { cn } from "@/utils/cn";

const catColors: Record<string, string> = {
  streaming: "#2563eb",
  musica: "#0ea5e9",
  cloud: "#6366f1",
  software: "#8b5cf6",
  fitness: "#059669",
  entrega: "#f59e0b",
  educacion: "#10b981",
  citas: "#ec4899",
};

function DonutChart() {
  const { country, t, lang } = useApp();
  const byCat = CATEGORIES.map((c) => ({
    ...c,
    total: SUBSCRIPTIONS.filter((s) => s.category === c.key).reduce(
      (a, s) => a + s.monthlyUsd,
      0
    ),
  })).filter((c) => c.total > 0);

  const total = byCat.reduce((a, c) => a + c.total, 0);
  let acc = 0;
  const segments = byCat.map((c) => {
    const start = (acc / total) * 360;
    acc += c.total;
    const end = (acc / total) * 360;
    return `${catColors[c.key] ?? "#94a3b8"} ${start}deg ${end}deg`;
  });

  return (
    <div className="grid items-center gap-8 md:grid-cols-[auto_1fr]">
      <div className="relative mx-auto h-56 w-56" aria-hidden="true">
        <div
          className="h-full w-full rounded-full"
          style={{ background: `conic-gradient(${segments.join(",")})` }}
        />
        <div className="absolute inset-[22%] flex flex-col items-center justify-center rounded-full bg-white text-center shadow-inner">
          <span className="text-sm text-muted">{t.dashboard.cards.monthly}</span>
          <span className="text-2xl font-black text-ink">{formatMoney(total, country)}</span>
        </div>
      </div>

      <ul className="space-y-2.5">
        {byCat.map((c) => {
          const pct = Math.round((c.total / total) * 100);
          return (
            <li key={c.key} className="flex items-center gap-3">
              <span
                className="h-3.5 w-3.5 shrink-0 rounded-full"
                style={{ backgroundColor: catColors[c.key] ?? "#94a3b8" }}
                aria-hidden
              />
              <span className="min-w-0 flex-1 truncate text-sm font-semibold text-ink">
                {c.emoji} {c.label[lang]}
              </span>
              <span className="text-sm font-bold text-ink">{formatMoney(c.total, country)}</span>
              <span className="w-10 text-right text-sm text-muted">{pct}%</span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

export default function Dashboard() {
  const { t, country, email } = useApp();
  const navigate = useNavigate();

  const actionable = useMemo(
    () => SUBSCRIPTIONS.filter((s) => s.isForgotten || s.status === "trial"),
    []
  );
  const monthlySavings = actionable.reduce((a, s) => a + s.monthlyUsd, 0);
  const annualSavings = monthlySavings * 12;
  const trials = SUBSCRIPTIONS.filter((s) => s.status === "trial").length;
  const top = [...actionable].sort((a, b) => b.monthlyUsd - a.monthlyUsd).slice(0, 4);

  return (
    <Container className="py-10">
      <div className="flex flex-col gap-6">
        {/* Cabecera */}
        <div className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <div className="flex flex-wrap items-center gap-3">
              <Badge variant="save">{t.dashboard.eyebrow}</Badge>
              {email && <Badge variant="outline">✉️ {email}</Badge>}
            </div>
            <h1 className="mt-3 text-3xl font-extrabold tracking-tight text-ink sm:text-4xl">
              {t.dashboard.title} 👋
            </h1>
            <p className="mt-2 max-w-2xl text-lg text-muted">{t.dashboard.subtitle}</p>
          </div>
          <div className="flex shrink-0 gap-2.5">
            <Button variant="secondary" onClick={() => navigate("/scanning")}>
              <RefreshCw className="h-4 w-4" />
              {t.dashboard.ctaSecondary}
            </Button>
            <Button onClick={() => navigate("/subscriptions")}>
              {t.dashboard.ctaPrimary}
              <ArrowRight className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Reveal>
            <Stat
              label={t.dashboard.cards.found}
              value={SUBSCRIPTIONS.length}
              icon={<ScanSearch className="h-6 w-6" />}
              accent="text-ink"
            />
          </Reveal>
          <Reveal delay={60}>
            <Stat
              label={t.dashboard.cards.monthly}
              value={formatMoney(monthlySavings, country)}
              icon={<PiggyBank className="h-6 w-6" />}
              accent="text-save-dark"
            />
          </Reveal>
          <Reveal delay={120}>
            <Stat
              label={t.dashboard.cards.annual}
              value={formatMoney(annualSavings, country)}
              icon={<TrendingUp className="h-6 w-6" />}
              accent="text-save-dark"
            />
          </Reveal>
          <Reveal delay={180}>
            <Stat
              label={t.dashboard.cards.renew}
              value={trials}
              icon={<BellRing className="h-6 w-6" />}
              accent="text-amber-600"
            />
          </Reveal>
        </div>

        <div className="grid gap-6 lg:grid-cols-5">
          {/* Gráfico */}
          <Reveal className="lg:col-span-3">
            <Card className="h-full p-6">
              <h2 className="text-xl font-bold text-ink">{t.dashboard.chartTitle}</h2>
              <p className="mt-1 text-sm text-muted">{t.dashboard.chartNote}</p>
              <div className="mt-6">
                <DonutChart />
              </div>
            </Card>
          </Reveal>

          {/* Recapitulación de ahorro */}
          <Reveal className="lg:col-span-2" delay={80}>
            <Card className="flex h-full flex-col p-6">
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-save-soft text-save">
                <PiggyBank className="h-6 w-6" />
              </span>
              <h2 className="mt-4 text-xl font-bold text-ink">{t.dashboard.recapTitle}</h2>
              <p className="mt-1 text-sm text-muted">{t.dashboard.recapNote}</p>

              <div className="mt-6 rounded-2xl bg-save-soft p-5">
                <p className="text-sm font-semibold text-save-dark">
                  {t.dashboard.cards.annual}
                </p>
                <p className="mt-1 text-4xl font-black tracking-tight text-save-dark">
                  {formatMoney(annualSavings, country)}
                </p>
              </div>

              <ul className="mt-5 space-y-3">
                {top.slice(0, 3).map((s) => (
                  <li key={s.id} className="flex items-center gap-3">
                    <span
                      className="flex h-9 w-9 items-center justify-center rounded-lg text-lg"
                      style={{ backgroundColor: s.color }}
                      aria-hidden
                    >
                      {s.emoji}
                    </span>
                    <span className="min-w-0 flex-1 truncate text-sm font-semibold text-ink">
                      {s.name}
                    </span>
                    <span className="text-sm font-bold text-ink">
                      {formatMoney(s.monthlyUsd, country)}
                      {t.common.perMonth}
                    </span>
                  </li>
                ))}
              </ul>

              <LinkButton to="/subscriptions" className="mt-6 w-full">
                {t.dashboard.ctaPrimary}
                <ArrowRight className="h-4 w-4" />
              </LinkButton>
            </Card>
          </Reveal>
        </div>

        {/* Top para cancelar */}
        <Reveal>
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold text-ink">
                {t.landing.how.step3Title}
              </h2>
              <button
                type="button"
                onClick={() => navigate("/subscriptions")}
                className="flex items-center gap-1 text-sm font-semibold text-brand hover:text-brand-dark"
              >
                {t.dashboard.ctaPrimary}
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
            <div className="mt-5 grid gap-3 sm:grid-cols-2">
              {top.map((s) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => navigate(`/subscription/${s.id}`)}
                  className={cn(
                    "group flex items-center gap-3 rounded-2xl border border-line bg-white p-4 text-left transition-all hover:border-brand hover:shadow-sm"
                  )}
                >
                  <span
                    className="flex h-11 w-11 items-center justify-center rounded-xl text-xl"
                    style={{ backgroundColor: s.color }}
                    aria-hidden
                  >
                    {s.emoji}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-bold text-ink">{s.name}</span>
                    <span className="text-sm text-muted">
                      {formatMoney(s.monthlyUsd, country)}
                      {t.common.perMonth}
                    </span>
                  </span>
                  <Badge variant={s.status === "trial" ? "warning" : "danger"}>
                    {s.status === "trial"
                      ? t.subscriptions.legendTrial
                      : t.subscriptions.legendForgotten}
                  </Badge>
                  <ChevronRight className="h-4 w-4 text-slate-300 transition-transform group-hover:translate-x-0.5 group-hover:text-brand" />
                </button>
              ))}
            </div>
          </Card>
        </Reveal>
      </div>
    </Container>
  );
}
