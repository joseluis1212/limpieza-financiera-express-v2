import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  CheckCircle2,
  ExternalLink,
  Loader2,
  Lock,
  Mail,
  MousePointerClick,
  ShieldCheck,
  Sparkles,
  Zap,
} from "lucide-react";
import { Badge, Button, Card, Container } from "@/components/ui";
import { statusBadge } from "@/components/SubscriptionCard";
import { useApp } from "@/lib/store";
import { formatMoney } from "@/lib/currency";
import { SUBSCRIPTIONS } from "@/lib/data";
import { cn } from "@/utils/cn";
import type { Subscription } from "@/lib/types";

function methodInfo(method: Subscription["method"]) {
  if (method === "automatica") return { Icon: Zap, label: "automatica" };
  if (method === "guiada") return { Icon: MousePointerClick, label: "guiada" };
  return { Icon: Mail, label: "manual" };
}

function SubSummary({ sub }: { sub: Subscription }) {
  const { t, country } = useApp();
  const badge = statusBadge(sub.status, t);
  const { Icon, label } = methodInfo(sub.method);
  const methodText =
    label === "automatica"
      ? t.detail.methodAutomatica
      : label === "guiada"
        ? t.detail.methodGuiada
        : t.detail.methodManual;
  return (
    <div className="flex items-center gap-4 rounded-2xl border border-line bg-white p-4">
      <span
        className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl text-2xl"
        style={{ backgroundColor: sub.color }}
        aria-hidden
      >
        {sub.emoji}
      </span>
      <div className="min-w-0 flex-1">
        <p className="truncate text-base font-bold text-ink">{sub.name}</p>
        <p className="text-sm text-muted">
          {formatMoney(sub.monthlyUsd, country)}
          {t.common.perMonth}
        </p>
      </div>
      <div className="flex shrink-0 flex-col items-end gap-1.5">
        <Badge variant={badge.variant}>{badge.label}</Badge>
        <span className="inline-flex items-center gap-1 text-xs text-muted">
          <Icon className="h-3.5 w-3.5" />
          {methodText}
        </span>
      </div>
    </div>
  );
}

function SafeNote({ text }: { text: string }) {
  return (
    <div className="flex items-start gap-2.5 rounded-2xl bg-save-soft p-4">
      <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-save" />
      <p className="text-sm text-save-dark">{text}</p>
    </div>
  );
}

/* ------------------------- Cancelación individual ------------------------- */
function SingleCancel({ sub }: { sub: Subscription }) {
  const { t, markCancelled } = useApp();
  const navigate = useNavigate();
  const [phase, setPhase] = useState<"intro" | "working" | "done">("intro");
  const [doneSteps, setDoneSteps] = useState<boolean[]>(() => [false, false, false, false]);

  useEffect(() => {
    if (phase !== "working") return;
    const timer = window.setTimeout(() => {
      markCancelled(sub.id);
      setPhase("done");
    }, 1900);
    return () => window.clearTimeout(timer);
  }, [phase, sub.id, markCancelled]);

  const { Icon } = methodInfo(sub.method);
  const isAuto = sub.method === "automatica";
  const isGuided = sub.method === "guiada";
  const allDone = doneSteps.every(Boolean);

  const titles: Record<string, string> = {
    automatica: t.cancel.titleAuto,
    guiada: t.cancel.titleGuided,
    manual: t.cancel.titleManual,
  };

  return (
    <div className="mx-auto max-w-2xl">
      <Link
        to={`/subscription/${sub.id}`}
        className="inline-flex items-center gap-2 text-sm font-semibold text-muted transition-colors hover:text-ink"
      >
        <ArrowLeft className="h-4 w-4" />
        {t.detail.back}
      </Link>

      <div className="mt-6">
        <div className="flex items-center gap-3">
          <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-brand-soft text-brand">
            <Icon className="h-6 w-6" />
          </span>
          <h1 className="text-3xl font-extrabold tracking-tight text-ink">
            {titles[sub.method]}
          </h1>
        </div>

        <div className="mt-6">
          <SubSummary sub={sub} />
        </div>

        {/* Automática */}
        {isAuto && phase !== "done" && (
          <Card className="mt-5 p-6">
            <p className="text-lg text-ink-soft">{t.cancel.autoIntro}</p>
            {phase === "intro" ? (
              <Button size="lg" className="mt-6" onClick={() => setPhase("working")}>
                <Zap className="h-5 w-5" />
                {t.cancel.autoBtn}
              </Button>
            ) : (
              <div className="mt-6 flex flex-col items-center gap-4 rounded-2xl bg-surface p-8 text-center">
                <Loader2 className="h-10 w-10 animate-spin text-brand" />
                <p className="text-lg font-bold text-ink">{t.cancel.working}</p>
                <p className="text-sm text-muted">{sub.name}…</p>
              </div>
            )}
          </Card>
        )}

        {/* Guiada */}
        {isGuided && phase !== "done" && (
          <Card className="mt-5 p-6">
            <p className="text-lg text-ink-soft">{t.cancel.guidedIntro}</p>
            <ol className="mt-6 space-y-3">
              {t.cancel.guidedSteps.map((step, i) => (
                <li key={i}>
                  <button
                    type="button"
                    onClick={() =>
                      setDoneSteps((prev) => prev.map((v, idx) => (idx === i ? !v : v)))
                    }
                    aria-pressed={doneSteps[i]}
                    className={cn(
                      "flex w-full items-start gap-3 rounded-2xl border bg-white p-4 text-left transition-all",
                      doneSteps[i] ? "border-save bg-save-soft" : "border-line hover:border-slate-300"
                    )}
                  >
                    <span
                      className={cn(
                        "flex h-6 w-6 shrink-0 items-center justify-center rounded-full border-2",
                        doneSteps[i] ? "border-save bg-save text-white" : "border-slate-300"
                      )}
                    >
                      {doneSteps[i] && <Check className="h-4 w-4" />}
                    </span>
                    <span className="text-sm">
                      <span className="font-bold text-ink">
                        {t.cancel.stepLabel} {i + 1}.
                      </span>{" "}
                      <span className={doneSteps[i] ? "text-save-dark" : "text-ink-soft"}>
                        {step}
                      </span>
                    </span>
                  </button>
                </li>
              ))}
            </ol>
            <Button
              size="lg"
              variant="success"
              className="mt-6"
              disabled={!allDone}
              onClick={() => {
                markCancelled(sub.id);
                navigate("/success");
              }}
            >
              {t.cancel.guidedBtn}
              <Check className="h-5 w-5" />
            </Button>
          </Card>
        )}

        {/* Manual */}
        {!isAuto && !isGuided && phase !== "done" && (
          <Card className="mt-5 p-6">
            <p className="text-lg text-ink-soft">{t.cancel.manualIntro}</p>
            <div className="mt-6 flex flex-col gap-3 sm:flex-row">
              <a
                href="#"
                onClick={(e) => e.preventDefault()}
                className="inline-flex items-center justify-center gap-2 rounded-full bg-ink px-6 py-3 font-semibold text-white transition-colors hover:bg-ink-soft"
              >
                <ExternalLink className="h-5 w-5" />
                {t.cancel.goToSite}
              </a>
              <Button
                size="lg"
                variant="success"
                onClick={() => {
                  markCancelled(sub.id);
                  navigate("/success");
                }}
              >
                {t.cancel.manualBtn}
                <Check className="h-5 w-5" />
              </Button>
            </div>
          </Card>
        )}

        {/* Done */}
        {phase === "done" && (
          <Card className="mt-5 p-8 text-center">
            <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-save text-white">
              <CheckCircle2 className="h-9 w-9 animate-pop" />
            </span>
            <h2 className="mt-5 text-2xl font-extrabold text-ink">{t.cancel.autoDone}</h2>
            <p className="mt-2 text-lg text-muted">{t.cancel.autoDoneText}</p>
            <Button size="lg" className="mt-7" onClick={() => navigate("/success")}>
              {t.common.next}
              <ArrowRight className="h-5 w-5" />
            </Button>
          </Card>
        )}

        <div className="mt-5">
          <SafeNote text={t.cancel.safeText} />
        </div>
      </div>
    </div>
  );
}

/* ------------------------- Cancelación masiva ------------------------- */
function BatchCancel() {
  const { t, country, selected, cancelled, markCancelled } = useApp();
  const navigate = useNavigate();
  const [phase, setPhase] = useState<"confirm" | "working">("confirm");

  const subs = useMemo(
    () => SUBSCRIPTIONS.filter((s) => selected.includes(s.id) && !cancelled.includes(s.id)),
    [selected, cancelled]
  );
  const annual = subs.reduce((a, s) => a + s.monthlyUsd * 12, 0);

  useEffect(() => {
    if (phase !== "working") return;
    const timer = window.setTimeout(() => {
      subs.forEach((s) => markCancelled(s.id));
      navigate("/success");
    }, 2200);
    return () => window.clearTimeout(timer);
  }, [phase, subs, markCancelled, navigate]);

  if (subs.length === 0) {
    return (
      <Container className="py-16 text-center">
        <p className="text-lg text-muted">{t.subscriptions.empty}</p>
        <Link to="/subscriptions" className="mt-4 inline-block font-semibold text-brand">
          {t.detail.back}
        </Link>
      </Container>
    );
  }

  return (
    <Container className="py-10">
      <div className="mx-auto max-w-2xl">
        <h1 className="text-3xl font-extrabold tracking-tight text-ink">
          {t.cancel.confirmTitle}
        </h1>
        <p className="mt-3 text-lg text-muted">{t.cancel.confirmText}</p>

        <div className="mt-7 space-y-3">
          {subs.map((s) => (
            <SubSummary key={s.id} sub={s} />
          ))}
        </div>

        <div className="mt-6 flex items-center justify-between rounded-2xl bg-save-soft p-5">
          <span className="font-semibold text-save-dark">{t.success.annualSavings}</span>
          <span className="text-2xl font-black text-save-dark">
            {formatMoney(annual, country)}
          </span>
        </div>

        {phase === "confirm" ? (
          <div className="mt-7 flex flex-col gap-3 sm:flex-row">
            <Button size="lg" className="flex-1" onClick={() => setPhase("working")}>
              {t.cancel.confirmBtn}
              <Check className="h-5 w-5" />
            </Button>
            <Link
              to="/subscriptions"
              className="inline-flex items-center justify-center gap-2 rounded-full border border-line bg-white px-6 py-3 font-semibold text-ink transition-colors hover:bg-surface"
            >
              {t.cancel.cancelBack}
            </Link>
          </div>
        ) : (
          <div className="mt-7 flex flex-col items-center gap-4 rounded-2xl bg-surface p-8 text-center">
            <Loader2 className="h-10 w-10 animate-spin text-brand" />
            <p className="text-lg font-bold text-ink">{t.cancel.working}</p>
            <div className="w-full max-w-sm space-y-2">
              {subs.map((s) => (
                <div key={s.id} className="flex items-center gap-2 text-sm text-muted">
                  <span className="h-2 w-2 rounded-full bg-save" />
                  <span className="truncate">{s.name}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="mt-5 flex items-start gap-2.5 rounded-2xl bg-save-soft p-4">
          <Lock className="mt-0.5 h-5 w-5 shrink-0 text-save" />
          <p className="text-sm text-save-dark">{t.cancel.safeText}</p>
        </div>

        <div className="mt-5 flex items-start gap-2.5 rounded-2xl border border-line bg-white p-4">
          <Sparkles className="mt-0.5 h-5 w-5 shrink-0 text-brand" />
          <p className="text-sm text-muted">{t.detail.cancelNote}</p>
        </div>
      </div>
    </Container>
  );
}

export default function CancelFlow() {
  const { id } = useParams();
  const sub = SUBSCRIPTIONS.find((s) => s.id === id);

  return (
    <Container className="py-10">
      {sub ? <SingleCancel sub={sub} /> : <BatchCancel />}
    </Container>
  );
}
